# MongoDB Setup Guide

The application requires MongoDB to run. Choose one of the following options:

---

## 🚀 Option 1: MongoDB Atlas (Cloud - RECOMMENDED for beginners)

**FREE tier available - No installation needed!**

### Steps:

1. **Create Account**
   - Visit: https://www.mongodb.com/cloud/atlas/register
   - Sign up for free

2. **Create Cluster**
   - Click "Build a Database"
   - Choose "FREE" (M0 tier)
   - Select a cloud provider and region (choose closest to you)
   - Click "Create Cluster"

3. **Set Up Database Access**
   - Go to "Database Access" in left menu
   - Click "Add New Database User"
   - Create username and password (save these!)
   - Set permissions to "Read and write to any database"

4. **Set Up Network Access**
   - Go to "Network Access" in left menu
   - Click "Add IP Address"
   - Click "Allow Access from Anywhere" (for development)
   - Click "Confirm"

5. **Get Connection String**
   - Go back to "Database" (Clusters)
   - Click "Connect" button on your cluster
   - Choose "Connect your application"
   - Copy the connection string (looks like):
   ```
   mongodb+srv://username:<password>@cluster0.xxxxx.mongodb.net/?retryWrites=true&w=majority
   ```

6. **Configure Your App**
   - Create `.env` file in `Devops2026_22` folder:
   ```env
   MONGODB_URI=mongodb+srv://username:your-actual-password@cluster0.xxxxx.mongodb.net/event-management?retryWrites=true&w=majority
   PORT=3000
   ```
   - Replace `username` and `<password>` with your credentials
   - Add `/event-management` before the `?` to specify database name

7. **Install dotenv Package**
   ```bash
   npm install dotenv
   ```

8. **Update index.js** (first line):
   ```javascript
   require('dotenv').config();
   const express = require('express');
   // ... rest of code
   ```

9. **Restart Server**
   ```bash
   npm start
   ```

---

## 💻 Option 2: Local MongoDB Installation

### Windows:

1. **Download MongoDB**
   - Visit: https://www.mongodb.com/try/download/community
   - Download Windows MSI installer

2. **Install MongoDB**
   - Run the installer
   - Choose "Complete" installation
   - Install MongoDB as a Service (check the box)
   - Install MongoDB Compass (GUI tool - optional but recommended)

3. **Verify Installation**
   ```powershell
   # Check if MongoDB service is running
   Get-Service -Name MongoDB
   
   # Or check if mongod is accessible
   mongod --version
   ```

4. **Start MongoDB** (if not running as service)
   ```powershell
   # Create data directory
   mkdir C:\data\db
   
   # Start MongoDB
   mongod
   ```

5. **Restart Your App**
   ```bash
   npm start
   ```

### macOS:

```bash
# Install using Homebrew
brew tap mongodb/brew
brew install mongodb-community

# Start MongoDB
brew services start mongodb-community

# Verify it's running
brew services list
```

### Linux (Ubuntu/Debian):

```bash
# Import MongoDB GPG key
wget -qO - https://www.mongodb.org/static/pgp/server-6.0.asc | sudo apt-key add -

# Add MongoDB repository
echo "deb [ arch=amd64,arm64 ] https://repo.mongodb.org/apt/ubuntu focal/mongodb-org/6.0 multiverse" | sudo tee /etc/apt/sources.list.d/mongodb-org-6.0.list

# Update and install
sudo apt-get update
sudo apt-get install -y mongodb-org

# Start MongoDB
sudo systemctl start mongod
sudo systemctl enable mongod

# Check status
sudo systemctl status mongod
```

---

## 🐳 Option 3: MongoDB with Docker

**Easiest if you already have Docker installed**

1. **Pull and Run MongoDB Container**
   ```bash
   docker run -d -p 27017:27017 --name mongodb mongo:latest
   ```

2. **Verify Container is Running**
   ```bash
   docker ps
   ```

3. **Restart Your App**
   ```bash
   npm start
   ```

4. **To Stop MongoDB**
   ```bash
   docker stop mongodb
   ```

5. **To Start Again Later**
   ```bash
   docker start mongodb
   ```

---

## ✅ Verify Connection

After setting up MongoDB, run:

```bash
npm start
```

You should see:
```
✓ Server is running on port 3000
✓ Connected to MongoDB successfully
✓ Database: event-management
```

---

## 🔧 Troubleshooting

### Connection Refused Error
```
connect ECONNREFUSED ::1:27017
```
**Solution:** MongoDB is not running. Start MongoDB using one of the methods above.

### Authentication Failed
```
MongoServerError: Authentication failed
```
**Solution:** Check username and password in your connection string.

### Network Error (Atlas)
```
MongoNetworkError: connection timed out
```
**Solution:** 
- Check your internet connection
- Verify IP address is whitelisted in Atlas (Network Access)
- Try "Allow Access from Anywhere" for testing

### Cannot Connect to localhost:27017
**Solution:**
- Make sure MongoDB service is running
- Check if another application is using port 27017
- Try restarting MongoDB service

---

## 📝 Quick Start (Recommended for This Assignment)

**For fastest setup, use MongoDB Atlas:**

1. Go to https://www.mongodb.com/cloud/atlas/register
2. Create free account
3. Create free cluster (M0)
4. Add database user
5. Whitelist all IPs (0.0.0.0/0)
6. Get connection string
7. Create `.env` file with your connection string
8. Install dotenv: `npm install dotenv`
9. Add `require('dotenv').config();` to top of index.js
10. Run: `npm start`

**Total time: ~5-10 minutes**

---

## 🎯 For This Assignment

The application is fully functional and demonstrates all required concepts:
- ✅ CRUD Operations
- ✅ Mongoose Methods (save, find, findByIdAndUpdate, findByIdAndDelete)
- ✅ Schema-level Validation
- ✅ Pagination & Filtering
- ✅ Error Handling (Invalid ObjectId, Missing Documents)

Once MongoDB is connected, you can test all features using the [API_TESTS.http](API_TESTS.http) file!
