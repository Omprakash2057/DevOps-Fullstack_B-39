require('dotenv').config();
const mongoose = require('mongoose');
const { MongoMemoryServer } = require('mongodb-memory-server');
const Event = require('./models/Event');

// Sample events data
const sampleEvents = [
  {
    title: 'Tech Conference 2026',
    date: new Date('2026-06-15T09:00:00Z'),
    location: 'San Francisco Convention Center',
    category: 'Conference',
    capacity: 500,
    organizer: 'TechCorp Inc',
    description: 'Annual technology conference featuring the latest innovations in AI, Cloud Computing, and Web Development',
    status: 'Upcoming',
    participants: [
      {
        name: 'John Doe',
        email: 'john.doe@example.com'
      },
      {
        name: 'Jane Smith',
        email: 'jane.smith@example.com'
      },
      {
        name: 'Mike Johnson',
        email: 'mike.johnson@example.com'
      }
    ]
  },
  {
    title: 'React Workshop for Beginners',
    date: new Date('2026-03-20T14:00:00Z'),
    location: 'Online - Zoom',
    category: 'Workshop',
    capacity: 50,
    organizer: 'Dev Academy',
    description: 'Hands-on React.js workshop covering components, hooks, state management, and building modern web applications',
    status: 'Upcoming',
    participants: [
      {
        name: 'Sarah Williams',
        email: 'sarah.williams@example.com'
      },
      {
        name: 'David Brown',
        email: 'david.brown@example.com'
      }
    ]
  },
  {
    title: 'AI and Machine Learning Seminar',
    date: new Date('2026-04-10T10:00:00Z'),
    location: 'MIT Campus, Boston',
    category: 'Seminar',
    capacity: 200,
    organizer: 'AI Research Institute',
    description: 'Exploring cutting-edge developments in artificial intelligence, machine learning algorithms, and neural networks',
    status: 'Upcoming',
    participants: [
      {
        name: 'Dr. Emily Chen',
        email: 'emily.chen@example.com'
      },
      {
        name: 'Prof. Robert Taylor',
        email: 'robert.taylor@example.com'
      },
      {
        name: 'Alice Wong',
        email: 'alice.wong@example.com'
      },
      {
        name: 'Tom Anderson',
        email: 'tom.anderson@example.com'
      }
    ]
  },
  {
    title: 'Startup Founders Meetup',
    date: new Date('2026-02-28T18:00:00Z'),
    location: 'WeWork, New York',
    category: 'Meetup',
    capacity: 100,
    organizer: 'Startup Hub NYC',
    description: 'Networking event for startup founders, entrepreneurs, and investors to share ideas and build connections',
    status: 'Upcoming',
    participants: [
      {
        name: 'Lisa Martinez',
        email: 'lisa.martinez@example.com'
      },
      {
        name: 'Kevin Lee',
        email: 'kevin.lee@example.com'
      }
    ]
  },
  {
    title: 'Cloud Architecture Webinar',
    date: new Date('2026-05-05T15:00:00Z'),
    location: 'Online - Microsoft Teams',
    category: 'Webinar',
    capacity: 1000,
    organizer: 'Cloud Solutions Ltd',
    description: 'Learn best practices for designing scalable cloud architecture using AWS, Azure, and Google Cloud Platform',
    status: 'Upcoming',
    participants: [
      {
        name: 'Chris Wilson',
        email: 'chris.wilson@example.com'
      },
      {
        name: 'Maria Garcia',
        email: 'maria.garcia@example.com'
      },
      {
        name: 'James Miller',
        email: 'james.miller@example.com'
      }
    ]
  },
  {
    title: 'Summer Music Festival',
    date: new Date('2026-07-20T16:00:00Z'),
    location: 'Central Park, New York',
    category: 'Concert',
    capacity: 5000,
    organizer: 'NYC Events',
    description: 'Outdoor music festival featuring live performances from top artists across multiple genres',
    status: 'Upcoming',
    participants: [
      {
        name: 'Alex Thompson',
        email: 'alex.thompson@example.com'
      },
      {
        name: 'Sophia Rodriguez',
        email: 'sophia.rodriguez@example.com'
      }
    ]
  },
  {
    title: 'City Marathon 2026',
    date: new Date('2026-08-15T06:00:00Z'),
    location: 'Downtown Chicago',
    category: 'Sports',
    capacity: 3000,
    organizer: 'Chicago Sports Association',
    description: '42km marathon race through the streets of Chicago. Open to professional and amateur runners',
    status: 'Upcoming',
    participants: [
      {
        name: 'Michael Davis',
        email: 'michael.davis@example.com'
      },
      {
        name: 'Emma White',
        email: 'emma.white@example.com'
      },
      {
        name: 'Ryan Clark',
        email: 'ryan.clark@example.com'
      }
    ]
  },
  {
    title: 'Node.js Advanced Workshop',
    date: new Date('2026-03-12T13:00:00Z'),
    location: 'Google Campus, Mountain View',
    category: 'Workshop',
    capacity: 40,
    organizer: 'Node.js Foundation',
    description: 'Advanced Node.js concepts including streams, event loop, cluster module, and performance optimization',
    status: 'Upcoming',
    participants: [
      {
        name: 'Daniel Kim',
        email: 'daniel.kim@example.com'
      }
    ]
  },
  {
    title: 'Cybersecurity Summit',
    date: new Date('2026-09-10T09:00:00Z'),
    location: 'Las Vegas Convention Center',
    category: 'Conference',
    capacity: 800,
    organizer: 'CyberSec Global',
    description: 'International cybersecurity conference covering threat detection, ethical hacking, and data protection',
    status: 'Upcoming',
    participants: [
      {
        name: 'Brian Harris',
        email: 'brian.harris@example.com'
      },
      {
        name: 'Jennifer Lopez',
        email: 'jennifer.lopez@example.com'
      },
      {
        name: 'Steven Moore',
        email: 'steven.moore@example.com'
      }
    ]
  },
  {
    title: 'Product Design Meetup',
    date: new Date('2026-04-25T17:00:00Z'),
    location: 'Design Hub, Seattle',
    category: 'Meetup',
    capacity: 60,
    organizer: 'UX Designers Seattle',
    description: 'Monthly meetup for product designers to discuss UI/UX trends, tools, and share portfolio work',
    status: 'Upcoming',
    participants: [
      {
        name: 'Nicole Taylor',
        email: 'nicole.taylor@example.com'
      },
      {
        name: 'Andrew Martinez',
        email: 'andrew.martinez@example.com'
      }
    ]
  }
];

// Connect to MongoDB and insert events
async function insertEvents() {
  let mongod;
  
  // MongoDB connection string
  const MONGODB_URI = process.env.MONGODB_URI || 'mongodb://localhost:27017/event-management';
  
  console.log('🔌 Connecting to MongoDB...');
  
  try {
    // Try real MongoDB first
    await mongoose.connect(MONGODB_URI, { serverSelectionTimeoutMS: 3000 });
    console.log('✓ Connected to MongoDB successfully');
    console.log('✓ Using REAL MongoDB connection\n');
  } catch (error) {
    // Fallback to in-memory MongoDB
    console.log('⚠️  Could not connect to MongoDB server');
    console.log('🚀 Starting in-memory MongoDB...\n');
    
    try {
      mongod = await MongoMemoryServer.create();
      const uri = mongod.getUri();
      await mongoose.connect(uri);
      
      console.log('✓ Connected to in-memory MongoDB successfully');
      console.log('⚠️  Note: Data is temporary\n');
    } catch (memError) {
      console.error('✗ Failed to start in-memory MongoDB:', memError.message);
      process.exit(1);
    }
  }
  
  try {
    
    // Clear existing events (optional - comment out if you want to keep existing data)
    console.log('🗑️  Clearing existing events...');
    await Event.deleteMany({});
    console.log('✓ Existing events cleared\n');
    
    // Insert sample events
    console.log('📝 Inserting sample events...');
    const insertedEvents = await Event.insertMany(sampleEvents);
    
    console.log(`✓ Successfully inserted ${insertedEvents.length} events!\n`);
    
    // Display inserted events
    console.log('📋 Inserted Events:');
    console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n');
    
    insertedEvents.forEach((event, index) => {
      console.log(`${index + 1}. ${event.title}`);
      console.log(`   ID: ${event._id}`);
      console.log(`   Category: ${event.category}`);
      console.log(`   Date: ${event.date.toISOString().split('T')[0]}`);
      console.log(`   Location: ${event.location}`);
      console.log(`   Capacity: ${event.capacity}`);
      console.log(`   Participants: ${event.participants.length}/${event.capacity}`);
      console.log(`   Available Seats: ${event.capacity - event.participants.length}`);
      console.log('');
    });
    
    console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
    console.log('\n✅ Database populated successfully!');
    console.log('\n💡 You can now test the API:');
    if (mongod) {
      await mongod.stop();
      console.log('🔌 In-memory MongoDB stopped');
    }
    console.log('   - GET    http://localhost:3000/api/events');
    console.log('   - GET    http://localhost:3000/api/events/:id');
    console.log('   - POST   http://localhost:3000/api/events');
    console.log('   - PUT    http://localhost:3000/api/events/:id');
    console.log('   - DELETE http://localhost:3000/api/events/:id\n');
    
  } catch (error) {
    console.error('\n✗ Error inserting events:', error.message);
    
    if (error.name === 'ValidationError') {
      console.error('\n❌ Validation Errors:');
      Object.values(error.errors).forEach(err => {
        console.error(`   - ${err.message}`);
      });
    }
  } finally {
    // Close database connection
    await mongoose.connection.close();
    console.log('🔌 MongoDB connection closed');
    process.exit(0);
  }
}

// Run the script
console.log('═══════════════════════════════════════════════════');
console.log('   EVENT MANAGEMENT SYSTEM - DATA INSERTION');
console.log('═══════════════════════════════════════════════════\n');

insertEvents();
