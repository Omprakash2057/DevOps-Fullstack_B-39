const express = require('express');
const router = express.Router();
const Event = require('../models/Event');
const mongoose = require('mongoose');

/**
 * UTILITY FUNCTION: Validate ObjectId
 * Handles invalid ObjectId errors before querying database
 */
const isValidObjectId = (id) => {
  return mongoose.Types.ObjectId.isValid(id);
};

/**
 * CREATE OPERATION
 * POST /api/events
 * Demonstrates: save() method and schema validation
 */
router.post('/', async (req, res) => {
  try {
    // Create new event instance
    const event = new Event(req.body);
    
    // save() method - saves the document to database
    // Triggers all validators defined in schema
    const savedEvent = await event.save();
    
    res.status(201).json({
      success: true,
      message: 'Event created successfully',
      data: savedEvent
    });
  } catch (error) {
    // Handle validation errors
    if (error.name === 'ValidationError') {
      const messages = Object.values(error.errors).map(err => err.message);
      return res.status(400).json({
        success: false,
        error: 'Validation Error',
        messages: messages
      });
    }
    
    res.status(500).json({
      success: false,
      error: 'Server Error',
      message: error.message
    });
  }
});

/**
 * READ OPERATION - Get All Events with Pagination and Filtering
 * GET /api/events
 * Query params: page, limit, category, status, search, sortBy, order
 * 
 * Demonstrates:
 * - find() method
 * - Pagination implementation
 * - Filtering
 * - Sorting
 * - Text search
 */
router.get('/', async (req, res) => {
  try {
    // Extract query parameters
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 10;
    const skip = (page - 1) * limit;
    
    // Build filter object
    const filter = {};
    
    // Filter by category
    if (req.query.category) {
      filter.category = req.query.category;
    }
    
    // Filter by status
    if (req.query.status) {
      filter.status = req.query.status;
    }
    
    // Filter by date range
    if (req.query.startDate || req.query.endDate) {
      filter.date = {};
      if (req.query.startDate) {
        filter.date.$gte = new Date(req.query.startDate);
      }
      if (req.query.endDate) {
        filter.date.$lte = new Date(req.query.endDate);
      }
    }
    
    // Text search (searches title and description)
    if (req.query.search) {
      filter.$text = { $search: req.query.search };
    }
    
    // Build sort object
    const sortBy = req.query.sortBy || 'date';
    const order = req.query.order === 'desc' ? -1 : 1;
    const sort = { [sortBy]: order };
    
    // find() method - retrieves documents matching filter
    // Chaining: skip(), limit(), sort()
    const events = await Event.find(filter)
      .sort(sort)
      .skip(skip)
      .limit(limit)
      .select('-__v'); // Exclude version key
    
    // Get total count for pagination
    const total = await Event.countDocuments(filter);
    
    res.json({
      success: true,
      data: events,
      pagination: {
        page,
        limit,
        total,
        pages: Math.ceil(total / limit),
        hasMore: page * limit < total
      }
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: 'Server Error',
      message: error.message
    });
  }
});

/**
 * READ OPERATION - Get Single Event by ID
 * GET /api/events/:id
 * 
 * Demonstrates:
 * - findById() method
 * - Invalid ObjectId handling
 * - Missing document handling
 */
router.get('/:id', async (req, res) => {
  try {
    const { id } = req.params;
    
    // Validate ObjectId format
    if (!isValidObjectId(id)) {
      return res.status(400).json({
        success: false,
        error: 'Invalid ID',
        message: 'The provided ID is not a valid MongoDB ObjectId'
      });
    }
    
    // findById() method - finds document by _id
    const event = await Event.findById(id).select('-__v');
    
    // Handle missing document
    if (!event) {
      return res.status(404).json({
        success: false,
        error: 'Not Found',
        message: `Event with ID ${id} not found`
      });
    }
    
    res.json({
      success: true,
      data: event
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: 'Server Error',
      message: error.message
    });
  }
});

/**
 * UPDATE OPERATION
 * PUT /api/events/:id
 * 
 * Demonstrates:
 * - findByIdAndUpdate() method
 * - Options: new (return updated doc), runValidators (run schema validation)
 * - Invalid ObjectId handling
 * - Missing document handling
 */
router.put('/:id', async (req, res) => {
  try {
    const { id } = req.params;
    
    // Validate ObjectId format
    if (!isValidObjectId(id)) {
      return res.status(400).json({
        success: false,
        error: 'Invalid ID',
        message: 'The provided ID is not a valid MongoDB ObjectId'
      });
    }
    
    // findByIdAndUpdate() method
    // Options:
    // - new: true => returns updated document instead of original
    // - runValidators: true => runs schema validators on update
    const updatedEvent = await Event.findByIdAndUpdate(
      id,
      req.body,
      { 
        new: true,           // Return updated document
        runValidators: true  // Run schema validation
      }
    ).select('-__v');
    
    // Handle missing document
    if (!updatedEvent) {
      return res.status(404).json({
        success: false,
        error: 'Not Found',
        message: `Event with ID ${id} not found`
      });
    }
    
    res.json({
      success: true,
      message: 'Event updated successfully',
      data: updatedEvent
    });
  } catch (error) {
    // Handle validation errors
    if (error.name === 'ValidationError') {
      const messages = Object.values(error.errors).map(err => err.message);
      return res.status(400).json({
        success: false,
        error: 'Validation Error',
        messages: messages
      });
    }
    
    res.status(500).json({
      success: false,
      error: 'Server Error',
      message: error.message
    });
  }
});

/**
 * PARTIAL UPDATE OPERATION
 * PATCH /api/events/:id
 * 
 * Demonstrates: Partial update with validation
 */
router.patch('/:id', async (req, res) => {
  try {
    const { id } = req.params;
    
    // Validate ObjectId format
    if (!isValidObjectId(id)) {
      return res.status(400).json({
        success: false,
        error: 'Invalid ID',
        message: 'The provided ID is not a valid MongoDB ObjectId'
      });
    }
    
    // Partial update with validation
    const updatedEvent = await Event.findByIdAndUpdate(
      id,
      { $set: req.body },
      { 
        new: true,
        runValidators: true
      }
    ).select('-__v');
    
    if (!updatedEvent) {
      return res.status(404).json({
        success: false,
        error: 'Not Found',
        message: `Event with ID ${id} not found`
      });
    }
    
    res.json({
      success: true,
      message: 'Event updated successfully',
      data: updatedEvent
    });
  } catch (error) {
    if (error.name === 'ValidationError') {
      const messages = Object.values(error.errors).map(err => err.message);
      return res.status(400).json({
        success: false,
        error: 'Validation Error',
        messages: messages
      });
    }
    
    res.status(500).json({
      success: false,
      error: 'Server Error',
      message: error.message
    });
  }
});

/**
 * DELETE OPERATION
 * DELETE /api/events/:id
 * 
 * Demonstrates:
 * - findByIdAndDelete() method
 * - Invalid ObjectId handling
 * - Missing document handling
 */
router.delete('/:id', async (req, res) => {
  try {
    const { id } = req.params;
    
    // Validate ObjectId format
    if (!isValidObjectId(id)) {
      return res.status(400).json({
        success: false,
        error: 'Invalid ID',
        message: 'The provided ID is not a valid MongoDB ObjectId'
      });
    }
    
    // findByIdAndDelete() method - finds and removes document
    const deletedEvent = await Event.findByIdAndDelete(id);
    
    // Handle missing document
    if (!deletedEvent) {
      return res.status(404).json({
        success: false,
        error: 'Not Found',
        message: `Event with ID ${id} not found`
      });
    }
    
    res.json({
      success: true,
      message: 'Event deleted successfully',
      data: deletedEvent
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: 'Server Error',
      message: error.message
    });
  }
});

/**
 * SPECIAL OPERATIONS
 */

// Get upcoming events
router.get('/special/upcoming', async (req, res) => {
  try {
    const events = await Event.findUpcoming();
    res.json({
      success: true,
      data: events
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: 'Server Error',
      message: error.message
    });
  }
});

// Add participant to event
router.post('/:id/participants', async (req, res) => {
  try {
    const { id } = req.params;
    
    if (!isValidObjectId(id)) {
      return res.status(400).json({
        success: false,
        error: 'Invalid ID',
        message: 'The provided ID is not a valid MongoDB ObjectId'
      });
    }
    
    const event = await Event.findById(id);
    
    if (!event) {
      return res.status(404).json({
        success: false,
        error: 'Not Found',
        message: `Event with ID ${id} not found`
      });
    }
    
    await event.addParticipant(req.body);
    
    res.json({
      success: true,
      message: 'Participant added successfully',
      data: event
    });
  } catch (error) {
    if (error.message === 'Event is at full capacity') {
      return res.status(400).json({
        success: false,
        error: 'Capacity Error',
        message: error.message
      });
    }
    
    res.status(500).json({
      success: false,
      error: 'Server Error',
      message: error.message
    });
  }
});

module.exports = router;
