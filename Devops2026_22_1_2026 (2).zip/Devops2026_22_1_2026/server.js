require('dotenv').config();
const express = require('express');
const mongoose = require('mongoose');
const { MongoMemoryServer } = require('mongodb-memory-server');
const eventRoutes = require('./routes/events');

const app = express();

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Request logging
app.use((req, res, next) => {
  console.log(`${new Date().toISOString()} - ${req.method} ${req.path}`);
  next();
});

// Start server with MongoDB (try real MongoDB first, fallback to in-memory)
async function startServer() {
  try {
    const MONGODB_URI = process.env.MONGODB_URI || 'mongodb://localhost:27017/event-management';
    
    console.log('🔌 Attempting to connect to MongoDB...');
    
    // Try connecting to real MongoDB first
    try {
      await mongoose.connect(MONGODB_URI, { serverSelectionTimeoutMS: 3000 });
      console.log('✓ Connected to MongoDB successfully');
      console.log(`✓ Database: ${mongoose.connection.name}`);
      console.log('✓ Using REAL MongoDB connection\n');
    } catch (error) {
      // If real MongoDB fails, use in-memory server
      console.log('⚠️  Could not connect to MongoDB server');
      console.log('🚀 Starting in-memory MongoDB instead...\n');
      
      const mongod = await MongoMemoryServer.create();
      const uri = mongod.getUri();
      await mongoose.connect(uri);
      
      console.log('✓ Connected to in-memory MongoDB successfully');
      console.log('✓ Database: event-management (stored in RAM)');
      console.log('⚠️  Note: Data is temporary - Use MongoDB Atlas for permanent storage\n');
      
      // Store reference for cleanup
      app.locals.mongod = mongod;
    }
    
    // Routes
    app.use('/api/events', eventRoutes);
    
    // Root route
    app.get('/', (req, res) => {
      const dbType = app.locals.mongod ? 'In-Memory (Temporary)' : 'MongoDB Server';
      res.json({
        message: 'Event Management System API',
        version: '1.0.0',
        database: dbType,
        endpoints: {
          'GET /api/events': 'Get all events (with pagination & filtering)',
          'GET /api/events/:id': 'Get event by ID',
          'POST /api/events': 'Create new event',
          'PUT /api/events/:id': 'Update event (full update)',
          'PATCH /api/events/:id': 'Update event (partial update)',
          'DELETE /api/events/:id': 'Delete event',
          'GET /api/events/special/upcoming': 'Get upcoming events',
          'POST /api/events/:id/participants': 'Add participant to event'
        }
      });
    });
    
    // 404 Handler
    app.use((req, res) => {
      res.status(404).json({
        success: false,
        error: 'Not Found',
        message: `Route ${req.method} ${req.path} not found`
      });
    });
    
    // Global Error Handler
    app.use((error, req, res, next) => {
      console.error('Error:', error);
      
      if (error.code === 11000) {
        return res.status(400).json({
          success: false,
          error: 'Duplicate Error',
          message: 'A record with this value already exists'
        });
      }
      
      if (error.name === 'CastError') {
        return res.status(400).json({
          success: false,
          error: 'Invalid Data',
          message: `Invalid ${error.path}: ${error.value}`
        });
      }
      
      res.status(500).json({
        success: false,
        error: 'Internal Server Error',
        message: error.message || 'Something went wrong'
      });
    });
    
    // Start server
    const PORT = process.env.PORT || 3000;
    app.listen(PORT, () => {
      console.log(`✓ Server is running on port ${PORT}`);
      console.log(`✓ API available at http://localhost:${PORT}`);
      console.log(`✓ Test the API using API_TESTS.http file\n`);
      
      if (!app.locals.mongod) {
        console.log('💡 Connected to real MongoDB - Data will persist!');
      } else {
        console.log('💡 To use real MongoDB:');
        console.log('   1. Install MongoDB locally OR');
        console.log('   2. Use MongoDB Atlas (free): https://www.mongodb.com/cloud/atlas');
        console.log('   3. Add connection string to .env file\n');
      }
    });
    
    // Graceful shutdown
    process.on('SIGINT', async () => {
      console.log('\nShutting down gracefully...');
      await mongoose.connection.close();
      if (app.locals.mongod) {
        await app.locals.mongod.stop();
      }
      console.log('MongoDB connection closed');
      process.exit(0);
    });
    
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

startServer();
