const mongoose = require('mongoose');

/**
 * Event Schema with built-in Mongoose validation
 * Demonstrates schema-level validation for:
 * - Required fields
 * - Data types
 * - String length constraints
 * - Date validation
 * - Enum validation
 * - Custom validators
 */
const eventSchema = new mongoose.Schema({
  title: {
    type: String,
    required: [true, 'Event title is required'],
    trim: true,
    minlength: [3, 'Title must be at least 3 characters long'],
    maxlength: [100, 'Title cannot exceed 100 characters']
  },
  
  date: {
    type: Date,
    required: [true, 'Event date is required'],
    validate: {
      validator: function(value) {
        // Ensure event date is not in the past
        return value >= new Date();
      },
      message: 'Event date cannot be in the past'
    }
  },
  
  location: {
    type: String,
    required: [true, 'Event location is required'],
    trim: true,
    minlength: [3, 'Location must be at least 3 characters long']
  },
  
  participants: [{
    name: {
      type: String,
      required: [true, 'Participant name is required'],
      trim: true
    },
    email: {
      type: String,
      required: [true, 'Participant email is required'],
      trim: true,
      lowercase: true,
      validate: {
        validator: function(value) {
          // Email validation regex
          return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value);
        },
        message: 'Invalid email format'
      }
    },
    registeredAt: {
      type: Date,
      default: Date.now
    }
  }],
  
  category: {
    type: String,
    required: [true, 'Event category is required'],
    enum: {
      values: ['Conference', 'Workshop', 'Seminar', 'Meetup', 'Webinar', 'Concert', 'Sports', 'Other'],
      message: '{VALUE} is not a valid category'
    }
  },
  
  capacity: {
    type: Number,
    required: [true, 'Event capacity is required'],
    min: [1, 'Capacity must be at least 1'],
    max: [10000, 'Capacity cannot exceed 10000'],
    validate: {
      validator: Number.isInteger,
      message: 'Capacity must be an integer'
    }
  },
  
  description: {
    type: String,
    trim: true,
    maxlength: [1000, 'Description cannot exceed 1000 characters']
  },
  
  status: {
    type: String,
    enum: ['Upcoming', 'Ongoing', 'Completed', 'Cancelled'],
    default: 'Upcoming'
  },
  
  organizer: {
    type: String,
    required: [true, 'Organizer name is required'],
    trim: true
  }
}, {
  timestamps: true // Adds createdAt and updatedAt fields automatically
});

// Index for better query performance
eventSchema.index({ date: 1, category: 1 });
eventSchema.index({ title: 'text', description: 'text' }); // Text search

// Virtual property: available seats
eventSchema.virtual('availableSeats').get(function() {
  return this.capacity - this.participants.length;
});

// Instance method: Add participant
eventSchema.methods.addParticipant = function(participantData) {
  if (this.participants.length >= this.capacity) {
    throw new Error('Event is at full capacity');
  }
  this.participants.push(participantData);
  return this.save();
};

// Instance method: Remove participant
eventSchema.methods.removeParticipant = function(email) {
  this.participants = this.participants.filter(p => p.email !== email);
  return this.save();
};

// Static method: Find upcoming events
eventSchema.statics.findUpcoming = function() {
  return this.find({ 
    date: { $gte: new Date() },
    status: 'Upcoming'
  }).sort({ date: 1 });
};

const Event = mongoose.model('Event', eventSchema);

module.exports = Event;
