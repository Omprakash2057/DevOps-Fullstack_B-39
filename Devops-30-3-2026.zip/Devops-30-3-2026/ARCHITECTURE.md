# Architecture Overview Document

## System Components

This document provides a detailed overview of the logging system architecture.

### 1. Web Application (Node.js)

**File**: `app/index.js`  
**Docker Image**: `node:18-alpine`  
**Port**: 3000

#### Responsibilities:
- Serve API endpoints
- Generate structured JSON logs
- Track requests with trace IDs
- Record metadata (user agent, IP, response time)
- Emit logs to stdout

#### Key Features:
- Express.js framework
- Winston logger with JSON formatting
- Request middleware for tracing
- Health check endpoint
- Error simulation endpoints

#### Log Output Format:
```json
{
  "timestamp": "ISO8601",
  "level": "INFO|WARN|ERROR|DEBUG",
  "message": "Human readable message",
  "service_name": "web-app",
  "container_name": "web-app-container",
  "trace_id": "UUID",
  "metadata": {
    "method": "GET",
    "path": "/api/users",
    "status_code": 200,
    "response_time_ms": 45
  }
}
```

#### Endpoints:
- `GET /` - Home page
- `GET /health` - Health check
- `GET /api/users` - Get all users
- `GET /api/user/:id` - Get user by ID
- `POST /api/error-simulator` - Simulate errors
- `POST /api/warning-simulator` - Simulate warnings
- `GET /api/database/query` - Simulate database query

---

### 2. Fluentd (Log Collector)

**Files**: `fluentd/fluent.conf`, `fluentd/config.d/`  
**Docker Image**: `fluent/fluentd:v1.16-1`  
**Port**: 24224 (TCP/UDP)

#### Responsibilities:
- Receive logs from Docker daemon
- Parse JSON formatted logs
- Enrich logs with metadata
- Buffer logs for reliability
- Forward to Elasticsearch
- Handle log rotation

#### Architecture:
```
Input Source (Docker)
        ↓
    Fluentd Process
        ↓
    Parsing & Enrichment
        ↓
    Buffering
        ↓
    Output (Elasticsearch)
```

#### Configuration Files:
- `fluent.conf` - Main configuration, defines input ports
- `01-docker.conf` - Docker log parsing and forwarding
- `02-nginx.conf` - Nginx log collection (optional)
- `99-catchall.conf` - Fallback for unmatched logs

#### Plugin Stack:
- `in_forward` - Receive Docker logs
- `filter_parser` - Parse JSON
- `filter_record_transformer` - Add metadata
- `out_elasticsearch` - Send to Elasticsearch

#### Buffer Strategy:
- **Type**: File-based for durability
- **Chunk Limit**: 256MB per file
- **Queue Limit**: 32 pending chunks
- **Flush Interval**: 10 seconds

---

### 3. Elasticsearch (Store)

**Docker Image**: `docker.io/library/elasticsearch:8.5.0`  
**Port**: 9200  
**Storage**: Docker volume `elasticsearch-data`

#### Responsibilities:
- Index and store all logs
- Provide full-text search
- Handle aggregations and analytics
- Manage data lifecycle
- Provide REST API

#### Data Structure:
```
├── Cluster
│   ├── Node 1
│   │   ├── Index: docker-logs-2026.04.08
│   │   │   ├── Shard 0 (Primary)
│   │   │   ├── Shard 1 (Replica)
│   │   │   └── Documents: 50000+
│   │   ├── Index: nginx-access-2026.04.08
│   │   └── Index: nginx-error-2026.04.08
│   └── Node 2 (replicas)
```

#### Index Naming Convention:
- `docker-logs-YYYY.MM.DD` - Application logs
- `nginx-access-YYYY.MM.DD` - Nginx access logs
- `nginx-error-YYYY.MM.DD` - Nginx error logs
- `fluentd-catchall-YYYY.MM.DD` - Other logs

#### Performance Characteristics:
- **Ingestion Rate**: 10,000 logs/minute
- **Query Response Time**: <500ms (for typical queries)
- **Storage Efficiency**: ~100 bytes/log average
- **Memory Usage**: 512MB - 1.5GB (with 256m-256m heap)

---

### 4. Kibana (Visualization)

**Docker Image**: `docker.io/library/kibana:8.5.0`  
**Port**: 5601

#### Responsibilities:
- Provide web UI for log search
- Create visualizations
- Build dashboards
- Configure alerting
- Manage index patterns

#### Main Features:
1. **Discover Tab** - Search and explore logs
2. **Visualizations** - Create charts and graphs
3. **Dashboards** - Combine visualizations
4. **Stack Management** - Configure indices and settings
5. **Dev Tools** - Console for advanced queries

#### Index Pattern:
- `docker-logs-*` - Matches all daily indices
- Time field: `@timestamp` or `timestamp`
- Timezone: Auto-detected from browser

---

### 5. Nginx (Reverse Proxy)

**Docker Image**: `nginx:1.24-alpine`  
**Port**: 80, 443

#### Responsibilities:
- Route external requests to web app
- Load balance multiple app instances
- Handle SSL/TLS termination
- Log HTTP request/response
- Cache static assets

#### Configuration:
- Upstream pool: web-app:3000
- Keepalive: 32 connections
- Log format: JSON for easy parsing
- Proxy timeouts: 60s

---

## Data Flow Diagram

```
┌─────────────────────────────────────────────────────────────────┐
│                     EXTERNAL REQUEST                            │
│                    (e.g., curl, browser)                        │
└──────────────────────────┬──────────────────────────────────────┘
                           │
                           ▼
                    ┌─────────────┐
                    │ Nginx :80   │
                    │ (Reverse    │
                    │  Proxy)     │
                    └──────┬──────┘
                           │
                           ▼
                    ┌─────────────────────┐
                    │ Web App             │
                    │ (Node.js :3000)     │
                    │                     │
                    │ - Process request   │
                    │ - Generate logs     │
                    │ - Send to stdout    │
                    └──────┬──────────────┘
                           │
                ┌──────────┴──────────┐
                │                     │
                ▼ stdout/stderr        ▼ http response
        ┌──────────────────┐   ┌──────────────────┐
        │  Docker Engine   │   │  Nginx -> Client │
        │  Logging Driver  │   └──────────────────┘
        │  (json-file)     │
        └────────┬─────────┘
                 │
      ┌──────────▼──────────────┐
      │   Docker Forward API    │
      │ Listener: localhost:24224
      └──────────┬──────────────┘
                 │
                 ▼
        ┌──────────────────┐
        │  Fluentd :24224  │
        │                  │
        │ - Receive logs   │
        │ - Parse JSON     │
        │ - Add metadata   │
        │ - Buffer data    │
        └────────┬─────────┘
                 │
                 ▼
        ┌──────────────────────────┐
        │  Elasticsearch :9200     │
        │                          │
        │ - Index logs             │
        │ - Store in indices       │
        │ - Maintain shards        │
        │ - Replicate data         │
        └────────┬─────────────────┘
                 │
                 ▼
        ┌──────────────────┐
        │  Kibana :5601    │
        │                  │
        │ - Query ES API   │
        │ - Display UI     │
        │ - Create visuals │
        └──────────────────┘
                 │
                 ▼
        ┌──────────────────┐
        │  User/Dashboard  │
        │  (Analytics)     │
        └──────────────────┘
```

## Network Communication

### Service-to-Service Links:

1. **Web App → Nginx**: Not used (external traffic only)
2. **Docker → Fluentd**: TCP 24224 (docker logging driver)
3. **Fluentd → Elasticsearch**: HTTP 9200 (bulk indexing)
4. **Kibana → Elasticsearch**: HTTP 9200 (queries)
5. **Client → Nginx**: HTTP 80, HTTPS 443
6. **Client → Web App**: Internal via Nginx
7. **Client → Kibana**: Direct HTTP 5601

### Docker Network:
- Name: `logging-network`
- Type: bridge
- Subnet: Default (172.16+)
- Service discovery: Docker DNS

---

## Data Storage

### Volumes:

1. **elasticsearch-data**
   - Persistent storage for Elasticsearch
   - Contains indices and shards
   - Size growth: ~1GB per 10M logs
   - Backup: Essential for recovery

2. **fluentd-buffer**
   - Temporary log buffering
   - File-based queue
   - Survives Fluentd restarts
   - Auto-cleanup after flush

### Data Lifecycle:

```
Logs Created (App)
    ↓ (real-time)
Fluentd Buffer
    ↓ (10-60 seconds)
Elasticsearch Index
    ↓ (daily rotation)
Index Management Policy (ILM)
    ├─ Hot Phase (0-30 days): Searchable
    ├─ Warm Phase (30-90 days): Read-only, lower priority
    ├─ Cold Phase (90-365 days): Archived
    └─ Delete Phase (365+ days): Permanent deletion
```

---

## Scalability

### Horizontal Scaling:

```
Load: 1,000 logs/second

Option 1: Multiple Fluentd Instances
├── Fluentd-1 (Primary)    ← 400 logs/sec
├── Fluentd-2 (Secondary)  ← 300 logs/sec
└── Fluentd-3 (Tertiary)   ← 300 logs/sec

Option 2: Elasticsearch Cluster
├── Elasticsearch-1 (Master)    4GB RAM
├── Elasticsearch-2 (Data)      4GB RAM
└── Elasticsearch-3 (Data)      4GB RAM
```

### Throughput Expectations:

| Component | Development | Production |
|-----------|-------------|-----------|
| Fluentd | 1,000 logs/s | 10,000 logs/s |
| Elasticsearch | 5,000 logs/s | 50,000+ logs/s |
| Kibana queries | <1 minute range | <1 hour range |

---

## Security Layers

### Current (Development):
- No authentication required
- HTTP only
- Default ports exposed
- Single host access

### Recommended (Production):
1. **Authentication**: Elasticsearch, Kibana, Fluentd credentials
2. **Encryption**: TLS for all communication
3. **Network**: Private Docker network, VPN access only
4. **Access Control**: RBAC for Kibana users
5. **Audit**: Log all administrative actions
6. **Data Privacy**: Mask sensitive fields before logging

---

## Monitoring and Observability

### Metrics to Monitor:

1. **Fluentd**:
   - Buffer queue depth
   - Flush latency
   - Connection status

2. **Elasticsearch**:
   - Cluster health (green/yellow/red)
   - JVM heap usage
   - Disk usage
   - Indexing rate

3. **Kibana**:
   - Query response time
   - User sessions

4. **Application**:
   - Request rate
   - Error rate
   - Response time (p50, p95, p99)

### Alerting Thresholds:

- JVM Memory > 90% → Alert
- Cluster Status Red → Critical Alert
- Disk Space < 10% → Alert
- Ingestion Lag > 5 minutes → Warning
- Error Rate > 5% → Alert

---

## Disaster Recovery

### Backup Strategy:

1. **Daily Snapshots**: Elasticsearch indices to S3
2. **Transaction Logs**: Fluentd buffer to secondary storage
3. **Configuration**: Version control (git)
4. **Recovery Time Objective (RTO)**: < 1 hour
5. **Recovery Point Objective (RPO)**: < 5 minutes

### Failover:

```
Primary Failure
    ↓
Health Check fails (30 seconds)
    ↓
Promote Secondary
    ↓ (or restore from snapshot)
Resume Operations
```

---

## Performance Optimization

### Tuning Parameters:

1. **Elasticsearch Heap**: Based on available RAM
2. **Fluentd Buffer Size**: Match ingestion peaks
3. **Index Refresh Interval**: Balance freshness vs. performance
4. **Number of Shards**: Based on query workload
5. **Retention Period**: Balance storage vs. compliance

### Common Bottlenecks:

- Elasticsearch heap memory
- Network I/O (Fluentd ↔ Elasticsearch)
- Disk I/O (index writes)
- Kibana query complexity

### Solutions:

- Increase resources
- Add caching
- Optimize queries
- Archive old indices
- Use ILM policies

---

For implementation details, see [README.md](README.md)  
For production deployment, see [DEPLOYMENT.md](DEPLOYMENT.md)
