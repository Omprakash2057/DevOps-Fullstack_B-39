# Project Reference Guide

Complete command reference and port information for the logging system.

## 📍 Service URLs & Access Points

| Service | URL | Port | Purpose | Login |
|---------|-----|------|---------|-------|
| **Web Application** | http://localhost:3000 | 3000 | Sample app + logs | N/A |
| **Elasticsearch API** | http://localhost:9200 | 9200 | Log storage & query | N/A |
| **Kibana Dashboard** | http://localhost:5601 | 5601 | Log visualization | N/A |
| **Nginx Proxy** | http://localhost:80 | 80 | Reverse proxy | N/A |
| **Fluentd Monitor** | http://localhost:24220 | 24220 | Fluentd API | N/A |
| **Docker Logs** | Docker daemon | 24224 | Log input (TCP/UDP) | N/A |

## 🔌 Internal Service Communication

```
Web App :3000              ← Logs stdout/stderr
    ↓
Docker Logging Driver      ← Receives logs
    ↓
Fluentd :24224            ← Collects & processes
    ↓
Elasticsearch :9200       ← Indexes & stores
    ↓
Kibana :5601              ← Queries & visualizes
```

## 💻 Essential Commands

### Getting Started

```bash
# Navigate to project
cd Devops-30-3-2026

# Make scripts executable (Linux/Mac)
chmod +x scripts/*.sh

# Start everything
./scripts/setup.sh
# or manually
docker-compose build
docker-compose up -d

# Wait for startup
sleep 30

# Verify all containers running
docker-compose ps
```

### Testing & Generating Logs

```bash
# Run automated tests
./scripts/test-logging.sh

# Manual API calls
## Home page
curl http://localhost:3000/

## Health check
curl http://localhost:3000/health

## Get users
curl http://localhost:3000/api/users

## Create error log
curl -X POST http://localhost:3000/api/error-simulator?type=database_error

## Create warning log
curl -X POST http://localhost:3000/api/warning-simulator?type=slow_query

## Test 404 error
curl http://localhost:3000/api/user/999

## Simulate database query
curl http://localhost:3000/api/database/query
```

### Viewing Logs

```bash
# Real-time container logs
docker-compose logs -f web-app      # Just web app
docker-compose logs -f fluentd      # Just fluentd
docker-compose logs -f              # All services

# Historical logs
docker-compose logs web-app --tail 50

# Check specific container
docker logs web-app

# Export logs to file
docker-compose logs > logs.txt
```

### Container Management

```bash
# Stop all containers
docker-compose stop

# Stop specific container
docker-compose stop web-app

# Start containers
docker-compose start
docker-compose up -d

# Restart
docker-compose restart web-app

# Remove containers (keeps volumes)
docker-compose down

# Remove everything (deletes volumes too)
docker-compose down -v

# Access container shell
docker-compose exec web-app bash
docker-compose exec elasticsearch bash
docker-compose exec fluentd bash
```

### Building & Rebuilding

```bash
# Build all images
docker-compose build

# Build specific service
docker-compose build web-app

# Rebuild without cache
docker-compose build --no-cache

# Rebuild and restart
docker-compose build --no-cache web-app && docker-compose up -d web-app
```

### System Information

```bash
# Container status
docker-compose ps

# Container resource usage
docker stats
docker stats web-app

# Container configuration
docker-compose config

# Environment variables
docker-compose exec web-app env

# Container network
docker network ls
docker network inspect logging_logging-network
```

### Diagnostics Scripts

```bash
# Complete system health check
./scripts/system-diagnostics.sh

# Elasticsearch detailed diagnostics
./scripts/elasticsearch-diagnostics.sh

# Fluentd status check
./scripts/fluentd-diagnostics.sh

# Load testing
./scripts/load-test.sh

# Cleanup
./scripts/cleanup.sh
```

## 🔍 Elasticsearch Commands

### Cluster Health

```bash
# Check cluster status
curl http://localhost:9200/_cluster/health

# Pretty print output
curl -s http://localhost:9200/_cluster/health | python3 -m json.tool

# More detailed health
curl http://localhost:9200/_cluster/health?pretty&human
```

### Index Management

```bash
# List all indices
curl http://localhost:9200/_cat/indices?v

# List specific indices
curl http://localhost:9200/_cat/indices?h=index,docs.count,store.size

# Get index mappings
curl http://localhost:9200/docker-logs-2026.04.08/_mapping?pretty

# Create index
curl -X PUT http://localhost:9200/test-index

# Delete index
curl -X DELETE http://localhost:9200/docker-logs-2026.01.*

# Count documents
curl http://localhost:9200/docker-logs-*/_count

# Get statistics
curl http://localhost:9200/_stats
```

### Search

```bash
# Simple match_all (all documents)
curl -X GET "localhost:9200/docker-logs-*/_search"

# Search with query
curl -X GET "localhost:9200/docker-logs-*/_search" \
  -H 'Content-Type: application/json' \
  -d'{
    "query": {
      "match": {
        "message": "error"
      }
    }
  }'

# Filter by log level
curl -X GET "localhost:9200/docker-logs-*/_search" \
  -H 'Content-Type: application/json' \
  -d'{
    "query": {
      "term": {
        "level": "ERROR"
      }
    }
  }'
```

### Shard & Replica Info

```bash
# View shard allocation
curl http://localhost:9200/_cat/shards?v

# View replicas
curl http://localhost:9200/_cat/recovery

# Reallocate shards
curl -X POST "localhost:9200/_cluster/reroute" \
  -H 'Content-Type: application/json' \
  -d'{"commands": [{"allocate": {"index": "docker-logs-2026.04.08", "shard": 0, "node": "node-1"}}]}'
```

## 📊 Kibana URLs & Actions

```
# Main URLs
http://localhost:5601                          - Home
http://localhost:5601/app/discover             - Discover logs
http://localhost:5601/app/visualize            - Create visualization
http://localhost:5601/app/dashboards           - View dashboards
http://localhost:5601/app/management           - Admin/config
http://localhost:5601/app/dev_tools            - Dev console

# Saved searches
http://localhost:5601/app/kibana#/discover

# Saved dashboards
http://localhost:5601/app/kibana#/dashboards
```

### Kibana Setup Steps

1. Create Index Pattern
   - Stack Management → Index Patterns
   - Enter: `docker-logs-*`
   - Time field: `@timestamp`
   - Create index pattern

2. View Logs
   - Discover tab
   - Select index pattern
   - Browse logs

3. Create Visualization
   - Visualize tab
   - Create new visualization
   - Select visualization type
   - Configure data source
   - Save

4. Create Dashboard
   - Dashboards tab
   - Create dashboard
   - Add visualizations
   - Save dashboard

## 🐳 Docker Commands

### Container Inspection

```bash
# Detailed container info
docker inspect web-app

# Specific info formatting
docker inspect -f '{{.Config.Env}}' web-app
docker inspect -f '{{.NetworkSettings.Networks}}' web-app
docker inspect -f '{{.Mounts}}' elasticsearch

# Common port info
docker inspect -f '{{range .NetworkSettings.Ports}}{{.}}{{end}}' web-app
```

### File Operations

```bash
# Copy file from container
docker cp web-app:/app/index.js ./local-copy.js

# Copy file to container
docker cp ./local-file.js web-app:/app/

# View container logs with timestamps
docker logs --timestamps web-app

# Tail logs
docker logs --follow --tail 100 web-app
```

### Networking

```bash
# Inspect Docker network
docker network inspect logging_logging-network

# List all networks
docker network ls

# Connect container to network
docker network connect logging_logging-network container_name

# Disconnect
docker network disconnect logging_logging-network container_name
```

### Resource Management

```bash
# View resource limits
docker inspect web-app | grep -A 10 "HostConfig"

# Set resource limits
docker update --memory=1g --cpus=1.0 web-app

# View current usage
docker stats
docker stats --no-stream
docker stats web-app
```

## 📁 File Structure Reference

```
Devops-30-3-2026/
├── app/                           # Node.js application
│   ├── index.js                  # Main application (routes, log generation)
│   ├── logger.js                 # Logging configuration (JSON format)
│   ├── package.json              # Dependencies (express, winston, uuid)
│   ├── Dockerfile                # Application container definition
│   └── .dockerignore             # Docker build ignore rules
│
├── fluentd/                       # Log collector & forwarder
│   ├── Dockerfile                # Custom Fluentd with plugins
│   ├── fluent.conf               # Main configuration (inputs/outputs)
│   └── config.d/
│       ├── 01-docker.conf        # Docker logs parsing & Elasticsearch output
│       ├── 02-nginx.conf         # Nginx logs parsing (optional)
│       └── 99-catchall.conf      # Fallback for unmatched logs
│
├── nginx/                         # Reverse proxy
│   ├── nginx.conf                # Main nginx configuration
│   ├── conf.d/
│   │   └── default.conf          # Virtual host (upstream, proxy rules)
│   └── ssl/                      # SSL certificates (for production)
│
├── scripts/                       # Automation & diagnostics
│   ├── setup.sh                  # Initial setup wth checks
│   ├── test-logging.sh           # Generate test logs
│   ├── elasticsearch-diagnostics.sh  # ES health & diagnostics
│   ├── fluentd-diagnostics.sh    # Fluentd status check
│   ├── system-diagnostics.sh     # Complete system check
│   ├── cleanup.sh                # Stop and remove containers
│   └── load-test.sh              # Performance load testing
│
├── kibana-dashboards/            # Kibana exports
│   └── (future dashboard JSONs)
│
├── docker-compose.yml            # Multi-container orchestration
│                                 # - Elasticsearch :9200
│                                 # - Kibana :5601
│                                 # - Fluentd :24224
│                                 # - Web App :3000
│                                 # - Nginx :80/:443
│
├── .env.example                  # Environment variables template
├── .gitignore                    # Git ignore rules
├── README.md                     # Complete documentation
├── QUICK_START.md                # Getting started guide
├── DEPLOYMENT.md                 # Production setup guide
├── ARCHITECTURE.md               # System architecture explained
├── TROUBLESHOOTING.md            # Common issues & FAQs
└── REFERENCE.md                  # This file
```

## 🔐 Environment Variables

### Key Variables

```bash
# Elasticsearch
ELASTICSEARCH_HOST=elasticsearch
ELASTICSEARCH_PORT=9200
ES_JAVA_OPTS=-Xms512m -Xmx512m  # Heap size limit

# Kibana
KIBANA_HOST=kibana
KIBANA_PORT=5601

# Fluentd
FLUENTD_CONF=fluent.conf
ELASTICSEARCH_HOST=elasticsearch
ELASTICSEARCH_PORT=9200

# Application
NODE_ENV=production
PORT=3000
LOG_LEVEL=info              # debug, info, warn, error
SERVICE_NAME=web-app
CONTAINER_NAME=web-app-container

# Network
TZ=UTC
```

## 📝 Configuration Files

### Key Configurations

```
app/logger.js
  - Winston logger setup
  - JSON format definition
  - Log levels
  - Transport configuration

app/index.js
  - Express routes
  - Request middleware
  - Log generation calls
  - Error handling

fluentd/fluent.conf
  - Input sources (forward:24224)
  - Monitor agent (port 24220)

fluentd/config.d/01-docker.conf
  - Parser configuration
  - Metadata enrichment
  - Elasticsearch output
  - Buffer settings

fluentd/config.d/99-catchall.conf
  - Fallback log routing
  - Generic Elasticsearch output

nginx/nginx.conf
  - Worker configuration
  - Log format (JSON)
  - GZIP compression

nginx/conf.d/default.conf
  - Upstream definition (web-app:3000)
  - Proxy rules
  - SSL configuration (commented)

docker-compose.yml
  - Service definitions
  - Port mappings
  - Volume mounts
  - Network configuration
  - Logging driver setup
  - Health checks
  - Dependencies
```

## 🎯 Common Workflows

### 1. Start Fresh

```bash
docker-compose down -v      # Remove everything
docker-compose build        # Rebuild images
docker-compose up -d        # Start services
sleep 30                    # Wait for startup
docker-compose ps           # Verify
./scripts/test-logging.sh   # Generate logs
```

### 2. Check Service Status

```bash
docker-compose ps               # Container status
curl http://localhost:9200/_cluster/health  # ES health
curl http://localhost:5601/api/status       # Kibana status
curl http://localhost:3000/health           # App health
```

### 3. View Recent Logs

```bash
# Application logs
docker-compose logs --tail 50 web-app

# All service logs
docker-compose logs --tail 20

# Fluentd logs
docker-compose logs -f fluentd
```

### 4. Check Data in Elasticsearch

```bash
# List indices
curl http://localhost:9200/_cat/indices?v

# Count documents
curl http://localhost:9200/docker-logs-*/_count\?pretty

# See sample document
curl -X GET http://localhost:9200/docker-logs-*/_search?size=1\&pretty
```

### 5. Create Kibana Dashboard

1. Open http://localhost:5601
2. Go to Discover
3. Select index pattern: `docker-logs-*`
4. Build searches
5. Create visualizations
6. Add to dashboard

### 6. Performance Optimization

```bash
# Check memory usage
docker stats

# Reduce Elasticsearch heap (in docker-compose.yml)
# ES_JAVA_OPTS=-Xms256m -Xmx256m

# Delete old indices
curl -X DELETE http://localhost:9200/docker-logs-2026.01.*

# Force merge (optimize)
curl -X POST http://localhost:9200/docker-logs-*/_forcemerge
```

## 🆘 Quick Emergency Commands

```bash
# System not responding
docker-compose restart          # Restart all services
docker-compose down && docker-compose up -d  # Full restart

# Port conflicts
sudo lsof -i :9200             # Find what's using port
kill -9 PID                    # Kill the process

# Disk full
docker system prune -a          # Remove unused images
curl -X DELETE http://localhost:9200/docker-logs-2026.01.*  # Delete old logs

# Memory issues
docker update --memory=1g elasticsearch  # Limit Elasticsearch memory
docker-compose restart                   # Restart

# Lost all logs
## They're gone unless you have backups
## Use snapshots in future:
curl -X PUT http://localhost:9200/_snapshot/backup

# Can't access Kibana
docker-compose logs kibana      # See error
docker-compose restart kibana   # Restart
sleep 10 && curl http://localhost:5601/api/status  # Check status
```

---

**For more detailed information:**
- [README.md](README.md) - Full documentation
- [QUICK_START.md](QUICK_START.md) - Getting started
- [DEPLOYMENT.md](DEPLOYMENT.md) - Production setup
- [ARCHITECTURE.md](ARCHITECTURE.md) - System design
- [TROUBLESHOOTING.md](TROUBLESHOOTING.md) - Common issues

**Official Documentation:**
- [Elasticsearch](https://www.elastic.co/guide/en/elasticsearch/reference/current/)
- [Kibana](https://www.elastic.co/guide/en/kibana/current/)
- [Fluentd](https://docs.fluentd.org/)
- [Docker](https://docs.docker.com/)
