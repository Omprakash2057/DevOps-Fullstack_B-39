const winston = require('winston');
const { v4: uuidv4 } = require('uuid');

// Custom JSON format for structured logging
const jsonFormat = winston.format.combine(
  winston.format.timestamp({ format: 'YYYY-MM-DD HH:mm:ss.SSS' }),
  winston.format.errors({ stack: true }),
  winston.format.json(),
  winston.format.printf((info) => {
    const logObject = {
      timestamp: info.timestamp,
      level: info.level.toUpperCase(),
      message: info.message,
      service_name: process.env.SERVICE_NAME || 'web-app',
      container_name: process.env.CONTAINER_NAME || 'unknown',
      hostname: require('os').hostname(),
      pid: process.pid,
      trace_id: info.trace_id || uuidv4(),
      metadata: info.metadata || {}
    };

    // Add stack trace for errors
    if (info.stack) {
      logObject.stack_trace = info.stack;
    }

    // Add custom fields if present
    if (info.customFields) {
      logObject.metadata = { ...logObject.metadata, ...info.customFields };
    }

    return JSON.stringify(logObject);
  })
);

// Create logger instance
const logger = winston.createLogger({
  format: jsonFormat,
  defaultMeta: { service: 'web-app' },
  transports: [
    new winston.transports.Console({
      format: jsonFormat,
      level: process.env.LOG_LEVEL || 'info'
    })
  ],
  exceptionHandlers: [
    new winston.transports.Console({
      format: jsonFormat
    })
  ]
});

// Helper function to log with metadata
logger.logWithMetadata = function(level, message, metadata = {}) {
  this.log({
    level,
    message,
    metadata,
    timestamp: new Date().toISOString()
  });
};

module.exports = logger;
