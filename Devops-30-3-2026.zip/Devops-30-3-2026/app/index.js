const express = require('express');
const logger = require('./logger');
const { v4: uuidv4 } = require('uuid');
const os = require('os');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware to add trace ID to requests
app.use((req, res, next) => {
  req.traceId = req.headers['x-trace-id'] || uuidv4();
  req.startTime = Date.now();
  next();
});

// Middleware to log requests
app.use((req, res, next) => {
  logger.info(`Incoming request: ${req.method} ${req.path}`, {
    metadata: {
      method: req.method,
      path: req.path,
      ip: req.ip,
      trace_id: req.traceId,
      user_agent: req.get('user-agent')
    }
  });
  
  // Log response
  res.on('finish', () => {
    const duration = Date.now() - req.startTime;
    const logLevel = res.statusCode >= 400 ? 'warn' : 'info';
    logger.log(logLevel, `Request completed: ${req.method} ${req.path}`, {
      metadata: {
        method: req.method,
        path: req.path,
        status_code: res.statusCode,
        response_time_ms: duration,
        trace_id: req.traceId
      }
    });
  });
  
  next();
});

// Routes
app.get('/', (req, res) => {
  logger.info('Home page accessed', {
    metadata: {
      trace_id: req.traceId,
      endpoint: '/'
    }
  });
  res.json({
    message: 'Welcome to Logging Demo App',
    version: '1.0.0',
    timestamp: new Date().toISOString(),
    uptime: process.uptime()
  });
});

app.get('/health', (req, res) => {
  const healthStatus = {
    status: 'healthy',
    timestamp: new Date().toISOString(),
    uptime: process.uptime(),
    memory: process.memoryUsage(),
    hostname: os.hostname()
  };
  
  logger.debug('Health check performed', {
    metadata: {
      trace_id: req.traceId,
      ...healthStatus
    }
  });
  
  res.json(healthStatus);
});

app.get('/api/users', (req, res) => {
  logger.info('Fetching users', {
    metadata: {
      trace_id: req.traceId,
      endpoint: '/api/users'
    }
  });

  const mockUsers = [
    { id: 1, name: 'John Doe', email: 'john@example.com' },
    { id: 2, name: 'Jane Smith', email: 'jane@example.com' },
    { id: 3, name: 'Bob Johnson', email: 'bob@example.com' }
  ];

  res.json({
    success: true,
    count: mockUsers.length,
    data: mockUsers,
    trace_id: req.traceId
  });
});

app.get('/api/user/:id', (req, res) => {
  const userId = req.params.id;
  logger.info('Fetching user details', {
    metadata: {
      trace_id: req.traceId,
      user_id: userId,
      endpoint: `/api/user/${userId}`
    }
  });

  if (isNaN(userId) || userId < 1 || userId > 3) {
    logger.warn('User not found', {
      metadata: {
        trace_id: req.traceId,
        user_id: userId,
        severity: 'WARN'
      }
    });
    return res.status(404).json({
      success: false,
      message: `User ${userId} not found`,
      trace_id: req.traceId
    });
  }

  const mockUsers = {
    1: { id: 1, name: 'John Doe', email: 'john@example.com', created_at: '2025-01-15' },
    2: { id: 2, name: 'Jane Smith', email: 'jane@example.com', created_at: '2025-02-20' },
    3: { id: 3, name: 'Bob Johnson', email: 'bob@example.com', created_at: '2025-03-10' }
  };

  res.json({
    success: true,
    data: mockUsers[userId],
    trace_id: req.traceId
  });
});

app.post('/api/error-simulator', (req, res) => {
  const errorType = req.query.type || 'database_error';
  
  logger.error(`Simulated error triggered: ${errorType}`, {
    metadata: {
      trace_id: req.traceId,
      error_type: errorType,
      severity: 'ERROR',
      timestamp: new Date().toISOString()
    }
  });

  res.status(500).json({
    success: false,
    message: `Simulated ${errorType}`,
    trace_id: req.traceId,
    error: 'This is a test error for logging purposes'
  });
});

app.post('/api/warning-simulator', (req, res) => {
  const warningType = req.query.type || 'performance_warning';
  
  logger.warn(`Simulated warning: ${warningType}`, {
    metadata: {
      trace_id: req.traceId,
      warning_type: warningType,
      severity: 'WARN',
      timestamp: new Date().toISOString()
    }
  });

  res.status(200).json({
    success: true,
    message: `Simulated ${warningType} logged`,
    trace_id: req.traceId
  });
});

app.get('/api/database/query', (req, res) => {
  logger.info('Database query initiated', {
    metadata: {
      trace_id: req.traceId,
      query_type: 'SELECT',
      database: 'postgres',
      table: 'users'
    }
  });

  // Simulate query execution
  setTimeout(() => {
    logger.info('Database query completed successfully', {
      metadata: {
        trace_id: req.traceId,
        query_type: 'SELECT',
        rows_returned: 42,
        execution_time_ms: 150
      }
    });

    res.json({
      success: true,
      rows_affected: 42,
      trace_id: req.traceId
    });
  }, 150);
});

// 404 handler
app.use((req, res) => {
  logger.warn('Endpoint not found', {
    metadata: {
      trace_id: req.traceId,
      method: req.method,
      path: req.path,
      status_code: 404
    }
  });

  res.status(404).json({
    success: false,
    message: 'Endpoint not found',
    trace_id: req.traceId
  });
});

// Error handler
app.use((err, req, res, next) => {
  logger.error('Unhandled error', {
    metadata: {
      trace_id: req.traceId,
      error_message: err.message,
      error_stack: err.stack,
      severity: 'ERROR'
    }
  });

  res.status(500).json({
    success: false,
    message: 'Internal server error',
    trace_id: req.traceId
  });
});

// Start server
app.listen(PORT, () => {
  logger.info(`Application started successfully`, {
    metadata: {
      port: PORT,
      environment: process.env.NODE_ENV || 'development',
      version: '1.0.0',
      hostname: os.hostname()
    }
  });
});

// Graceful shutdown
process.on('SIGTERM', () => {
  logger.info('SIGTERM signal received: closing HTTP server', {
    metadata: {
      severity: 'INFO',
      reason: 'graceful shutdown'
    }
  });
  process.exit(0);
});

process.on('SIGINT', () => {
  logger.info('SIGINT signal received: closing HTTP server', {
    metadata: {
      severity: 'INFO',
      reason: 'graceful shutdown'
    }
  });
  process.exit(0);
});
