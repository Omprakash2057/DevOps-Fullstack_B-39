# Getting Started Guide

## What You're Building

You're building a complete logging infrastructure for Docker containers consisting of:

1. **A Node.js Web Application** that generates structured JSON logs
2. **A Docker container** that runs the application
3. **Fluentd** that collects and processes logs
4. **Elasticsearch** that stores all logs
5. **Kibana** that visualizes and lets you search logs

## System Architecture Simplified

```
Your App logs to stdout
        ↓
Docker's logging driver
        ↓
Fluentd (collects and parses)
        ↓
Elasticsearch (stores)
        ↓
Kibana (you view here)
```

## Installation Steps

### Step 1: Verify Prerequisites

```bash
# Check Docker
docker --version
# Expected: Docker version 20.10+

# Check Docker Compose
docker-compose --version
# Expected: Docker Compose version 1.29+

# Check Git (optional)
git --version

# Check available RAM
# Needed: 4GB+ (2GB for Elasticsearch, 512MB for Kibana, 512MB for Fluentd, 512MB for app)
```

### Step 2: Clone or Download the Project

```bash
# Option 1: Clone from git
git clone <your-repo-url>
cd Devops-30-3-2026

# Option 2: Download and extract
# Download ZIP and extract to your desired location
cd Devops-30-3-2026
```

### Step 3: Make Scripts Executable (Linux/Mac only)

```bash
chmod +x scripts/*.sh
```

### Step 4: Start the System

```bash
# Run the setup script (handles everything)
./scripts/setup.sh

# Or manually:
docker-compose build
docker-compose up -d
```

**Windows Users** (PowerShell):
```powershell
cd Devops-30-3-2026
docker-compose build
docker-compose up -d
# Wait 30 seconds for all services to start
```

### Step 5: Verify Everything Started

```bash
# Check container status
docker-compose ps

# Should show 5 containers as "Up":
# - elasticsearch
# - kibana  
# - fluentd
# - web-app
# - nginx-proxy
```

## First-Time Setup Checklist

- [ ] Docker installed and running
- [ ] Docker Compose installed
- [ ] 4GB+ RAM available
- [ ] Project files downloaded/cloned
- [ ] Scripts made executable (Linux/Mac)
- [ ] `docker-compose up -d` executed
- [ ] All containers are running (`docker-compose ps`)
- [ ] Successful response from `curl http://localhost:3000/`

## Quick Testing

### Test 1: Check Web Application

```bash
curl http://localhost:3000/

# Expected response:
# {"message":"Welcome to Logging Demo App","version":"1.0.0",...}
```

### Test 2: Check Health Endpoint

```bash
curl http://localhost:3000/health

# Expected response:
# {"status":"healthy","timestamp":"...","uptime":...}
```

### Test 3: Generate Test Logs

```bash
./scripts/test-logging.sh

# Or manually:
curl http://localhost:3000/api/users
curl -X POST http://localhost:3000/api/error-simulator?type=test_error
```

### Test 4: View Logs in Kibana

Open browser to: **http://localhost:5601**

1. Wait for Kibana to fully load (may take 5-10 seconds on first visit)
2. You might see a "Create index pattern" prompt
3. Or go to Stack Management > Index Patterns
4. Click "Create index pattern"
5. Type: `docker-logs-*`
6. Select `@timestamp` as time field
7. Click "Create index pattern"
8. Go to "Discover" section
9. You should see logs appearing

## Understanding the Logs

Each log entry is JSON with this structure:

```json
{
  "timestamp": "2026-04-08T10:30:45Z",
  "level": "INFO",              // Log level
  "message": "Request received",
  "service_name": "web-app",
  "container_name": "web-app",
  "hostname": "abc123def456",
  "pid": 1,
  "trace_id": "550e8400-...",   // Unique request ID
  "metadata": {
    "method": "GET",
    "path": "/api/users",
    "status_code": 200,
    "response_time_ms": 45
  }
}
```

**Key Fields to Remember**:
- `level`: ERROR, WARN, INFO, DEBUG
- `message`: Human readable description
- `trace_id`: Links related logs
- `metadata`: Additional context-specific data

## Common First-Time Issues

### Issue: "Connection refused"
```
Error: Cannot connect to port 3000
```

**Solution**: 
- Ensure `docker-compose up -d` finished
- Check: `docker-compose ps` (all containers should be Up)
- Check: `docker-compose logs web-app` for errors
- Wait another 10 seconds and try again

### Issue: Kibana shows "No matching indices"

**Solution**:
1. Make sure web app is generating logs (run test script)
2. Create index pattern (see Test 4 above)
3. Verify Elasticsearch has data: `curl http://localhost:9200/_cat/indices`

### Issue: High memory usage

**Solution**:
```bash
# Check what's using memory
docker stats

# If Elasticsearch is using too much:
# Edit docker-compose.yml and change:
# ES_JAVA_OPTS=-Xms256m -Xmx256m

# Then restart:
docker-compose down
docker-compose up -d
```

## Next Steps

1. **Explore the Code**:
   - Read `app/index.js` to understand the web app
   - Check `fluentd/fluent.conf` to see how logs are processed

2. **Generate More Logs**:
   - Run load test: `./scripts/load-test.sh`
   - Make custom API calls
   - Trigger different error types

3. **Create Kibana Dashboard**:
   - Build visualizations
   - Create a custom dashboard
   - Save useful searches

4. **Add Another Service**:
   - Modify docker-compose.yml
   - Add another app with same logging config
   - Logs are automatically centralized

5. **Explore Advanced Features**:
   - Add custom metadata
   - Implement trace IDs
   - Filter by severity

6. **Prepare for Production**:
   - Read DEPLOYMENT.md
   - Add authentication
   - Set up SSL/TLS
   - Configure backups

## Stop and Cleanup

```bash
# Stop all containers (keeps data)
docker-compose stop

# Stop and remove containers (keeps data)
docker-compose down

# Remove everything including data
docker-compose down -v

# Remove all Docker resources
docker system prune
```

## Accessing Help

```bash
# Run system diagnostics
./scripts/system-diagnostics.sh

# Check Elasticsearch health
./scripts/elasticsearch-diagnostics.sh

# Check Fluentd status
./scripts/fluentd-diagnostics.sh

# Or check individual logs
docker-compose logs elasticsearch
docker-compose logs kibana
docker-compose logs web-app
```

## Common Commands

```bash
# View real-time logs
docker-compose logs -f web-app      # Just web app
docker-compose logs -f               # All services

# Restart a service
docker-compose restart web-app

# Rebuild and restart
docker-compose build web-app
docker-compose up -d web-app

# Connect to a container
docker-compose exec web-app bash
docker-compose exec elasticsearch bash

# View container stats
docker stats

# Clean up resources
docker system prune --all
```

## What Happens When You Run It

1. **docker-compose build**: Creates Docker images from Dockerfiles
2. **docker-compose up**: Starts all containers in order:
   - Elasticsearch (takes 10-15s)
   - Fluentd (takes 5s)
   - Kibana (takes 10-15s)
   - Web App (takes 2-3s)
   - Nginx (takes 1-2s)
3. **Fluentd connects** to Docker daemon and starts receiving logs
4. **Logs flow**: App → Docker → Fluentd → Elasticsearch
5. **Kibana** queries Elasticsearch for visualization

## URL Reference

| Service | URL | Login | Purpose |
|---------|-----|-------|---------|
| Web App | http://localhost:3000 | None | View logs from app |
| Elasticsearch | http://localhost:9200 | None | REST API for logs |
| Kibana | http://localhost:5601 | None | Search and visualize |
| Nginx | http://localhost | None | Reverse proxy (demo) |

## File Overview

```
app/
├── index.js          - Main application code
├── logger.js         - Logging configuration
├── package.json      - Node.js dependencies
└── Dockerfile        - Build instructions

fluentd/            
├── fluent.conf       - Main fluentd config
├── Dockerfile        - Custom fluentd image
└── config.d/         - Additional configurations

nginx/
├── nginx.conf        - Nginx main config
└── conf.d/           - Site configs

scripts/
├── setup.sh          - Initial setup
├── test-logging.sh   - Generate test logs
└── system-diagnostics.sh - Check system health

docker-compose.yml   - Multi-container setup

README.md            - Full documentation
QUICK_START.md       - This file
```

## Tips for Success

✅ **Do**:
- Keep docker-compose up between tests
- Check logs when something doesn't work
- Use trace IDs to track requests
- Create backups of important data
- Read the full README.md for production tips

❌ **Don't**:
- Run multiple instances on same ports
- Log sensitive data (passwords, tokens)
- Restart Docker host frequently
- Fill up disk with old logs
- Skip the production security setup

---

**Success Indicator**: When you can open Kibana, create an index pattern, and see logs in the Discover tab, you've got a working centralized logging system! 🎉

For more details, see [README.md](README.md)
