#!/bin/bash

# Color codes for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Configuration
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
PROJECT_ROOT="$( cd "$SCRIPT_DIR/.." && pwd )"

echo -e "${BLUE}========================================${NC}"
echo -e "${BLUE}  Complete System Diagnostics${NC}"
echo -e "${BLUE}========================================${NC}"
echo ""

echo -e "${YELLOW}Current Time: $(date)${NC}"
echo ""

# Docker status
echo -e "${BLUE}=== Docker Container Status ===${NC}"
docker-compose ps
echo ""

# Elasticsearch status
echo -e "${BLUE}=== Elasticsearch Status ===${NC}"
if curl -s http://localhost:9200/_cluster/health > /dev/null 2>&1; then
    echo -e "${GREEN}✓ Elasticsearch is running${NC}"
    status=$(curl -s http://localhost:9200/_cluster/health)
    echo "$status" | python3 -m json.tool
else
    echo -e "${RED}✗ Elasticsearch is not running${NC}"
fi
echo ""

# Kibana status
echo -e "${BLUE}=== Kibana Status ===${NC}"
if curl -s http://localhost:5601/api/status > /dev/null 2>&1; then
    echo -e "${GREEN}✓ Kibana is running${NC}"
    status=$(curl -s http://localhost:5601/api/status | python3 -c "import sys, json; d=json.load(sys.stdin); print(json.dumps({'state': d['state'], 'version': d.get('version', {}).get('number')}, indent=2))")
    echo "$status"
else
    echo -e "${RED}✗ Kibana is not running${NC}"
fi
echo ""

# Web App status
echo -e "${BLUE}=== Web App Status ===${NC}"
if curl -s http://localhost:3000/health > /dev/null 2>&1; then
    echo -e "${GREEN}✓ Web App is running${NC}"
    health=$(curl -s http://localhost:3000/health)
    echo "$health" | python3 -m json.tool
else
    echo -e "${RED}✗ Web App is not running${NC}"
fi
echo ""

# Docker logs (last 20 lines for each service)
echo -e "${BLUE}=== Recent Logs ===${NC}"
echo ""

for service in elasticsearch kibana fluentd web-app nginx-proxy; do
    echo -e "${YELLOW}$service logs:${NC}"
    docker-compose logs --tail=10 $service 2>/dev/null || echo "Service not found"
    echo ""
done

# Network information
echo -e "${BLUE}=== Network Information ===${NC}"
docker network ls | grep logging-network
echo ""

# Volume information
echo -e "${BLUE}=== Volumes ===${NC}"
docker volume ls | grep -E "elasticsearch|fluentd"
echo ""

echo -e "${BLUE}========================================${NC}"
echo -e "${BLUE}End of Diagnostics Report${NC}"
echo -e "${BLUE}========================================${NC}"
