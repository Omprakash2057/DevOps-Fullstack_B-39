#!/bin/bash

# Color codes for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Configuration
BASE_URL="http://localhost"
API_URL="http://localhost:3000/api"

echo -e "${BLUE}========================================${NC}"
echo -e "${BLUE}  Testing Logging System${NC}"
echo -e "${BLUE}========================================${NC}"
echo ""

# Function to make API call and check status
call_api() {
    local method=$1
    local endpoint=$2
    local description=$3
    
    echo -e "${YELLOW}Testing: $description${NC}"
    echo "  Endpoint: $method $endpoint"
    
    if [ "$method" = "GET" ]; then
        response=$(curl -s -w "\n%{http_code}" "$endpoint")
    else
        response=$(curl -s -X $method -w "\n%{http_code}" "$endpoint")
    fi
    
    http_code=$(echo "$response" | tail -n1)
    body=$(echo "$response" | head -n-1)
    
    echo "  Response Code: $http_code"
    
    if [ "$http_code" -ge 200 ] && [ "$http_code" -lt 300 ]; then
        echo -e "  ${GREEN}✓ Success${NC}"
    else
        echo -e "  ${RED}✗ Failed${NC}"
    fi
    
    echo ""
}

# Test health check
echo -e "${GREEN}=== Health Checks ===${NC}"
echo ""
call_api "GET" "http://localhost:3000/health" "Web Application Health"

# Test home endpoint
echo -e "${GREEN}=== Application Endpoints ===${NC}"
echo ""
call_api "GET" "http://localhost:3000/" "Home Page"

# Test users endpoint
call_api "GET" "$API_URL/users" "Get All Users"

# Test single user endpoint
call_api "GET" "$API_URL/user/1" "Get User by ID"

# Test 404 error
call_api "GET" "$API_URL/user/999" "Test 404 Not Found"

# Test database simulation
echo -e "${GREEN}=== Database Simulation ===${NC}"
echo ""
call_api "GET" "$API_URL/database/query" "Database Query Simulation"

# Simulate errors and warnings
echo -e "${GREEN}=== Error & Warning Simulation ===${NC}"
echo ""
call_api "POST" "$API_URL/error-simulator?type=database_error" "Simulate Database Error"

call_api "POST" "$API_URL/error-simulator?type=connection_timeout" "Simulate Connection Timeout"

call_api "POST" "$API_URL/warning-simulator?type=slow_query" "Simulate Slow Query Warning"

call_api "POST" "$API_URL/warning-simulator?type=high_memory_usage" "Simulate High Memory Warning"

echo -e "${BLUE}========================================${NC}"
echo -e "${BLUE}  Testing Complete!${NC}"
echo -e "${BLUE}========================================${NC}"
echo ""
echo -e "${YELLOW}💡 Tip: Check Kibana for logs at ${BLUE}http://localhost:5601${NC}"
echo ""
