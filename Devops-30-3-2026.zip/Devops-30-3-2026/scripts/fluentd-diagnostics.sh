#!/bin/bash

# Color codes for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

echo -e "${BLUE}========================================${NC}"
echo -e "${BLUE}  Fluentd Status and Diagnostics${NC}"
echo -e "${BLUE}========================================${NC}"
echo ""

# Check if Fluentd is running
if ! curl -s http://localhost:24220/api/plugins.json > /dev/null 2>&1; then
    echo -e "${RED}✗ Fluentd monitor agent is not available${NC}"
    echo "  Make sure Fluentd container is running"
    exit 1
fi

echo -e "${GREEN}✓ Fluentd is running${NC}"
echo ""

# Get Fluentd plugins
echo -e "${BLUE}Fluentd Plugins:${NC}"
curl -s http://localhost:24220/api/plugins.json | python3 -m json.tool
echo ""

# Get Fluentd configuration
echo -e "${BLUE}Fluentd Configuration:${NC}"
docker-compose exec -T fluentd cat /fluentd/etc/fluent.conf
echo ""

# Check Fluentd logs
echo -e "${BLUE}Recent Fluentd Logs:${NC}"
docker-compose logs --tail=20 fluentd
echo ""

echo -e "${BLUE}========================================${NC}"
