#!/bin/bash

# Color codes for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Configuration
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
PROJECT_ROOT="$( cd "$SCRIPT_DIR/.." && pwd )"

echo -e "${BLUE}========================================${NC}"
echo -e "${BLUE}  Docker Compose Logging System Setup${NC}"
echo -e "${BLUE}========================================${NC}"
echo ""

# Check if Docker is installed
if ! command -v docker &> /dev/null; then
    echo -e "${RED}✗ Docker is not installed${NC}"
    exit 1
fi

echo -e "${GREEN}✓ Docker is installed${NC}"
echo "  Version: $(docker --version)"
echo ""

# Check if Docker Compose is installed
if ! command -v docker-compose &> /dev/null; then
    echo -e "${RED}✗ Docker Compose is not installed${NC}"
    exit 1
fi

echo -e "${GREEN}✓ Docker Compose is installed${NC}"
echo "  Version: $(docker-compose --version)"
echo ""

# Navigate to project root
cd "$PROJECT_ROOT"

# Stop any running containers
echo -e "${YELLOW}Stopping any running containers...${NC}"
docker-compose down --remove-orphans 2>/dev/null || true
sleep 2

echo -e "${YELLOW}Building Docker images...${NC}"
docker-compose build --no-cache

if [ $? -ne 0 ]; then
    echo -e "${RED}✗ Failed to build Docker images${NC}"
    exit 1
fi

echo -e "${GREEN}✓ Docker images built successfully${NC}"
echo ""

echo -e "${YELLOW}Starting services...${NC}"
docker-compose up -d

if [ $? -ne 0 ]; then
    echo -e "${RED}✗ Failed to start services${NC}"
    exit 1
fi

echo -e "${GREEN}✓ Services started${NC}"
echo ""

# Wait for services to be ready
echo -e "${YELLOW}Waiting for services to be healthy...${NC}"
sleep 10

# Check Elasticsearch
echo -e "${BLUE}Checking Elasticsearch...${NC}"
for i in {1..30}; do
    if curl -s http://localhost:9200/_cluster/health > /dev/null 2>&1; then
        echo -e "${GREEN}✓ Elasticsearch is ready${NC}"
        break
    fi
    
    if [ $i -eq 30 ]; then
        echo -e "${RED}✗ Elasticsearch failed to start${NC}"
        docker-compose logs elasticsearch
        exit 1
    fi
    
    echo "  Attempt $i/30..."
    sleep 1
done

# Check Kibana
echo -e "${BLUE}Checking Kibana...${NC}"
for i in {1..30}; do
    if curl -s http://localhost:5601/api/status | grep -q '"state":"green"'; then
        echo -e "${GREEN}✓ Kibana is ready${NC}"
        break
    fi
    
    if [ $i -eq 30 ]; then
        echo -e "${YELLOW}⚠ Kibana taking longer to start (may still be initializing)${NC}"
        break
    fi
    
    echo "  Attempt $i/30..."
    sleep 1
done

# Check Web App
echo -e "${BLUE}Checking Web Application...${NC}"
for i in {1..30}; do
    if curl -s http://localhost:3000/health > /dev/null 2>&1; then
        echo -e "${GREEN}✓ Web Application is ready${NC}"
        break
    fi
    
    if [ $i -eq 30 ]; then
        echo -e "${RED}✗ Web Application failed to start${NC}"
        docker-compose logs web-app
        exit 1
    fi
    
    echo "  Attempt $i/30..."
    sleep 1
done

echo ""
echo -e "${BLUE}========================================${NC}"
echo -e "${BLUE}  Setup Complete!${NC}"
echo -e "${BLUE}========================================${NC}"
echo ""
echo -e "${GREEN}Service URLs:${NC}"
echo "  • Web Application: ${BLUE}http://localhost:3000${NC}"
echo "  • Elasticsearch:   ${BLUE}http://localhost:9200${NC}"
echo "  • Kibana:          ${BLUE}http://localhost:5601${NC}"
echo "  • Nginx Proxy:     ${BLUE}http://localhost:80${NC}"
echo ""
echo -e "${GREEN}Docker Status:${NC}"
docker-compose ps
echo ""
