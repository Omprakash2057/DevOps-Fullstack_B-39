#!/bin/bash

# Color codes
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

echo -e "${BLUE}========================================${NC}"
echo -e "${BLUE}  Cleanup and Shutdown${NC}"
echo -e "${BLUE}========================================${NC}"
echo ""

read -p "Are you sure you want to stop and remove all containers? (y/n) " -n 1 -r
echo
if [[ $REPLY =~ ^[Yy]$ ]]; then
    echo -e "${YELLOW}Stopping containers...${NC}"
    docker-compose stop
    
    echo -e "${YELLOW}Removing containers...${NC}"
    docker-compose rm -f
    
    echo ""
    read -p "Do you also want to remove volumes (elasticsearch-data, fluentd-buffer)? (y/n) " -n 1 -r
    echo
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        echo -e "${YELLOW}Removing volumes...${NC}"
        docker volume rm logging_elasticsearch-data 2>/dev/null || true
        docker volume rm logging_fluentd-buffer 2>/dev/null || true
        echo -e "${GREEN}✓ Volumes removed${NC}"
    fi
    
    echo -e "${GREEN}✓ Cleanup complete${NC}"
else
    echo -e "${YELLOW}Cancelled${NC}"
fi
