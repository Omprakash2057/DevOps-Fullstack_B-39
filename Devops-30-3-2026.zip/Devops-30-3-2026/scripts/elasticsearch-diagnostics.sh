#!/bin/bash

# Color codes for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Configuration
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
PROJECT_ROOT="$( cd "$SCRIPT_DIR/.." && pwd )"

echo -e "${BLUE}========================================${NC}"
echo -e "${BLUE}  Elasticsearch Diagnostics${NC}"
echo -e "${BLUE}========================================${NC}"
echo ""

# Check if Elasticsearch is running
if ! curl -s http://localhost:9200/_cluster/health > /dev/null 2>&1; then
    echo -e "${RED}✗ Elasticsearch is not available${NC}"
    echo "  Try running: docker-compose up -d"
    exit 1
fi

echo -e "${GREEN}✓ Elasticsearch is running${NC}"
echo ""

# Cluster Health
echo -e "${BLUE}Cluster Health:${NC}"
curl -s http://localhost:9200/_cluster/health | python3 -m json.tool
echo ""

# Node Info
echo -e "${BLUE}Nodes Information:${NC}"
curl -s http://localhost:9200/_nodes?pretty | python3 -m json.tool | head -50
echo ""

# Indices
echo -e "${BLUE}Indices:${NC}"
curl -s http://localhost:9200/_cat/indices?v
echo ""

# Index Stats
echo -e "${BLUE}Index Statistics:${NC}"
curl -s http://localhost:9200/_cat/indices?format=json | python3 -m json.tool
echo ""

# Shards
echo -e "${BLUE}Shard Allocation:${NC}"
curl -s http://localhost:9200/_cat/shards?v
echo ""

# Documents count
echo -e "${BLUE}Document Counts by Index:${NC}"
indices=$(curl -s http://localhost:9200/_cat/indices?h=index | grep -v "^\.")
for index in $indices; do
    count=$(curl -s http://localhost:9200/$index/_count | python3 -c "import sys, json; print(json.load(sys.stdin)['count'])")
    echo "  $index: $count documents"
done
echo ""

echo -e "${BLUE}========================================${NC}"
