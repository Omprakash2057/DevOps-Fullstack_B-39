#!/bin/bash

# Color codes
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

echo -e "${BLUE}========================================${NC}"
echo -e "${BLUE}  Load Testing Script${NC}"
echo -e "${BLUE}========================================${NC}"
echo ""

# Check dependencies
if ! command -v ab &> /dev/null; then
    echo -e "${YELLOW}Apache Bench not found. Installing...${NC}"
    # Note: This assumes you're on a system where you can install tools
    # For production, use a proper load testing tool like k6, JMeter, or Locust
    echo "Please install Apache Bench: apt-get install apache2-utils"
    exit 1
fi

BASE_URL="http://localhost:3000"

echo -e "${YELLOW}Running load tests...${NC}"
echo ""

# Test 1: Basic endpoint
echo -e "${BLUE}Test 1: Home Page (100 requests, 10 concurrent)${NC}"
ab -n 100 -c 10 "$BASE_URL/"
echo ""

# Test 2: API endpoint
echo -e "${BLUE}Test 2: API Users (100 requests, 10 concurrent)${NC}"
ab -n 100 -c 10 "$BASE_URL/api/users"
echo ""

# Test 3: Health check
echo -e "${BLUE}Test 3: Health Check (1000 requests, 50 concurrent)${NC}"
ab -n 1000 -c 50 "$BASE_URL/health"
echo ""

# Test 4: Error simulation
echo -e "${BLUE}Test 4: Error Simulation (50 requests, 5 concurrent)${NC}"
ab -n 50 -c 5 -X POST "$BASE_URL/api/error-simulator?type=test_error"
echo ""

echo -e "${GREEN}✓ Load tests complete${NC}"
echo ""
echo -e "${YELLOW}Tip: Check Kibana to analyze the generated logs${NC}"
echo -e "${YELLOW}URL: http://localhost:5601${NC}"
