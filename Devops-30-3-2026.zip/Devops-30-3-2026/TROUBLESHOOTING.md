# Troubleshooting & FAQ

## Common Issues and Solutions

### 1. Containers Won't Start

#### Symptoms:
```
Error response from daemon: ... (various Docker errors)
```

#### Solutions:

**Check Docker is running:**
```bash
docker info
# Should show daemon running info
```

**Insufficient memory:**
```bash
# Check available RAM
# Linux/Mac:
free -h
# Windows PowerShell:
Get-WmiObject -Class Win32_OperatingSystem | Select-Object TotalVisibleMemorySize, FreePhysicalMemory
```

**Port already in use:**
```bash
# Check what's on ports
# Linux/Mac:
lsof -i :3000
lsof -i :9200
lsof -i :5601

# Windows PowerShell:
netstat -ano | findstr :3000
netstat -ano | findstr :9200
```

**Solution - Free up ports:**
```bash
# Stop conflicting services
docker-compose stop existing-service

# Or use different ports in docker-compose.yml
# Change "3000:3000" to "3001:3000"
```

**Docker image pull failed:**
```bash
# Pull manually and check
docker pull node:18-alpine
docker pull docker.io/library/elasticsearch:8.5.0
docker pull docker.io/library/kibana:8.5.0
docker pull fluent/fluentd:v1,16-1
docker pull nginx:1.24-alpine
```

---

### 2. Logs Not Appearing in Kibana

#### Symptoms:
- Kibana says "No matching documents"
- Discover tab shows empty
- Recently viewed indices is empty

#### Diagnosis:

**Check if logs are in Elasticsearch:**
```bash
curl http://localhost:9200/_cat/indices
# Should see docker-logs, nginx-access, etc.

curl http://localhost:9200/docker-logs-*/_count
# Should show count > 0
```

**Check if Fluentd is running:**
```bash
docker-compose ps fluentd
# Should show UP status

docker-compose logs fluentd | tail -20
# Look for errors
```

**Check if Docker logging driver is configured:**
```bash
docker inspect web-app | grep -A 20 "LogDriver"
# Should show "fluentd"
```

#### Solutions:

**1. Create index pattern:**
- Go to http://localhost:5601
- Click "Stack Management" → "Index Patterns"
- Click "Create index pattern"
- Enter: `docker-logs-*`
- Select timestamp field
- Click "Create"

**2. Select correct index in Discover:**
- Click "Discover" tab
- Check the index pattern dropdown (top left)
- Should show your newly created pattern

**3. Check data is being generated:**
```bash
./scripts/test-logging.sh
# or
curl http://localhost:3000/api/users
```

**4. Verify Fluentd to Elasticsearch connection:**
```bash
docker-compose logs fluentd | grep -i "elasticsearch\|connection\|error"
```

**5. Check Elasticsearch status:**
```bash
curl -s http://localhost:9200/_cluster/health | python3 -m json.tool
# Should show "status": "green"
```

---

### 3. High Memory Usage

#### Symptoms:
```
Docker stats shows Elasticsearch at 90%+ memory
System running slowly
```

#### Causes:
- Elasticsearch heap too large
- Too many indices
- Large queries

#### Solutions:

**Reduce Elasticsearch heap (Development):**
```yaml
# In docker-compose.yml
elasticsearch:
  environment:
    - "ES_JAVA_OPTS=-Xms256m -Xmx256m"  # Reduce from 512m
```

Then rebuild:
```bash
docker-compose down
docker-compose up -d
```

**Delete old indices (reduces memory):**
```bash
# Check indices
curl http://localhost:9200/_cat/indices?v

# Delete old ones
curl -X DELETE http://localhost:9200/docker-logs-2026.01.*
curl -X DELETE http://localhost:9200/docker-logs-2026.02.*
```

**Set ILM policy (automatically delete old logs):**

See [DEPLOYMENT.md](DEPLOYMENT.md) for ILM setup.

---

### 4. Slow Kibana Searches

#### Symptoms:
```
Kibana query takes > 10 seconds
"Waiting for Elasticsearch" message persists
```

#### Causes:
- Searching entire 1+ year of data
- Too many shards
- Complex queries
- Insufficient disk I/O

#### Solutions:

**Reduce date range:**
- In Discover, set time range to "Last 7 days" instead of "All time"
- Or use "Last 24 hours" for faster results

**Use filters instead of search:**
```
Bad: search for entire collection
Good: use filters: status: 500 AND level: ERROR
```

**Delete unnecessary indices:**
```bash
# See what you have
curl http://localhost:9200/_cat/indices?h=index,docs.count

# Delete unnecessary ones
curl -X DELETE "http://localhost:9200/fluentd-catchall-*"
```

**Close old indices (keep data but make searchable):**
```bash
curl -X POST "http://localhost:9200/docker-logs-2026.01.*/_close"
```

---

### 5. Fluentd Not Forwarding Logs

#### Symptoms:
```
Docker logs show app output: "timestamp", "level", etc.
But nothing arrives in Elasticsearch
```

#### Causes:
- Fluentd not running
- Docker logging driver not configured
- Elasticsearch unavailable

#### Diagnosis:

**Check Fluentd container:**
```bash
docker-compose ps fluentd
# Should show UP

docker-compose logs fluentd
# Look for startup messages and errors
```

**Check Fluentd can reach Elasticsearch:**
```bash
docker-compose exec fluentd curl http://elasticsearch:9200/_cluster/health
# Should return green status
```

**Check logs are reaching Fluentd:**
```bash
docker-compose logs fluentd | grep -i "forward\|parse\|json"
# Should show log processing messages
```

#### Solutions:

**Restart Fluentd:**
```bash
docker-compose restart fluentd

# Wait 5 second and check
sleep 5
docker-compose logs fluentd | tail -20
```

**Rebuild Fluentd (if dependencies broke):**
```bash
docker-compose build --no-cache fluentd
docker-compose up -d fluentd
```

**Check docker-compose.yml logging config:**
```yaml
web-app:
  logging:
    driver: fluentd
    options:
      fluentd-address: localhost:24224  # Must match
      tag: docker.web-app
```

**Verify Fluentd config:**
```bash
docker-compose exec fluentd cat /fluentd/etc/fluent.conf
docker-compose exec fluentd cat /fluentd/etc/config.d/01-docker.conf
# Should show port 24224 listening
```

---

### 6. Elasticsearch Shows "Red" Status

#### Symptoms:
```
curl http://localhost:9200/_cluster/health
# "status": "red"
```

#### Causes:
- Unassigned shards
- Insufficient disk space
- Memory pressure
- Hardware failure

#### Solutions:

**Check cluster status details:**
```bash
curl -s http://localhost:9200/_cluster/health?human | python3 -m json.tool
# Shows unassigned_shards count
```

**Reallocate shards:**
```bash
curl -X POST "http://localhost:9200/_cluster/reroute" \
  -H 'Content-Type: application/json' \
  -d'{"commands": [{"allocate": {"index": "docker-logs-2026.04.08", "shard": 0, "node": "node-1"}}]}'
```

**Check disk space:**
```bash
docker exec elasticsearch df -h
# Should have > 10% free space
```

**Free disk space**, then:
```bash
curl -X PUT "http://localhost:9200/_all/_settings" \
  -H 'Content-Type: application/json' \
  -d'{"index.blocks.read_only_allow_delete": null}'
```

**Force merge to reclaim space:**
```bash
curl -X POST "http://localhost:9200/docker-logs-*/_forcemerge"
```

---

### 7. Docker Compose Up Stuck on "Waiting for Elasticsearch"

#### Symptoms:
```
docker-compose up showing "Waiting for service_name"
Nothing happens after 5+ minutes
```

#### Causes:
- Elasticsearch taking long to start
- Memory constraints
- Port conflicts

#### Solutions:

**Check what's happening:**
```bash
# In another terminal
docker-compose logs elasticsearch
# Look for actual errors
```

**Increase docker-compose timeout:**
```bash
# Run with explicit wait
docker-compose up -d

# Then check status
docker-compose ps
sleep 30
docker-compose ps
```

**Check Elasticsearch logs directly:**
```bash
docker logs elasticsearch 2>&1 | tail -50
# Look for OutOfMemory, port binding errors, etc.
```

**For Docker Desktop (Mac/Windows):**
- Open Docker Desktop preferences
- Increase CPU cores
- Increase RAM allocation
- Restart Docker Desktop

---

### 8. Port Already in Use Error

#### Symptoms:
```
Error response from daemon: Ports are not available: listen tcp 0.0.0.0:9200: bind: address already in use
```

#### Causes:
- Previous containers still running
- Another service on same port
- Docker not fully stopped

#### Solutions:

**List what's using ports:**
```bash
# Linux/Mac
lsof -i :9200
lsof -i :5601
lsof -i :3000

# Windows
netstat -ano | findstr :9200
netstat -ano | findstr :5601
netstat -ano | findstr :3000
```

**Stop old containers:**
```bash
docker-compose down

# Or more forcefully:
docker-compose down -v  # Also removes volumes
```

**Kill specific processes (if needed):**
```bash
# Linux/Mac (replace PID with number from lsof)
kill -9 PID

# Windows PowerShell (replace PID)
Stop-Process -Id PID -Force
```

**Use different ports (temporary workaround):**
```yaml
# In docker-compose.yml
elasticsearch:
  ports:
    - "9300:9200"  # Use 9300 instead of 9200

kibana:
  ports:
    - "5602:5601"  # Use 5602 instead
```

---

### 9. "Connection refused" When Accessing Services

#### Symptoms:
```
curl: (7) Failed to connect to localhost port 3000: Connection refused
```

#### Causes:
- Service not running
- Service not fully started
- Port mapping wrong
- Firewall blocking

#### Solutions:

**Check if container is running:**
```bash
docker-compose ps web-app
# Should show "Up X minutes"
```

**Check if port is actually listening:**
```bash
docker-compose exec web-app netstat -tuln | grep 3000
# Should show LISTEN
```

**Try accessing from inside Docker network:**
```bash
# From another container
docker-compose exec nginx curl http://web-app:3000/health

# Shows if it's localhost binding or actual service issue
```

**Wait longer for startup:**
```bash
docker-compose up -d
sleep 20  # More time for services
curl http://localhost:3000/
```

**Check firewall:**
```bash
# Linux iptables
sudo iptables -L -n | grep 3000

# macOS (Little Snitch, etc.)
# Check system preferences

# Windows Firewall
# Check Settings > Network > Firewall
```

---

### 10. Application Logs Not in JSON Format

#### Symptoms:
```
docker logs web-app shows:
"2026-04-08T10:30:45Z app info..."
NOT: {"timestamp": "...", "level": "..."
```

#### Causes:
- Logger not configured properly
- Different logging library used
- console.log used instead of logger.log

#### Solutions:

**Check app/logger.js:**
```bash
cat app/logger.js | head -30
# Should show JSON format configuration
```

**Rebuild container:**
```bash
docker-compose build --no-cache web-app
docker-compose up -d web-app
```

**Check that winston is installed:**
```bash
docker-compose exec web-app npm list winston
# Should show winston version
```

**Verify app is using logger:**
```bash
docker-compose exec web-app grep "logger\." app/index.js | head -5
# Should show logger.info, logger.error, etc.
```

---

## FAQ

### Q: How much disk space does logging use?

**A:** Approximately 100 bytes per log entry average.
- 1,000 logs/day = ~100KB
- 10,000 logs/day = ~1MB
- 1,000,000 logs/day = ~100MB

Set retention in Elasticsearch ILM to manage.

---

### Q: Can I run this on Windows 10/11?

**A:** Yes, but requires either:
- Windows Subsystem for Linux 2 (WSL2) + Docker Desktop
- Hyper-V + Docker Desktop
- VirtualBox + Docker Toolbox

Docker Desktop is simplest option.

---

### Q: How do I add a new service to logging?

**A:** In docker-compose.yml:
```yaml
my-service:
  image: my-image:latest
  logging:
    driver: fluentd
    options:
      fluentd-address: localhost:24224
      tag: docker.my-service
      labels: "service_name=my-service"
```

Logs automatically appear in Kibana.

---

### Q: How do I backup logs?

**A:**
```bash
# Using Elasticsearch snapshots
curl -X PUT "localhost:9200/_snapshot/backup"

# Using docker volumes
docker run --rm -v logging_elasticsearch-data:/data \
  -v /backup:/backup \
  ubuntu tar czf /backup/es-backup.tar.gz -C /data .
```

See DEPLOYMENT.md for full backup strategy.

---

### Q: How do I search for logs with specific values?

**A:** In Kibana Discover:
```
# Simple filter
level: ERROR

# Complex filter
level: ERROR AND status_code: 500

# String search
message: "database"

# Range
response_time_ms > 1000
```

---

### Q: Can I run this in production?

**A:** Yes, but read [DEPLOYMENT.md](DEPLOYMENT.md) first. You'll need:
- Enable authentication
- Add SSL/TLS
- Set up backups
- Configure monitoring
- Implement ILM policies
- Use a cluster (multiple Elasticsearch nodes)

---

### Q: How do I delete old logs permanently?

**A:**
```bash
# List indices
curl http://localhost:9200/_cat/indices

# Delete specific index
curl -X DELETE "http://localhost:9200/docker-logs-2026.01.*"

# Or set ILM delete policy (automatic)
# See DEPLOYMENT.md
```

---

### Q: Does this work with Kubernetes?

**A:** Yes! Use Helm charts:
```bash
helm repo add elastic https://helm.elastic.co
helm install elasticsearch elastic/elasticsearch
helm install kibana elastic/kibana
helm install fluentd stable/fluentd
```

Then adapt docker-compose for Kubernetes manifests.

---

### Q: How do I monitor my monitoring system (logging)?

**A:** Add Prometheus + Grafana:
```yaml
prometheus:
  image: prom/prometheus:latest
  scrape_configs:
    - job_name: elasticsearch
      static_configs: [{targets: ['elasticsearch:9200']}]
```

Then visualize Elasticsearch metrics in Grafana.

---

### Q: Can logs be lost?

**A:** Possible if:
- Fluentd buffer disk fills up
- Elasticsearch crashes before flush
- Network disconnect between services

Mitigation:
- Monitor disk space
- Use file-based buffering
- Set up replication
- Regular backups

---

### Q: How do I implement log rotation?

**A:** Elasticsearch automates with ILM:
```bash
# Set policy
curl -X PUT "localhost:9200/_ilm/policy/logs-policy" \
  -H 'Content-Type: application/json' \
  -d'{
    "policy": "logs-policy",
    "phases": {
      "delete": {"min_age": "30d", "actions": {"delete": {}}}
    }
  }'
```

---

### Q: Is data encrypted in transit?

**A:** By default, NO. Add SSL/TLS:
1. Generate certificates
2. Configure Elasticsearch SSL
3. Configure Fluentd SSL
4. Configure Kibana SSL

See DEPLOYMENT.md for instructions.

---

For more issues, check:
1. `./scripts/system-diagnostics.sh`
2. `docker-compose logs SERVICE`
3. [README.md](README.md) - Main documentation
4. [ARCHITECTURE.md](ARCHITECTURE.md) - System details
5. Official docs: elastic.co, fluentd.org, docker.com
