# Production Deployment Guide

This guide walks through deploying the centralized logging system to production with proper security, scalability, and reliability.

## 🔐 Security Hardening

### 1. Enable Elasticsearch Security

**Edit docker-compose.yml**:

```yaml
elasticsearch:
  environment:
    - xpack.security.enabled=true
    - ELASTIC_PASSWORD=${ELASTIC_PASSWORD}
    - xpack.license.self_generated.type=basic
    - xpack.security.transport.ssl.enabled=true
    - xpack.security.transport.ssl.verification_mode=certificate
```

**Create .env file**:

```bash
ELASTIC_PASSWORD=YourSecurePassword123!
KIBANA_PASSWORD=KibanaSecurePassword456!
FLUENTD_PASSWORD=FluentdPassword789!
```

**⚠️ Never commit .env to version control!**

### 2. Enable Kibana Authentication

```yaml
kibana:
  environment:
    - ELASTICSEARCH_USERNAME=kibana
    - ELASTICSEARCH_PASSWORD=${KIBANA_PASSWORD}
    - ELASTICSEARCH_HOSTS=http://elasticsearch:9200
```

### 3. Add SSL/TLS Certificates

**For Nginx (reverse proxy)**:

```bash
# Generate self-signed certificate (for testing)
openssl req -x509 -newkey rsa:4096 -keyout nginx/ssl/server.key \
  -out nginx/ssl/server.crt -days 365 -nodes

# For production: Use Let's Encrypt
# See: https://letsencrypt.org/
```

**Update docker-compose.yml**:

```yaml
nginx:
  volumes:
    - ./nginx/ssl:/etc/nginx/ssl:ro
  # SSL config already in nginx/conf.d/default.conf
```

**Update nginx/conf.d/default.conf**:

```nginx
server {
    listen 443 ssl http2;
    
    ssl_certificate /etc/nginx/ssl/server.crt;
    ssl_certificate_key /etc/nginx/ssl/server.key;
    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_ciphers HIGH:!aNULL:!MD5;
    ssl_prefer_server_ciphers on;
    
    # Additional security headers
    add_header Strict-Transport-Security "max-age=31536000" always;
    add_header X-Content-Type-Options "nosniff" always;
    add_header X-Frame-Options "DENY" always;
}

# Redirect HTTP to HTTPS
server {
    listen 80;
    return 301 https://$host$request_uri;
}
```

### 4. Network Isolation

Create a production-only network:

```yaml
networks:
  logging-network:
    driver: bridge
    ipam:
      config:
        - subnet: 172.20.0.0/16

  # Optional: Separate network for sensitive data
  secure-network:
    driver: bridge
```

Connect only necessary services:

```yaml
elasticsearch:
  networks:
    - logging-network

kibana:
  networks:
    - logging-network  # Kibana talks to Elasticsearch

web-app:
  networks:
    - logging-network  # App sends logs to Fluentd

nginx:
  networks:
    - logging-network  # Proxy in front
```

## 📈 Scalability

### 1. Elasticsearch Cluster

For production, use a proper cluster:

```yaml
elasticsearch-1:
  image: docker.io/library/elasticsearch:8.5.0
  environment:
    - cluster.name=production-cluster
    - discovery.seed_hosts=elasticsearch-2,elasticsearch-3
    - cluster.initial_master_nodes=elasticsearch-1,elasticsearch-2,elasticsearch-3
    - "ES_JAVA_OPTS=-Xms1g -Xmx1g"

elasticsearch-2:
  image: docker.io/library/elasticsearch:8.5.0
  environment:
    - cluster.name=production-cluster
    - discovery.seed_hosts=elasticsearch-1,elasticsearch-3
    - "ES_JAVA_OPTS=-Xms1g -Xmx1g"

elasticsearch-3:
  image: docker.io/library/elasticsearch:8.5.0
  environment:
    - cluster.name=production-cluster
    - discovery.seed_hosts=elasticsearch-1,elasticsearch-2
    - "ES_JAVA_OPTS=-Xms1g -Xmx1g"
```

### 2. Fluentd High Availability

Run multiple Fluentd instances:

```yaml
fluentd-1:
  # Main configuration
  ports:
    - "24224:24224"

fluentd-2:
  # Backup configuration
  ports:
    - "24225:24224"  # Different host port, same container port

fluentd-3:
  # Another backup
  ports:
    - "24226:24224"
```

Configure app to round-robin:

```javascript
// In app: send logs to multiple fluentd instances
const fluent = require('fluent-logger');
const logger = fluent.support.elFluent({
  host: 'fluentd-1',  // Primary
  port: 24224,
  timeout: 3.0,
  reconnectInterval: 600000
});
```

### 3. Application Load Balancing

Use Docker Swarm or Kubernetes:

```yaml
# docker-compose for Swarm mode
version: '3.9'

services:
  web-app:
    deploy:
      replicas: 3  # 3 copies
      placement:
        constraints: [ node.role == worker ]
      update_config:
        parallelism: 1
        delay: 10s
```

## 🔄 Data Persistence and Backups

### 1. Volume Backups

Create backup script:

```bash
#!/bin/bash
# backup-elasticsearch.sh

BACKUP_DIR="/backups/elasticsearch"
mkdir -p $BACKUP_DIR

# Create snapshot
curl -X PUT "localhost:9200/_snapshot/backup?pretty" \
  -H 'Content-Type: application/json' \
  -d'{
    "type": "fs",
    "settings": {
      "location": "/mnt/backups"
    }
  }'

# Trigger snapshot
curl -X PUT "localhost:9200/_snapshot/backup/$(date +%Y%m%d_%H%M%S)?wait_for_completion=true"
```

### 2. Index Lifecycle Management (ILM)

Set up automatic index rotation:

```bash
# Create ILM policy
curl -X PUT "localhost:9200/_ilm/policy/logs-policy?pretty" \
  -H 'Content-Type: application/json' \
  -d'{
    "policy": "logs-policy",
    "phases": {
      "hot": {
        "min_age": "0ms",
        "actions": {
          "rollover": {
            "max_primary_shard_size": "50GB"
          }
        }
      },
      "warm": {
        "min_age": "30d",
        "actions": {
          "set_priority": {
            "priority": 50
          }
        }
      },
      "cold": {
        "min_age": "90d",
        "actions": {
          "set_priority": {
            "priority": 0
          }
        }
      },
      "delete": {
        "min_age": "365d",
        "actions": {
          "delete": {}
        }
      }
    }
  }'
```

### 3. Snapshot Repository

```bash
# Register snapshot repo
curl -X PUT "localhost:9200/_snapshot/my_backup?pretty" \
  -H 'Content-Type: application/json' \
  -d'{
    "type": "s3",
    "settings": {
      "bucket": "my-bucket",
      "region": "us-east-1",
      "base_path": "elasticsearch-backups"
    }
  }'
```

## 📊 Monitoring and Alerts

### 1. Elasticsearch Monitoring

```yaml
# Add monitoring service
monitoring:
  image: docker.io/library/elasticsearch:8.5.0
  environment:
    - discovery.type=single-node
  volumes:
    - monitoring-data:/usr/share/elasticsearch/data
```

### 2. Prometheus Integration

```yaml
prometheus:
  image: prom/prometheus:latest
  volumes:
    - ./monitoring/prometheus.yml:/etc/prometheus/prometheus.yml
    - prometheus-data:/prometheus
  command:
    - '--config.file=/etc/prometheus/prometheus.yml'
```

**prometheus.yml**:

```yaml
global:
  scrape_interval: 15s

scrape_configs:
  - job_name: 'elasticsearch'
    static_configs:
      - targets: ['elasticsearch:9200']
  
  - job_name: 'kibana'
    static_configs:
      - targets: ['kibana:5601']
```

### 3. Grafana Dashboards

```yaml
grafana:
  image: grafana/grafana:latest
  environment:
    - GF_SECURITY_ADMIN_PASSWORD=admin
  ports:
    - "3000:3000"
  volumes:
    - grafana-storage:/var/lib/grafana
```

Add data sources in Grafana for Prometheus and Elasticsearch.

### 4. Alerting

**Alert Rules**:

```yaml
groups:
  - name: elasticsearch
    rules:
      - alert: HighHeapUsage
        expr: elasticsearch_jvm_memory_used_percent > 85
        for: 5m
        annotations:
          summary: "High JVM memory usage"
      
      - alert: ClusterRed
        expr: elasticsearch_cluster_health_status == 2
        annotations:
          summary: "Elasticsearch cluster is RED"
      
      - alert: LowDiskSpace
        expr: elasticsearch_filesystem_available_bytes < 5368709120  # 5GB
        annotations:
          summary: "Less than 5GB disk space available"
```

## 🚀 Infrastructure as Code

### Docker Swarm Deploy

```bash
#!/bin/bash
# deploy-swarm.sh

# Initialize swarm
docker swarm init

# Deploy stack
docker stack deploy -c docker-compose.yml logging-stack

# Check status
docker stack ps logging-stack

# Update service
docker service update logging-stack_elasticsearch --image elasticsearch:8.5.0
```

### Kubernetes Deployment

Create `k8s/logging-deployment.yaml`:

```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: logging-stack
spec:
  replicas: 3
  selector:
    matchLabels:
      app: logging
  template:
    metadata:
      labels:
        app: logging
    spec:
      containers:
      - name: elasticsearch
        image: docker.io/library/elasticsearch:8.5.0
        resources:
          limits:
            memory: "2Gi"
            cpu: "1000m"
        livenessProbe:
          httpGet:
            path: /_cluster/health
            port: 9200
          initialDelaySeconds: 30
          periodSeconds: 10
```

Deploy with:

```bash
kubectl apply -f k8s/logging-deployment.yaml
```

## 🔍 Log Retention and Compliance

### 1. GDPR Compliance

Configure right to be forgotten:

```yaml
# Elasticsearch mapping with TTL
PUT /logs-2026.04.08/_settings
{
  "index.lifecycle.name": "gdpr-policy",
  "index.lifecycle.rollover_alias": "logs"
}
```

### 2. Data Encryption

**At Rest**:

```yaml
elasticsearch:
  environment:
    - xpack.security.enabled=true
    - xpack.security.transport.ssl.enabled=true
    - xpack.security.transport.ssl.keystore.path=/usr/share/elasticsearch/config/certs/elasticsearch.keystore
```

**In Transit**:

```yaml
fluentd:
  environment:
    - ELASTICSEARCH_PROTOCOL=https
    - ELASTICSEARCH_SSL=true
    - ELASTICSEARCH_SSL_VERIFY=true
```

### 3. Audit Logging

```yaml
elasticsearch:
  environment:
    - xpack.security.audit.enabled=true
```

## ✅ Production Checklist

- [ ] SSL/TLS certificates installed
- [ ] All passwords changed from defaults
- [ ] .env file in .gitignore
- [ ] Network security configured
- [ ] Backup strategy implemented
- [ ] Monitoring and alerts set up
- [ ] ILM policies configured
- [ ] High availability enabled
- [ ] Load balancing configured
- [ ] Regular backup tests performed
- [ ] Disaster recovery plan documented
- [ ] Log retention policies set
- [ ] Encryption enabled
- [ ] Audit logging enabled
- [ ] Documentation updated
- [ ] Team trained on operations

## 📋 Deployment Steps

```bash
# 1. Prepare infrastructure
cd /path/to/production

# 2. Configure .env
cp .env.example .env
# Edit .env with production values

# 3. Generate certificates
./scripts/generate-certs.sh

# 4. Pre-flight checks
./scripts/pre-deployment-check.sh

# 5. Build images
docker-compose build --no-cache

# 6. Start services
docker-compose up -d

# 7. Run health checks
./scripts/post-deployment-check.sh

# 8. Setup backups
./scripts/setup-backups.sh

# 9. Configure monitoring
./scripts/setup-monitoring.sh

# 10. Verify everything
docker-compose ps
curl https://your-domain.com:5601  # Should work with SSL
```

## 🐛 Troubleshooting Production Issues

### Performance Degradation

```bash
# Check Elasticsearch stats
curl -s http://localhost:9200/_stats | jq '.indices'

# Check segment count
curl -s http://localhost:9200/_cat/segments | wc -l

# Force merge for optimization
curl -X POST "localhost:9200/docker-logs-*/_forcemerge"

# Check disk I/O
docker stats elasticsearch
```

### Memory Issues

```bash
# Adjust heap size
docker-compose stop elasticsearch
# Edit docker-compose.yml: ES_JAVA_OPTS=-Xms2g -Xmx2g
docker-compose up -d elasticsearch
```

### Connection Issues

```bash
# Test Elasticsearch connectivity
docker-compose exec fluentd curl http://elasticsearch:9200

# Check Fluentd buffer
docker-compose exec fluentd tail -f /fluentd/log/*.log

# Restart Fluentd
docker-compose restart fluentd
```

## 🎓 Further Learning

- [Elasticsearch Production Best Practices](https://www.elastic.co/guide/en/elasticsearch/reference/current/settings.html)
- [Kibana Security](https://www.elastic.co/guide/en/kibana/current/kibana-security.html)
- [Fluentd Production Guide](https://docs.fluentd.org/deployment/deployment-guides)
- [Docker Security](https://docs.docker.com/engine/security/)

---

For questions or issues, refer to the main [README.md](README.md) or check component-specific documentation.
