// ***********************************************
// This file contains custom Cypress commands
// and can be used across all test files.
//
// For more comprehensive examples of custom
// commands please read more here:
// https://on.cypress.io/custom-commands
// ***********************************************

// Command to add an expense
Cypress.Commands.add('addExpense', (description, amount, category, date) => {
  cy.get('[data-testid="nav-expenses"]').click()
  cy.get('[data-testid="expense-description"]').type(description)
  cy.get('[data-testid="expense-amount"]').type(amount)
  cy.get('[data-testid="expense-category"]').select(category)
  cy.get('[data-testid="expense-date"]').clear().type(date)
  cy.get('[data-testid="expense-submit"]').click()
})

// Command to add an income
Cypress.Commands.add('addIncome', (description, amount, source, date) => {
  cy.get('[data-testid="nav-income"]').click()
  cy.get('[data-testid="income-description"]').type(description)
  cy.get('[data-testid="income-amount"]').type(amount)
  cy.get('[data-testid="income-source"]').select(source)
  cy.get('[data-testid="income-date"]').clear().type(date)
  cy.get('[data-testid="income-submit"]').click()
})

// Command to navigate to dashboard
Cypress.Commands.add('navigateToDashboard', () => {
  cy.get('[data-testid="nav-dashboard"]').click()
  cy.get('[data-testid="dashboard"]').should('be.visible')
})
