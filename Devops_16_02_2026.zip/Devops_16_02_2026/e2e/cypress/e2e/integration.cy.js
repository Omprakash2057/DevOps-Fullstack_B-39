describe('Personal Finance Tracker - Integration Flow', () => {
  beforeEach(() => {
    cy.visit('/')
  })

  it('should add a new income and verify it reflects on Dashboard', () => {
    // First, check initial dashboard state
    cy.navigateToDashboard()
    cy.get('[data-testid="loading"]').should('not.exist')
    
    // Record initial values
    cy.get('[data-testid="total-income"]').invoke('text').then((initialIncome) => {
      cy.get('[data-testid="balance"]').invoke('text').then((initialBalance) => {
        
        // Navigate to Income page and add new income
        cy.get('[data-testid="nav-income"]').click()
        cy.addIncome('Bonus Payment', '1000.00', 'Job', '2026-02-16')
        
        // Verify success message
        cy.get('[data-testid="income-message"]').should('contain', 'Income added successfully!')
        
        // Navigate back to Dashboard
        cy.navigateToDashboard()
        cy.get('[data-testid="loading"]').should('not.exist')
        
        // Verify income is updated
        cy.get('[data-testid="total-income"]').should('not.contain', initialIncome.trim())
        cy.get('[data-testid="total-income"]').should('contain', '$6800.00') // 5800 + 1000
        
        // Verify balance is updated
        cy.get('[data-testid="balance"]').should('not.contain', initialBalance.trim())
        cy.get('[data-testid="balance"]').should('contain', '$6604.50') // 6800 - 195.50
      })
    })
  })

  it('should add a new expense and verify Dashboard reflects the change', () => {
    // Check initial dashboard
    cy.navigateToDashboard()
    cy.get('[data-testid="loading"]').should('not.exist')
    
    // Navigate to Expenses and add new expense
    cy.get('[data-testid="nav-expenses"]').click()
    cy.addExpense('Restaurant', '75.25', 'Food', '2026-02-16')
    
    // Verify expense added
    cy.get('[data-testid="expense-message"]').should('contain', 'Expense added successfully!')
    
    // Go back to Dashboard
    cy.navigateToDashboard()
    cy.get('[data-testid="loading"]').should('not.exist')
    
    // Verify expenses are updated
    cy.get('[data-testid="total-expenses"]').should('contain', '$270.75') // 195.50 + 75.25
    cy.get('[data-testid="balance"]').should('contain', '$5529.25') // 5800 - 270.75
  })

  it('should complete full workflow: add income, add expense, verify dashboard', () => {
    // Start at Dashboard
    cy.navigateToDashboard()
    cy.get('[data-testid="loading"]').should('not.exist')
    
    // Step 1: Add Income
    cy.get('[data-testid="nav-income"]').click()
    cy.addIncome('Freelance Project', '2500.00', 'Freelance', '2026-02-16')
    cy.get('[data-testid="income-message"]').should('contain', 'Income added successfully!')
    cy.get('[data-testid="income-list"]').should('contain', 'Freelance Project')
    
    // Step 2: Add Expense
    cy.get('[data-testid="nav-expenses"]').click()
    cy.addExpense('New Laptop', '1200.00', 'Other', '2026-02-16')
    cy.get('[data-testid="expense-message"]').should('contain', 'Expense added successfully!')
    cy.get('[data-testid="expense-list"]').should('contain', 'New Laptop')
    
    // Step 3: Verify Dashboard
    cy.navigateToDashboard()
    cy.get('[data-testid="loading"]').should('not.exist')
    
    // Calculate expected values: 
    // Income: 5800 + 2500 = 8300
    // Expenses: 195.50 + 1200 = 1395.50
    // Balance: 8300 - 1395.50 = 6904.50
    cy.get('[data-testid="total-income"]').should('contain', '$8300.00')
    cy.get('[data-testid="total-expenses"]').should('contain', '$1395.50')
    cy.get('[data-testid="balance"]').should('contain', '$6904.50')
  })

  it('should handle navigation between all pages smoothly', () => {
    // Test navigation flow
    cy.get('[data-testid="nav-dashboard"]').should('have.class', 'active')
    
    cy.get('[data-testid="nav-expenses"]').click()
    cy.get('[data-testid="nav-expenses"]').should('have.class', 'active')
    cy.get('[data-testid="expense-form"]').should('be.visible')
    
    cy.get('[data-testid="nav-income"]').click()
    cy.get('[data-testid="nav-income"]').should('have.class', 'active')
    cy.get('[data-testid="income-form"]').should('be.visible')
    
    cy.get('[data-testid="nav-dashboard"]').click()
    cy.get('[data-testid="nav-dashboard"]').should('have.class', 'active')
    cy.get('[data-testid="dashboard"]').should('be.visible')
  })

  it('should verify backend API integration', () => {
    // Test API health
    cy.request('GET', 'http://localhost:5000/api/health')
      .its('status')
      .should('eq', 200)
    
    // Test getting summary
    cy.request('GET', 'http://localhost:5000/api/summary')
      .its('status')
      .should('eq', 200)
      .its('body')
      .should('have.property', 'totalIncome')
      .and('have.property', 'totalExpenses')
      .and('have.property', 'balance')
  })
})
