describe('Personal Finance Tracker - Income', () => {
  beforeEach(() => {
    cy.visit('/')
  })

  it('should navigate to Income page', () => {
    cy.get('[data-testid="nav-income"]').click()
    cy.get('[data-testid="income-form"]').should('be.visible')
    cy.get('[data-testid="income-list"]').should('be.visible')
  })

  it('should display existing incomes', () => {
    cy.get('[data-testid="nav-income"]').click()
    
    // Wait for data to load
    cy.wait(1000)
    
    // Verify initial incomes are displayed
    cy.get('[data-testid="income-item-1"]').should('be.visible')
    cy.get('[data-testid="income-item-1"]').should('contain', 'Salary')
    cy.get('[data-testid="income-item-1"]').should('contain', '$5000.00')
    
    cy.get('[data-testid="income-item-2"]').should('be.visible')
    cy.get('[data-testid="income-item-2"]').should('contain', 'Freelance')
    cy.get('[data-testid="income-item-2"]').should('contain', '$800.00')
  })

  it('should add a new income and verify it appears in the list', () => {
    // Navigate to Income page
    cy.get('[data-testid="nav-income"]').click()
    
    // Fill out income form
    const newIncome = {
      description: 'Consulting Work',
      amount: '1200.00',
      source: 'Freelance',
      date: '2026-02-16'
    }
    
    cy.get('[data-testid="income-description"]').type(newIncome.description)
    cy.get('[data-testid="income-amount"]').type(newIncome.amount)
    cy.get('[data-testid="income-source"]').select(newIncome.source)
    cy.get('[data-testid="income-date"]').clear().type(newIncome.date)
    
    // Submit the form
    cy.get('[data-testid="income-submit"]').click()
    
    // Verify success message
    cy.get('[data-testid="income-message"]').should('be.visible')
    cy.get('[data-testid="income-message"]').should('contain', 'Income added successfully!')
    
    // Wait for list to update
    cy.wait(1000)
    
    // Verify the new income appears in the list
    cy.get('[data-testid="income-list"]').should('contain', newIncome.description)
    cy.get('[data-testid="income-list"]').should('contain', `$${parseFloat(newIncome.amount).toFixed(2)}`)
    
    // Verify form is reset
    cy.get('[data-testid="income-description"]').should('have.value', '')
    cy.get('[data-testid="income-amount"]').should('have.value', '')
  })

  it('should add multiple incomes successfully', () => {
    cy.get('[data-testid="nav-income"]').click()
    
    // Add first income
    cy.addIncome('Bonus', '500.00', 'Job', '2026-02-16')
    cy.get('[data-testid="income-message"]').should('contain', 'Income added successfully!')
    
    cy.wait(500)
    
    // Add second income
    cy.addIncome('Investment Returns', '350.00', 'Investment', '2026-02-16')
    cy.get('[data-testid="income-message"]').should('contain', 'Income added successfully!')
    
    // Verify both incomes appear
    cy.get('[data-testid="income-list"]').should('contain', 'Bonus')
    cy.get('[data-testid="income-list"]').should('contain', 'Investment Returns')
  })

  it('should validate required fields in income form', () => {
    cy.get('[data-testid="nav-income"]').click()
    
    // Try to submit empty form
    cy.get('[data-testid="income-submit"]').click()
    
    // Form should not submit (browser validation)
    cy.get('[data-testid="income-description"]').then($input => {
      expect($input[0].validationMessage).to.exist
    })
  })
})
