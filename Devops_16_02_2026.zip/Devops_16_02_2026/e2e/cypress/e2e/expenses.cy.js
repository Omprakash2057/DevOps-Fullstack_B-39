describe('Personal Finance Tracker - Expenses', () => {
  beforeEach(() => {
    cy.visit('/')
  })

  it('should navigate to Expenses page', () => {
    cy.get('[data-testid="nav-expenses"]').click()
    cy.get('[data-testid="expense-form"]').should('be.visible')
    cy.get('[data-testid="expense-list"]').should('be.visible')
  })

  it('should display existing expenses', () => {
    cy.get('[data-testid="nav-expenses"]').click()
    
    // Wait for data to load
    cy.wait(1000)
    
    // Verify initial expenses are displayed
    cy.get('[data-testid="expense-item-1"]').should('be.visible')
    cy.get('[data-testid="expense-item-1"]').should('contain', 'Groceries')
    cy.get('[data-testid="expense-item-1"]').should('contain', '$150.50')
    
    cy.get('[data-testid="expense-item-2"]').should('be.visible')
    cy.get('[data-testid="expense-item-2"]').should('contain', 'Gas')
    cy.get('[data-testid="expense-item-2"]').should('contain', '$45.00')
  })

  it('should add a new expense and verify it appears in the list', () => {
    // Navigate to Expenses page
    cy.get('[data-testid="nav-expenses"]').click()
    
    // Fill out expense form
    const newExpense = {
      description: 'Coffee Shop',
      amount: '15.75',
      category: 'Food',
      date: '2026-02-16'
    }
    
    cy.get('[data-testid="expense-description"]').type(newExpense.description)
    cy.get('[data-testid="expense-amount"]').type(newExpense.amount)
    cy.get('[data-testid="expense-category"]').select(newExpense.category)
    cy.get('[data-testid="expense-date"]').clear().type(newExpense.date)
    
    // Submit the form
    cy.get('[data-testid="expense-submit"]').click()
    
    // Verify success message
    cy.get('[data-testid="expense-message"]').should('be.visible')
    cy.get('[data-testid="expense-message"]').should('contain', 'Expense added successfully!')
    
    // Wait for list to update
    cy.wait(1000)
    
    // Verify the new expense appears in the list
    cy.get('[data-testid="expense-list"]').should('contain', newExpense.description)
    cy.get('[data-testid="expense-list"]').should('contain', `$${parseFloat(newExpense.amount).toFixed(2)}`)
    
    // Verify form is reset
    cy.get('[data-testid="expense-description"]').should('have.value', '')
    cy.get('[data-testid="expense-amount"]').should('have.value', '')
  })

  it('should add multiple expenses successfully', () => {
    cy.get('[data-testid="nav-expenses"]').click()
    
    // Add first expense
    cy.addExpense('Lunch', '25.00', 'Food', '2026-02-16')
    cy.get('[data-testid="expense-message"]').should('contain', 'Expense added successfully!')
    
    cy.wait(500)
    
    // Add second expense
    cy.addExpense('Uber Ride', '18.50', 'Transportation', '2026-02-16')
    cy.get('[data-testid="expense-message"]').should('contain', 'Expense added successfully!')
    
    // Verify both expenses appear
    cy.get('[data-testid="expense-list"]').should('contain', 'Lunch')
    cy.get('[data-testid="expense-list"]').should('contain', 'Uber Ride')
  })

  it('should validate required fields in expense form', () => {
    cy.get('[data-testid="nav-expenses"]').click()
    
    // Try to submit empty form
    cy.get('[data-testid="expense-submit"]').click()
    
    // Form should not submit (browser validation)
    cy.get('[data-testid="expense-description"]').then($input => {
      expect($input[0].validationMessage).to.exist
    })
  })
})
