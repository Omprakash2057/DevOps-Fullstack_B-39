describe('Personal Finance Tracker - Dashboard', () => {
  beforeEach(() => {
    cy.visit('/')
  })

  it('should load the application and display the header', () => {
    cy.contains('💰 Personal Finance Tracker').should('be.visible')
  })

  it('should navigate to Dashboard and load summary data', () => {
    // Navigate to Dashboard
    cy.navigateToDashboard()
    
    // Wait for data to load
    cy.get('[data-testid="loading"]', { timeout: 10000 }).should('not.exist')
    
    // Verify summary cards are displayed
    cy.get('[data-testid="total-income"]').should('be.visible')
    cy.get('[data-testid="total-expenses"]').should('be.visible')
    cy.get('[data-testid="balance"]').should('be.visible')
    
    // Verify initial data (from reset)
    cy.get('[data-testid="total-income"]').should('contain', '$5800.00')
    cy.get('[data-testid="total-expenses"]').should('contain', '$195.50')
    cy.get('[data-testid="balance"]').should('contain', '$5604.50')
  })

  it('should refresh dashboard data when clicking refresh button', () => {
    cy.navigateToDashboard()
    cy.get('[data-testid="loading"]').should('not.exist')
    
    // Click refresh button
    cy.get('[data-testid="refresh-button"]').click()
    
    // Data should still be visible
    cy.get('[data-testid="total-income"]').should('be.visible')
    cy.get('[data-testid="balance"]').should('be.visible')
  })

  it('should display correct financial summary with counts', () => {
    cy.navigateToDashboard()
    cy.get('[data-testid="loading"]').should('not.exist')
    
    // Check transaction counts
    cy.contains('2 transactions').should('be.visible')
  })
})
