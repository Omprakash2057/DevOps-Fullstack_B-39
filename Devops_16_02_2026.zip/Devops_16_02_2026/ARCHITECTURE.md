# 🏗️ System Architecture

## Personal Finance Tracker - E2E Integration Testing

```
┌─────────────────────────────────────────────────────────────────────┐
│                          CI/CD Pipeline                              │
│                         (GitHub Actions)                             │
├─────────────────────────────────────────────────────────────────────┤
│  1. Checkout Code                                                    │
│  2. Setup Node.js                                                    │
│  3. Install Dependencies                                             │
│  4. Build Frontend                                                   │
│  5. Start Backend Server ────────────┐                              │
│  6. Start Frontend Server ───────────┤                              │
│  7. Run E2E Tests ───────────────────┤                              │
│  8. Upload Artifacts (Screenshots/Videos)                            │
│  9. Shutdown Services                                                │
└───────────────────────────────────────┼──────────────────────────────┘
                                        │
                                        ▼
┌─────────────────────────────────────────────────────────────────────┐
│                        Application Stack                             │
└─────────────────────────────────────────────────────────────────────┘

┌──────────────────────────┐         ┌──────────────────────────┐
│    Frontend (React)      │         │   Backend (Express.js)   │
│                          │         │                          │
│  Port: 3000              │────────▶│   Port: 5000             │
│                          │  HTTP   │                          │
│  Components:             │ Requests│   API Endpoints:         │
│  • Dashboard             │         │   • GET /api/summary     │
│  • ExpenseForm           │         │   • GET /api/expenses    │
│  • ExpenseList           │         │   • POST /api/expenses   │
│  • IncomeForm            │         │   • GET /api/incomes     │
│  • IncomeList            │         │   • POST /api/incomes    │
│                          │         │   • POST /api/reset      │
│  State Management:       │         │                          │
│  • React Hooks           │         │   Data Store:            │
│  • Event System          │         │   • In-Memory Arrays     │
│                          │         │                          │
└────────────┬─────────────┘         └──────────────────────────┘
             │                                    ▲
             │                                    │
             ▼                                    │
┌─────────────────────────────────────────────────┼──────────────┐
│           E2E Testing Layer (Cypress)           │              │
│                                                 │              │
│  Test Suites:                                  │              │
│  ┌──────────────────────────────────────────┐ │              │
│  │ 1. Dashboard Tests                       │ │              │
│  │    • Load summary data                   │─┘              │
│  │    • Verify calculations                 │                │
│  │    • Test refresh                        │                │
│  └──────────────────────────────────────────┘                │
│                                                               │
│  ┌──────────────────────────────────────────┐                │
│  │ 2. Expense Tests                         │                │
│  │    • Add expense                         │                │
│  │    • Verify list update                  │                │
│  │    • Form validation                     │                │
│  └──────────────────────────────────────────┘                │
│                                                               │
│  ┌──────────────────────────────────────────┐                │
│  │ 3. Income Tests                          │                │
│  │    • Add income                          │                │
│  │    • Verify list update                  │                │
│  │    • Form validation                     │                │
│  └──────────────────────────────────────────┘                │
│                                                               │
│  ┌──────────────────────────────────────────┐                │
│  │ 4. Integration Tests                     │                │
│  │    • Complete workflows                  │                │
│  │    • Cross-page navigation               │                │
│  │    • API integration                     │                │
│  │    • End-to-end scenarios                │                │
│  └──────────────────────────────────────────┘                │
│                                                               │
│  Test Artifacts:                                             │
│  • Screenshots (on failure)                                  │
│  • Videos (all tests)                                        │
│  • Test reports                                              │
└───────────────────────────────────────────────────────────────┘

```

## Data Flow

```
┌─────────┐
│  User   │
└────┬────┘
     │
     ▼
┌─────────────────────────┐
│   React Components      │
│   (UI Layer)            │
└────────┬────────────────┘
         │
         │ User Actions
         │ (Add Expense/Income)
         ▼
┌─────────────────────────┐
│   Event Handlers        │
│   (Form Submit)         │
└────────┬────────────────┘
         │
         │ HTTP POST
         │ (Axios)
         ▼
┌─────────────────────────┐
│   Express API           │
│   (Backend)             │
└────────┬────────────────┘
         │
         │ Process & Store
         ▼
┌─────────────────────────┐
│   In-Memory Data        │
│   (Array Storage)       │
└────────┬────────────────┘
         │
         │ HTTP Response
         ▼
┌─────────────────────────┐
│   React State           │
│   (Update UI)           │
└────────┬────────────────┘
         │
         ▼
┌─────────────────────────┐
│   Updated UI            │
│   (List/Dashboard)      │
└─────────────────────────┘
```

## Test Execution Flow

```
┌──────────────────┐
│  CI Trigger      │
│  (Push/PR)       │
└────────┬─────────┘
         │
         ▼
┌──────────────────────────────────┐
│  Install Dependencies            │
│  • Backend                       │
│  • Frontend                      │
│  • E2E Tests                     │
└────────┬─────────────────────────┘
         │
         ▼
┌──────────────────────────────────┐
│  Build Frontend                  │
│  (Production Build)              │
└────────┬─────────────────────────┘
         │
         ▼
┌──────────────────────────────────┐
│  Start Backend Server            │
│  • Wait for health check         │
│  • Verify API accessible         │
└────────┬─────────────────────────┘
         │
         ▼
┌──────────────────────────────────┐
│  Start Frontend Server           │
│  • Wait for app ready            │
│  • Verify UI accessible          │
└────────┬─────────────────────────┘
         │
         ▼
┌──────────────────────────────────┐
│  Run Cypress E2E Tests           │
│  • Dashboard tests               │
│  • Expense tests                 │
│  • Income tests                  │
│  • Integration tests             │
└────────┬─────────────────────────┘
         │
         ▼
┌──────────────────────────────────┐
│  Capture Artifacts               │
│  • Screenshots (failures)        │
│  • Videos (all tests)            │
│  • Test reports                  │
└────────┬─────────────────────────┘
         │
         ▼
┌──────────────────────────────────┐
│  Shutdown Services               │
│  • Stop backend                  │
│  • Stop frontend                 │
│  • Clean up processes            │
└────────┬─────────────────────────┘
         │
         ▼
┌──────────────────────────────────┐
│  Upload to GitHub Actions        │
│  • Artifacts (30 day retention)  │
│  • Test results                  │
│  • Build summary                 │
└──────────────────────────────────┘
```

## Component Architecture

```
┌─────────────────────────────────────┐
│           App.js (Main)             │
│                                     │
│  • Tab Navigation                   │
│  • Active Tab State                 │
│  • Route Components                 │
└───────────┬─────────────────────────┘
            │
            ├─────────────────────┬───────────────────┐
            │                     │                   │
            ▼                     ▼                   ▼
┌─────────────────────┐ ┌──────────────┐  ┌──────────────┐
│   Dashboard         │ │  Expenses    │  │   Income     │
│   Component         │ │  Section     │  │   Section    │
│                     │ │              │  │              │
│  • Summary Cards    │ │  ┌─────────┐ │  │  ┌─────────┐ │
│  • Total Income     │ │  │ Form    │ │  │  │ Form    │ │
│  • Total Expenses   │ │  └─────────┘ │  │  └─────────┘ │
│  • Balance          │ │  ┌─────────┐ │  │  ┌─────────┐ │
│  • Refresh Button   │ │  │ List    │ │  │  │ List    │ │
│                     │ │  └─────────┘ │  │  └─────────┘ │
└─────────────────────┘ └──────────────┘  └──────────────┘
```

## API Endpoint Structure

```
Backend API (http://localhost:5000)
│
├─ /api/health          [GET]   → Health check
│
├─ /api/summary         [GET]   → Dashboard summary
│   Response: {
│     totalIncome: number,
│     totalExpenses: number,
│     balance: number,
│     incomeCount: number,
│     expenseCount: number
│   }
│
├─ /api/expenses        [GET]   → Get all expenses
│   Response: Expense[]
│
├─ /api/expenses        [POST]  → Add new expense
│   Request: {
│     description: string,
│     amount: number,
│     category: string,
│     date: string
│   }
│   Response: Expense
│
├─ /api/incomes         [GET]   → Get all incomes
│   Response: Income[]
│
├─ /api/incomes         [POST]  → Add new income
│   Request: {
│     description: string,
│     amount: number,
│     source: string,
│     date: string
│   }
│   Response: Income
│
└─ /api/reset           [POST]  → Reset data (testing)
    Response: { message: string }
```

## Project Structure Tree

```
Devops_16_02_2026/
│
├── backend/                      # Express.js Backend
│   ├── server.js                # Main server file
│   ├── package.json             # Dependencies
│   └── .gitignore
│
├── frontend/                     # React Frontend
│   ├── public/
│   │   └── index.html
│   ├── src/
│   │   ├── components/
│   │   │   ├── Dashboard.js
│   │   │   ├── Dashboard.css
│   │   │   ├── ExpenseForm.js
│   │   │   ├── ExpenseList.js
│   │   │   ├── IncomeForm.js
│   │   │   └── IncomeList.js
│   │   ├── App.js
│   │   ├── App.css
│   │   ├── index.js
│   │   └── index.css
│   ├── package.json
│   └── .gitignore
│
├── e2e/                          # Cypress E2E Tests
│   ├── cypress/
│   │   ├── e2e/
│   │   │   ├── dashboard.cy.js
│   │   │   ├── expenses.cy.js
│   │   │   ├── income.cy.js
│   │   │   └── integration.cy.js
│   │   └── support/
│   │       ├── commands.js
│   │       └── e2e.js
│   ├── cypress.config.js
│   ├── package.json
│   └── .gitignore
│
├── .github/
│   └── workflows/               # CI/CD Pipelines
│       ├── e2e-tests.yml       # E2E testing workflow
│       └── ci-cd.yml           # Full CI/CD pipeline
│
├── run-tests.sh                 # Linux/Mac test runner
├── run-tests.bat                # Windows test runner
├── verify-setup.sh              # Linux/Mac setup check
├── verify-setup.bat             # Windows setup check
│
├── README.md                    # Full documentation
├── QUICKSTART.md               # Quick start guide
├── TESTING.md                  # Testing guide
├── ASSIGNMENT.md               # Assignment details
├── ARCHITECTURE.md             # This file
│
├── package.json                # Root package manager
└── .gitignore                  # Git ignore rules
```

## Technology Stack

### Frontend
- **Framework**: React 18.2.0
- **HTTP Client**: Axios 1.6.0
- **Styling**: CSS3 with custom styles
- **Build Tool**: react-scripts 5.0.1

### Backend
- **Runtime**: Node.js 18.x
- **Framework**: Express.js 4.18.2
- **Middleware**: CORS, Body-parser
- **Data Storage**: In-memory arrays

### Testing
- **E2E Framework**: Cypress 13.6.2
- **Test Runner**: Cypress CLI
- **Assertions**: Cypress built-in
- **Artifacts**: Screenshots + Videos

### CI/CD
- **Platform**: GitHub Actions
- **Runner**: Ubuntu Latest
- **Node Version**: 18.x
- **Caching**: npm dependencies

## Deployment Architecture

```
┌─────────────────────────────────────────┐
│         Development Environment          │
│                                          │
│  Developer → Git Push → GitHub           │
└─────────────┬───────────────────────────┘
              │
              ▼
┌─────────────────────────────────────────┐
│         CI/CD (GitHub Actions)           │
│                                          │
│  • Checkout Code                         │
│  • Run Tests                             │
│  • Build Application                     │
│  • Generate Artifacts                    │
└─────────────┬───────────────────────────┘
              │
              ▼
┌─────────────────────────────────────────┐
│         Artifact Storage                 │
│                                          │
│  • Screenshots (failures)                │
│  • Videos (all tests)                    │
│  • Build Output                          │
│  • Test Reports                          │
└─────────────────────────────────────────┘
              │
              ▼
┌─────────────────────────────────────────┐
│         Production Deployment            │
│         (Future Enhancement)             │
│                                          │
│  • Heroku / Vercel / AWS                 │
│  • Database Integration                  │
│  • Authentication                        │
│  • Monitoring                            │
└─────────────────────────────────────────┘
```

## Security Considerations

1. **CORS**: Enabled for development, configure for production
2. **Input Validation**: Backend validates all inputs
3. **Data Sanitization**: Prevents injection attacks
4. **Environment Variables**: Sensitive data in .env files
5. **HTTPS**: Use in production
6. **API Rate Limiting**: Implement for production

## Scalability Considerations

1. **Database**: Replace in-memory storage with PostgreSQL/MongoDB
2. **Caching**: Add Redis for session management
3. **Load Balancing**: Use Nginx for multiple instances
4. **CDN**: Serve static assets via CDN
5. **Microservices**: Split into smaller services if needed

## Future Enhancements

1. **User Authentication**: JWT-based auth
2. **Persistent Storage**: Database integration
3. **Real-time Updates**: WebSocket support
4. **Mobile App**: React Native version
5. **Analytics**: Track financial trends
6. **Export**: PDF/CSV reports
7. **Budget Planning**: Set budgets and goals
8. **Multi-currency**: Support multiple currencies

---

**Last Updated**: February 16, 2026
