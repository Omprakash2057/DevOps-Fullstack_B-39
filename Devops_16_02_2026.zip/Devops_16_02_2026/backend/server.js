const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');

const app = express();
const PORT = process.env.PORT || 5000;

// Middleware
app.use(cors());
app.use(bodyParser.json());

// In-memory data store
let expenses = [
  { id: 1, description: 'Groceries', amount: 150.50, category: 'Food', date: '2026-02-15' },
  { id: 2, description: 'Gas', amount: 45.00, category: 'Transportation', date: '2026-02-14' }
];

let incomes = [
  { id: 1, description: 'Salary', amount: 5000.00, source: 'Job', date: '2026-02-01' },
  { id: 2, description: 'Freelance', amount: 800.00, source: 'Side Project', date: '2026-02-10' }
];

// Routes

// Health check
app.get('/api/health', (req, res) => {
  res.json({ status: 'OK', message: 'Backend is running' });
});

// Get dashboard summary
app.get('/api/summary', (req, res) => {
  const totalIncome = incomes.reduce((sum, income) => sum + income.amount, 0);
  const totalExpenses = expenses.reduce((sum, expense) => sum + expense.amount, 0);
  const balance = totalIncome - totalExpenses;

  res.json({
    totalIncome,
    totalExpenses,
    balance,
    expenseCount: expenses.length,
    incomeCount: incomes.length
  });
});

// Get all expenses
app.get('/api/expenses', (req, res) => {
  res.json(expenses);
});

// Add new expense
app.post('/api/expenses', (req, res) => {
  const { description, amount, category, date } = req.body;
  
  if (!description || !amount || !category || !date) {
    return res.status(400).json({ error: 'All fields are required' });
  }

  const newExpense = {
    id: expenses.length > 0 ? Math.max(...expenses.map(e => e.id)) + 1 : 1,
    description,
    amount: parseFloat(amount),
    category,
    date
  };

  expenses.push(newExpense);
  res.status(201).json(newExpense);
});

// Get all incomes
app.get('/api/incomes', (req, res) => {
  res.json(incomes);
});

// Add new income
app.post('/api/incomes', (req, res) => {
  const { description, amount, source, date } = req.body;
  
  if (!description || !amount || !source || !date) {
    return res.status(400).json({ error: 'All fields are required' });
  }

  const newIncome = {
    id: incomes.length > 0 ? Math.max(...incomes.map(i => i.id)) + 1 : 1,
    description,
    amount: parseFloat(amount),
    source,
    date
  };

  incomes.push(newIncome);
  res.status(201).json(newIncome);
});

// Reset data (for testing)
app.post('/api/reset', (req, res) => {
  expenses = [
    { id: 1, description: 'Groceries', amount: 150.50, category: 'Food', date: '2026-02-15' },
    { id: 2, description: 'Gas', amount: 45.00, category: 'Transportation', date: '2026-02-14' }
  ];
  
  incomes = [
    { id: 1, description: 'Salary', amount: 5000.00, source: 'Job', date: '2026-02-01' },
    { id: 2, description: 'Freelance', amount: 800.00, source: 'Side Project', date: '2026-02-10' }
  ];
  
  res.json({ message: 'Data reset successfully' });
});

app.listen(PORT, () => {
  console.log(`Backend server running on http://localhost:${PORT}`);
});

module.exports = app;
