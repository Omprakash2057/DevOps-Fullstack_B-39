#!/bin/bash

echo "=================================="
echo "Setup Verification Script"
echo "=================================="
echo ""

# Color codes
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

ERRORS=0

# Check Node.js
echo -n "Checking Node.js installation... "
if command -v node &> /dev/null; then
    NODE_VERSION=$(node -v)
    echo -e "${GREEN}✓${NC} Node.js $NODE_VERSION"
else
    echo -e "${RED}✗ Node.js not found${NC}"
    ERRORS=$((ERRORS + 1))
fi

# Check npm
echo -n "Checking npm installation... "
if command -v npm &> /dev/null; then
    NPM_VERSION=$(npm -v)
    echo -e "${GREEN}✓${NC} npm $NPM_VERSION"
else
    echo -e "${RED}✗ npm not found${NC}"
    ERRORS=$((ERRORS + 1))
fi

echo ""
echo "Checking project structure..."

# Check backend
echo -n "  Backend files... "
if [ -f "backend/server.js" ] && [ -f "backend/package.json" ]; then
    echo -e "${GREEN}✓${NC}"
else
    echo -e "${RED}✗${NC}"
    ERRORS=$((ERRORS + 1))
fi

# Check frontend
echo -n "  Frontend files... "
if [ -f "frontend/src/App.js" ] && [ -f "frontend/package.json" ]; then
    echo -e "${GREEN}✓${NC}"
else
    echo -e "${RED}✗${NC}"
    ERRORS=$((ERRORS + 1))
fi

# Check E2E tests
echo -n "  E2E test files... "
if [ -f "e2e/cypress.config.js" ] && [ -f "e2e/package.json" ]; then
    echo -e "${GREEN}✓${NC}"
else
    echo -e "${RED}✗${NC}"
    ERRORS=$((ERRORS + 1))
fi

# Check CI workflows
echo -n "  CI/CD workflows... "
if [ -f ".github/workflows/e2e-tests.yml" ] && [ -f ".github/workflows/ci-cd.yml" ]; then
    echo -e "${GREEN}✓${NC}"
else
    echo -e "${RED}✗${NC}"
    ERRORS=$((ERRORS + 1))
fi

echo ""
echo "Checking dependencies installation..."

# Check backend dependencies
echo -n "  Backend dependencies... "
if [ -d "backend/node_modules" ]; then
    echo -e "${GREEN}✓ Installed${NC}"
else
    echo -e "${YELLOW}⚠ Not installed${NC}"
    echo "    Run: cd backend && npm install"
fi

# Check frontend dependencies
echo -n "  Frontend dependencies... "
if [ -d "frontend/node_modules" ]; then
    echo -e "${GREEN}✓ Installed${NC}"
else
    echo -e "${YELLOW}⚠ Not installed${NC}"
    echo "    Run: cd frontend && npm install"
fi

# Check E2E dependencies
echo -n "  E2E dependencies... "
if [ -d "e2e/node_modules" ]; then
    echo -e "${GREEN}✓ Installed${NC}"
else
    echo -e "${YELLOW}⚠ Not installed${NC}"
    echo "    Run: cd e2e && npm install"
fi

echo ""
echo "Checking documentation..."
FILES=("README.md" "QUICKSTART.md" "TESTING.md" "ASSIGNMENT.md")
for file in "${FILES[@]}"; do
    echo -n "  $file... "
    if [ -f "$file" ]; then
        echo -e "${GREEN}✓${NC}"
    else
        echo -e "${RED}✗${NC}"
        ERRORS=$((ERRORS + 1))
    fi
done

echo ""
echo "=================================="
if [ $ERRORS -eq 0 ]; then
    echo -e "${GREEN}✓ Setup verification passed!${NC}"
    echo ""
    echo "Next steps:"
    echo "  1. Install dependencies: npm run install:all"
    echo "  2. Run tests: ./run-tests.sh"
    echo "  3. Or start manually:"
    echo "     - Backend: cd backend && npm start"
    echo "     - Frontend: cd frontend && npm start"
    echo "     - Tests: cd e2e && npm run test:e2e"
else
    echo -e "${RED}✗ Setup verification found $ERRORS error(s)${NC}"
    echo "Please fix the issues above and try again."
fi
echo "=================================="
