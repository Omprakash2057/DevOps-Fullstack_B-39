import React, { useState, useEffect } from 'react';
import axios from 'axios';

const ExpenseList = () => {
  const [expenses, setExpenses] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    fetchExpenses();

    // Listen for new expense additions
    const handleExpenseAdded = () => {
      fetchExpenses();
    };
    window.addEventListener('expenseAdded', handleExpenseAdded);
    
    return () => {
      window.removeEventListener('expenseAdded', handleExpenseAdded);
    };
  }, []);

  const fetchExpenses = async () => {
    try {
      setLoading(true);
      const response = await axios.get('/api/expenses');
      setExpenses(response.data);
      setError(null);
    } catch (err) {
      setError('Failed to load expenses');
      console.error('Error fetching expenses:', err);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return <div className="loading">Loading expenses...</div>;
  }

  if (error) {
    return <div className="error-message">{error}</div>;
  }

  return (
    <div className="card" data-testid="expense-list">
      <h2>Expense History</h2>
      
      {expenses.length === 0 ? (
        <p>No expenses recorded yet.</p>
      ) : (
        <div className="list">
          {expenses.map((expense) => (
            <div key={expense.id} className="list-item" data-testid={`expense-item-${expense.id}`}>
              <div className="list-item-info">
                <div className="list-item-description">{expense.description}</div>
                <div className="list-item-details">
                  {expense.category} • {expense.date}
                </div>
              </div>
              <div className="list-item-amount amount-expense">
                ${expense.amount.toFixed(2)}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default ExpenseList;
