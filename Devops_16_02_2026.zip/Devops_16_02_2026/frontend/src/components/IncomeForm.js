import React, { useState } from 'react';
import axios from 'axios';

const IncomeForm = () => {
  const [formData, setFormData] = useState({
    description: '',
    amount: '',
    source: 'Job',
    date: new Date().toISOString().split('T')[0]
  });
  const [message, setMessage] = useState({ type: '', text: '' });
  const [loading, setLoading] = useState(false);

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setMessage({ type: '', text: '' });

    try {
      await axios.post('/api/incomes', formData);
      setMessage({ type: 'success', text: 'Income added successfully!' });
      setFormData({
        description: '',
        amount: '',
        source: 'Job',
        date: new Date().toISOString().split('T')[0]
      });
      
      // Trigger refresh of income list
      window.dispatchEvent(new Event('incomeAdded'));
    } catch (err) {
      setMessage({ type: 'error', text: 'Failed to add income. Please try again.' });
      console.error('Error adding income:', err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="card" data-testid="income-form">
      <h2>Add New Income</h2>
      
      {message.text && (
        <div 
          className={message.type === 'success' ? 'success-message' : 'error-message'}
          data-testid="income-message"
        >
          {message.text}
        </div>
      )}

      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label htmlFor="income-description">Description</label>
          <input
            type="text"
            id="income-description"
            name="description"
            value={formData.description}
            onChange={handleChange}
            required
            data-testid="income-description"
          />
        </div>

        <div className="form-group">
          <label htmlFor="income-amount">Amount ($)</label>
          <input
            type="number"
            id="income-amount"
            name="amount"
            value={formData.amount}
            onChange={handleChange}
            step="0.01"
            min="0"
            required
            data-testid="income-amount"
          />
        </div>

        <div className="form-group">
          <label htmlFor="income-source">Source</label>
          <select
            id="income-source"
            name="source"
            value={formData.source}
            onChange={handleChange}
            data-testid="income-source"
          >
            <option value="Job">Job</option>
            <option value="Freelance">Freelance</option>
            <option value="Investment">Investment</option>
            <option value="Side Project">Side Project</option>
            <option value="Gift">Gift</option>
            <option value="Other">Other</option>
          </select>
        </div>

        <div className="form-group">
          <label htmlFor="income-date">Date</label>
          <input
            type="date"
            id="income-date"
            name="date"
            value={formData.date}
            onChange={handleChange}
            required
            data-testid="income-date"
          />
        </div>

        <button 
          type="submit" 
          className="btn-primary"
          disabled={loading}
          data-testid="income-submit"
        >
          {loading ? 'Adding...' : 'Add Income'}
        </button>
      </form>
    </div>
  );
};

export default IncomeForm;
