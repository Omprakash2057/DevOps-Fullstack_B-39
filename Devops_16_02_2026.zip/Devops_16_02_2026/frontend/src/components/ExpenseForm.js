import React, { useState } from 'react';
import axios from 'axios';

const ExpenseForm = () => {
  const [formData, setFormData] = useState({
    description: '',
    amount: '',
    category: 'Food',
    date: new Date().toISOString().split('T')[0]
  });
  const [message, setMessage] = useState({ type: '', text: '' });
  const [loading, setLoading] = useState(false);

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setMessage({ type: '', text: '' });

    try {
      await axios.post('/api/expenses', formData);
      setMessage({ type: 'success', text: 'Expense added successfully!' });
      setFormData({
        description: '',
        amount: '',
        category: 'Food',
        date: new Date().toISOString().split('T')[0]
      });
      
      // Trigger refresh of expense list
      window.dispatchEvent(new Event('expenseAdded'));
    } catch (err) {
      setMessage({ type: 'error', text: 'Failed to add expense. Please try again.' });
      console.error('Error adding expense:', err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="card" data-testid="expense-form">
      <h2>Add New Expense</h2>
      
      {message.text && (
        <div 
          className={message.type === 'success' ? 'success-message' : 'error-message'}
          data-testid="expense-message"
        >
          {message.text}
        </div>
      )}

      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label htmlFor="expense-description">Description</label>
          <input
            type="text"
            id="expense-description"
            name="description"
            value={formData.description}
            onChange={handleChange}
            required
            data-testid="expense-description"
          />
        </div>

        <div className="form-group">
          <label htmlFor="expense-amount">Amount ($)</label>
          <input
            type="number"
            id="expense-amount"
            name="amount"
            value={formData.amount}
            onChange={handleChange}
            step="0.01"
            min="0"
            required
            data-testid="expense-amount"
          />
        </div>

        <div className="form-group">
          <label htmlFor="expense-category">Category</label>
          <select
            id="expense-category"
            name="category"
            value={formData.category}
            onChange={handleChange}
            data-testid="expense-category"
          >
            <option value="Food">Food</option>
            <option value="Transportation">Transportation</option>
            <option value="Entertainment">Entertainment</option>
            <option value="Utilities">Utilities</option>
            <option value="Healthcare">Healthcare</option>
            <option value="Other">Other</option>
          </select>
        </div>

        <div className="form-group">
          <label htmlFor="expense-date">Date</label>
          <input
            type="date"
            id="expense-date"
            name="date"
            value={formData.date}
            onChange={handleChange}
            required
            data-testid="expense-date"
          />
        </div>

        <button 
          type="submit" 
          className="btn-primary"
          disabled={loading}
          data-testid="expense-submit"
        >
          {loading ? 'Adding...' : 'Add Expense'}
        </button>
      </form>
    </div>
  );
};

export default ExpenseForm;
