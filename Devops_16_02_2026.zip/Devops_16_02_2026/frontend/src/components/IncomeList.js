import React, { useState, useEffect } from 'react';
import axios from 'axios';

const IncomeList = () => {
  const [incomes, setIncomes] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    fetchIncomes();

    // Listen for new income additions
    const handleIncomeAdded = () => {
      fetchIncomes();
    };
    window.addEventListener('incomeAdded', handleIncomeAdded);
    
    return () => {
      window.removeEventListener('incomeAdded', handleIncomeAdded);
    };
  }, []);

  const fetchIncomes = async () => {
    try {
      setLoading(true);
      const response = await axios.get('/api/incomes');
      setIncomes(response.data);
      setError(null);
    } catch (err) {
      setError('Failed to load incomes');
      console.error('Error fetching incomes:', err);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return <div className="loading">Loading incomes...</div>;
  }

  if (error) {
    return <div className="error-message">{error}</div>;
  }

  return (
    <div className="card" data-testid="income-list">
      <h2>Income History</h2>
      
      {incomes.length === 0 ? (
        <p>No incomes recorded yet.</p>
      ) : (
        <div className="list">
          {incomes.map((income) => (
            <div key={income.id} className="list-item" data-testid={`income-item-${income.id}`}>
              <div className="list-item-info">
                <div className="list-item-description">{income.description}</div>
                <div className="list-item-details">
                  {income.source} • {income.date}
                </div>
              </div>
              <div className="list-item-amount amount-income">
                ${income.amount.toFixed(2)}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default IncomeList;
