import React, { useState, useEffect } from 'react';
import axios from 'axios';

const Dashboard = () => {
  const [summary, setSummary] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    fetchSummary();
  }, []);

  const fetchSummary = async () => {
    try {
      setLoading(true);
      const response = await axios.get('/api/summary');
      setSummary(response.data);
      setError(null);
    } catch (err) {
      setError('Failed to load summary data');
      console.error('Error fetching summary:', err);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return <div className="loading" data-testid="loading">Loading dashboard...</div>;
  }

  if (error) {
    return <div className="error-message" data-testid="error">{error}</div>;
  }

  return (
    <div className="dashboard" data-testid="dashboard">
      <h2>Financial Summary</h2>
      <div className="summary-grid">
        <div className="summary-card income-card">
          <h3>Total Income</h3>
          <p className="summary-amount" data-testid="total-income">
            ${summary?.totalIncome?.toFixed(2) || '0.00'}
          </p>
          <span className="summary-count">{summary?.incomeCount || 0} transactions</span>
        </div>
        
        <div className="summary-card expense-card">
          <h3>Total Expenses</h3>
          <p className="summary-amount" data-testid="total-expenses">
            ${summary?.totalExpenses?.toFixed(2) || '0.00'}
          </p>
          <span className="summary-count">{summary?.expenseCount || 0} transactions</span>
        </div>
        
        <div className="summary-card balance-card">
          <h3>Balance</h3>
          <p 
            className={`summary-amount ${summary?.balance >= 0 ? 'positive' : 'negative'}`}
            data-testid="balance"
          >
            ${summary?.balance?.toFixed(2) || '0.00'}
          </p>
          <span className="summary-count">Current balance</span>
        </div>
      </div>
      
      <button 
        onClick={fetchSummary} 
        className="btn-primary"
        style={{ marginTop: '1rem' }}
        data-testid="refresh-button"
      >
        Refresh Data
      </button>
    </div>
  );
};

export default Dashboard;
