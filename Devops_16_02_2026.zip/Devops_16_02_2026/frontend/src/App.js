import React, { useState } from 'react';
import './App.css';
import Dashboard from './components/Dashboard';
import ExpenseForm from './components/ExpenseForm';
import IncomeForm from './components/IncomeForm';
import ExpenseList from './components/ExpenseList';
import IncomeList from './components/IncomeList';

function App() {
  const [activeTab, setActiveTab] = useState('dashboard');

  return (
    <div className="App">
      <header className="App-header">
        <h1>💰 Personal Finance Tracker</h1>
      </header>
      
      <nav className="App-nav">
        <button 
          className={activeTab === 'dashboard' ? 'active' : ''}
          onClick={() => setActiveTab('dashboard')}
          data-testid="nav-dashboard"
        >
          Dashboard
        </button>
        <button 
          className={activeTab === 'expenses' ? 'active' : ''}
          onClick={() => setActiveTab('expenses')}
          data-testid="nav-expenses"
        >
          Expenses
        </button>
        <button 
          className={activeTab === 'income' ? 'active' : ''}
          onClick={() => setActiveTab('income')}
          data-testid="nav-income"
        >
          Income
        </button>
      </nav>

      <main className="App-main">
        {activeTab === 'dashboard' && <Dashboard />}
        {activeTab === 'expenses' && (
          <div className="page-content">
            <ExpenseForm />
            <ExpenseList />
          </div>
        )}
        {activeTab === 'income' && (
          <div className="page-content">
            <IncomeForm />
            <IncomeList />
          </div>
        )}
      </main>
    </div>
  );
}

export default App;
