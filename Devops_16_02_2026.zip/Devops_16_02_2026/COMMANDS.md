# 📋 Available Commands Reference

## Root Level Commands

```bash
# Install all dependencies (backend, frontend, e2e)
npm run install:all

# Start backend server
npm run start:backend

# Start frontend server
npm run start:frontend

# Run E2E tests
npm run test:e2e

# Open Cypress test UI
npm run test:open

# Setup project (install all dependencies)
npm run setup

# Start both backend and frontend concurrently
npm run dev

# Clean all node_modules and package-lock files
npm run clean
```

---

## Backend Commands

```bash
cd backend

# Start server in production mode
npm start

# Start server with nodemon (auto-reload)
npm run dev

# Run tests
npm test
```

**Backend runs on**: http://localhost:5000

---

## Frontend Commands

```bash
cd frontend

# Start development server
npm start

# Build for production
npm run build

# Run tests
npm test

# Run tests without watch mode
npm test -- --watchAll=false

# Eject configuration (careful!)
npm run eject
```

**Frontend runs on**: http://localhost:3000

---

## E2E Test Commands

```bash
cd e2e

# Run tests in headless mode (CI)
npm run test:e2e

# Open Cypress Test Runner (interactive)
npm run cypress:open

# Run Cypress tests
npm run cypress:run

# Run specific test file
npx cypress run --spec "cypress/e2e/dashboard.cy.js"

# Run tests in specific browser
npx cypress run --browser chrome

# Run tests with video disabled
npx cypress run --video false

# Run tests with headed mode
npx cypress run --headed
```

---

## Automated Test Runners

### Windows
```bash
# Run complete test suite
run-tests.bat

# Verify project setup
verify-setup.bat
```

### Linux/Mac
```bash
# Make scripts executable (first time only)
chmod +x run-tests.sh
chmod +x verify-setup.sh

# Run complete test suite
./run-tests.sh

# Verify project setup
./verify-setup.sh
```

---

## Git Commands

```bash
# Initialize repository
git init

# Add all files
git add .

# Commit changes
git commit -m "Initial commit: Personal Finance Tracker with E2E tests"

# Add remote (replace with your repo URL)
git remote add origin https://github.com/username/repo.git

# Push to GitHub
git push -u origin main

# Check status
git status

# View logs
git log --oneline
```

---

## Useful Development Commands

### Check Ports
```bash
# Windows - Check if port is in use
netstat -ano | findstr :5000
netstat -ano | findstr :3000

# Linux/Mac - Check if port is in use
lsof -ti:5000
lsof -ti:3000
```

### Kill Processes
```bash
# Windows - Kill process by PID
taskkill /PID <PID> /F

# Linux/Mac - Kill process on port
lsof -ti:5000 | xargs kill -9
lsof -ti:3000 | xargs kill -9
```

### API Testing
```bash
# Test backend health
curl http://localhost:5000/api/health

# Get summary data
curl http://localhost:5000/api/summary

# Get expenses
curl http://localhost:5000/api/expenses

# Get incomes
curl http://localhost:5000/api/incomes

# Add expense (POST)
curl -X POST http://localhost:5000/api/expenses \
  -H "Content-Type: application/json" \
  -d '{"description":"Test","amount":10.50,"category":"Food","date":"2026-02-16"}'

# Add income (POST)
curl -X POST http://localhost:5000/api/incomes \
  -H "Content-Type: application/json" \
  -d '{"description":"Test","amount":100,"source":"Job","date":"2026-02-16"}'

# Reset data
curl -X POST http://localhost:5000/api/reset
```

---

## Cypress Specific Commands

### Interactive Mode
```bash
cd e2e

# Open Cypress with specific browser
npx cypress open --browser chrome
npx cypress open --browser firefox
npx cypress open --browser edge

# Open specific test
npx cypress open --spec "cypress/e2e/dashboard.cy.js"
```

### Headless Mode
```bash
cd e2e

# Run all tests
npx cypress run

# Run specific test
npx cypress run --spec "cypress/e2e/dashboard.cy.js"

# Run tests in Chrome
npx cypress run --browser chrome

# Run tests without video
npx cypress run --video false

# Run tests with specific viewport
npx cypress run --config viewportWidth=1920,viewportHeight=1080
```

### Clear Cache
```bash
cd e2e

# Clear Cypress cache
npx cypress cache clear

# Verify Cypress installation
npx cypress verify
```

---

## Troubleshooting Commands

### Clean Installation
```bash
# Remove all node_modules
rm -rf backend/node_modules
rm -rf frontend/node_modules
rm -rf e2e/node_modules
rm -rf node_modules

# Remove all package-lock files
rm backend/package-lock.json
rm frontend/package-lock.json
rm e2e/package-lock.json
rm package-lock.json

# Reinstall everything
npm run install:all
```

### Clear Build Artifacts
```bash
# Frontend
rm -rf frontend/build

# Cypress
rm -rf e2e/cypress/screenshots
rm -rf e2e/cypress/videos

# Logs
rm backend.log
rm frontend.log
```

### Check Node & npm Versions
```bash
# Check Node.js version
node -v

# Check npm version
npm -v

# Check installed packages
npm list --depth=0
```

---

## CI/CD Commands (GitHub Actions)

### Trigger Workflow Manually
1. Go to GitHub repository
2. Click "Actions" tab
3. Select workflow
4. Click "Run workflow"
5. Select branch
6. Click "Run workflow" button

### View Workflow Status
```bash
# Using GitHub CLI (if installed)
gh workflow list
gh workflow view
gh run list
gh run view <run-id>
```

---

## Package Management

### Update Dependencies
```bash
# Check for outdated packages
npm outdated

# Update all dependencies
npm update

# Update specific package
npm update <package-name>

# Install latest version of package
npm install <package-name>@latest
```

### Audit Security
```bash
# Check for vulnerabilities
npm audit

# Fix vulnerabilities automatically
npm audit fix

# Force fix (may have breaking changes)
npm audit fix --force
```

---

## Quick Reference for Common Tasks

### Starting the Application
```bash
# Option 1: Use automated script
run-tests.bat  # Windows
./run-tests.sh # Linux/Mac

# Option 2: Manual (3 terminals)
# Terminal 1
cd backend && npm start

# Terminal 2
cd frontend && npm start

# Terminal 3
cd e2e && npm run cypress:open
```

### Running Tests Only
```bash
# Make sure backend and frontend are running first!
cd e2e
npm run test:e2e
```

### Checking Everything Works
```bash
# Run verification script
verify-setup.bat  # Windows
./verify-setup.sh # Linux/Mac
```

---

## Environment Variables

### Backend (.env)
```bash
# Create file: backend/.env
PORT=5000
NODE_ENV=development
```

### Frontend (.env)
```bash
# Create file: frontend/.env
REACT_APP_API_URL=http://localhost:5000
PORT=3000
```

---

## Build Commands

### Production Build
```bash
# Build frontend
cd frontend
npm run build

# Output: frontend/build/

# Serve production build (requires serve package)
npx serve -s build
```

### Docker Commands (Future Enhancement)
```bash
# Build image
docker build -t finance-tracker .

# Run container
docker run -p 3000:3000 -p 5000:5000 finance-tracker

# Docker Compose
docker-compose up
docker-compose down
```

---

## Help Commands

### Get Help
```bash
# npm help
npm help

# Cypress help
npx cypress --help

# Node help
node --help
```

---

## Keyboard Shortcuts (VS Code)

```
Ctrl + `         Open terminal
Ctrl + Shift + ` New terminal
Ctrl + P         Quick file open
Ctrl + Shift + F Find in files
Ctrl + B         Toggle sidebar
F5              Start debugging
```

---

## Quick File Locations

```
Backend:          backend/server.js
Frontend:         frontend/src/App.js
E2E Tests:        e2e/cypress/e2e/
CI Workflows:     .github/workflows/
Documentation:    *.md files in root
Cypress Config:   e2e/cypress.config.js
Test Screenshots: e2e/cypress/screenshots/
Test Videos:      e2e/cypress/videos/
```

---

## Most Common Command Sequences

### First Time Setup
```bash
1. verify-setup.bat
2. npm run install:all
3. run-tests.bat
```

### Daily Development
```bash
1. cd backend && npm start  (Terminal 1)
2. cd frontend && npm start (Terminal 2)
3. Make changes
4. cd e2e && npm run cypress:open (Terminal 3)
```

### Before Committing
```bash
1. cd e2e && npm run test:e2e
2. Check all tests pass
3. git add .
4. git commit -m "message"
5. git push
```

---

## Need More Help?

Check these files:
- [QUICKSTART.md](QUICKSTART.md) - Quick start guide
- [TESTING.md](TESTING.md) - Detailed testing guide
- [README.md](README.md) - Complete documentation
- [ARCHITECTURE.md](ARCHITECTURE.md) - System architecture

---

**Last Updated**: February 16, 2026
