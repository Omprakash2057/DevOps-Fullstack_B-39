#!/bin/bash

# Colors for output
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

echo -e "${YELLOW}========================================${NC}"
echo -e "${YELLOW}Personal Finance Tracker - E2E Test Runner${NC}"
echo -e "${YELLOW}========================================${NC}"
echo ""

# Function to check if a port is in use
check_port() {
    if lsof -Pi :$1 -sTCP:LISTEN -t >/dev/null 2>&1 ; then
        return 0
    else
        return 1
    fi
}

# Function to cleanup processes
cleanup() {
    echo -e "\n${YELLOW}Cleaning up processes...${NC}"
    if [ -f backend.pid ]; then
        kill $(cat backend.pid) 2>/dev/null || true
        rm backend.pid
    fi
    if [ -f frontend.pid ]; then
        kill $(cat frontend.pid) 2>/dev/null || true
        rm frontend.pid
    fi
    pkill -f "node.*server.js" 2>/dev/null || true
    pkill -f "react-scripts start" 2>/dev/null || true
    echo -e "${GREEN}✓ Cleanup complete${NC}"
}

# Set up trap to cleanup on script exit
trap cleanup EXIT

# Step 1: Install dependencies
echo -e "${YELLOW}Step 1: Installing dependencies...${NC}"
cd backend && npm install && cd ..
cd frontend && npm install && cd ..
cd e2e && npm install && cd ..
echo -e "${GREEN}✓ Dependencies installed${NC}"
echo ""

# Step 2: Start Backend
echo -e "${YELLOW}Step 2: Starting backend server...${NC}"
cd backend
npm start > ../backend.log 2>&1 &
echo $! > ../backend.pid
cd ..

# Wait for backend to be ready
echo "Waiting for backend to start..."
for i in {1..30}; do
    if curl -f http://localhost:5000/api/health >/dev/null 2>&1; then
        echo -e "${GREEN}✓ Backend is ready${NC}"
        break
    fi
    if [ $i -eq 30 ]; then
        echo -e "${RED}✗ Backend failed to start${NC}"
        cat backend.log
        exit 1
    fi
    sleep 2
done
echo ""

# Step 3: Start Frontend
echo -e "${YELLOW}Step 3: Starting frontend server...${NC}"
cd frontend
CI=false npm start > ../frontend.log 2>&1 &
echo $! > ../frontend.pid
cd ..

# Wait for frontend to be ready
echo "Waiting for frontend to start..."
for i in {1..60}; do
    if curl -f http://localhost:3000 >/dev/null 2>&1; then
        echo -e "${GREEN}✓ Frontend is ready${NC}"
        break
    fi
    if [ $i -eq 60 ]; then
        echo -e "${RED}✗ Frontend failed to start${NC}"
        cat frontend.log
        exit 1
    fi
    sleep 2
done
echo ""

# Step 4: Run E2E Tests
echo -e "${YELLOW}Step 4: Running E2E tests...${NC}"
cd e2e
npm run test:e2e
TEST_EXIT_CODE=$?
cd ..

echo ""
if [ $TEST_EXIT_CODE -eq 0 ]; then
    echo -e "${GREEN}========================================${NC}"
    echo -e "${GREEN}✓ All E2E tests passed successfully!${NC}"
    echo -e "${GREEN}========================================${NC}"
else
    echo -e "${RED}========================================${NC}"
    echo -e "${RED}✗ Some E2E tests failed${NC}"
    echo -e "${RED}========================================${NC}"
    echo -e "${YELLOW}Check screenshots in: e2e/cypress/screenshots/${NC}"
    echo -e "${YELLOW}Check videos in: e2e/cypress/videos/${NC}"
fi

echo ""
echo -e "${YELLOW}Test artifacts:${NC}"
echo -e "  Screenshots: e2e/cypress/screenshots/"
echo -e "  Videos: e2e/cypress/videos/"
echo ""

exit $TEST_EXIT_CODE
