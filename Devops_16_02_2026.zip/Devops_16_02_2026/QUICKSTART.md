# 🚀 Quick Start Guide

## Personal Finance Tracker - E2E Integration Testing

### Prerequisites
- Node.js 18.x or higher
- npm package manager
- Git (for version control)

---

## Option 1: Automated Test Runner (Recommended)

### Windows
```bash
run-tests.bat
```

### Linux/Mac
```bash
chmod +x run-tests.sh
./run-tests.sh
```

This script will:
1. ✅ Install all dependencies
2. ✅ Start backend server
3. ✅ Start frontend server
4. ✅ Run E2E tests
5. ✅ Save screenshots/videos
6. ✅ Clean up processes

---

## Option 2: Manual Setup

### Step 1: Install Dependencies
```bash
# Backend
cd backend
npm install

# Frontend
cd ../frontend
npm install

# E2E Tests
cd ../e2e
npm install
cd ..
```

### Step 2: Start Backend (Terminal 1)
```bash
cd backend
npm start
```
Backend runs on: http://localhost:5000

### Step 3: Start Frontend (Terminal 2)
```bash
cd frontend
npm start
```
Frontend runs on: http://localhost:3000

### Step 4: Run Tests (Terminal 3)
```bash
cd e2e
npm run test:e2e
```

---

## 🎯 Test Results

### Success
- All tests pass ✅
- Videos saved to: `e2e/cypress/videos/`

### Failure
- Screenshots saved to: `e2e/cypress/screenshots/`
- Videos saved to: `e2e/cypress/videos/`
- Check console for error details

---

## 🔍 Viewing the App

Once running, access:
- **Frontend**: http://localhost:3000
- **Backend API**: http://localhost:5000/api/summary
- **Health Check**: http://localhost:5000/api/health

---

## 🧪 Test Scenarios Covered

✅ **Dashboard**
- Load summary data
- Verify calculations
- Refresh functionality

✅ **Expenses**
- Add new expense
- Verify in list
- Form validation

✅ **Income**
- Add new income
- Verify in list
- Dashboard updates

✅ **Integration**
- Complete workflows
- Cross-page navigation
- API integration

---

## 📊 CI/CD Pipeline

### GitHub Actions
Push code to trigger:
- Automated builds
- E2E tests
- Artifact storage

### View Results
1. Go to GitHub Actions tab
2. Check workflow status
3. Download artifacts

---

## 🐛 Troubleshooting

### Port in Use
```bash
# Windows
netstat -ano | findstr :5000
taskkill /PID <PID> /F

# Linux/Mac
lsof -ti:5000 | xargs kill -9
```

### Tests Failing
1. Check backend is running
2. Check frontend is running
3. Verify http://localhost:5000/api/health
4. Verify http://localhost:3000
5. Review screenshots

### Clean Install
```bash
# Remove all node_modules
rm -rf backend/node_modules
rm -rf frontend/node_modules
rm -rf e2e/node_modules

# Reinstall
cd backend && npm install && cd ..
cd frontend && npm install && cd ..
cd e2e && npm install && cd ..
```

---

## 📁 Important Files

```
├── run-tests.bat/sh       # Test runner scripts
├── README.md              # Full documentation
├── TESTING.md            # Testing guide
├── ASSIGNMENT.md         # Assignment details
├── backend/server.js     # API server
├── frontend/src/App.js   # Main app
└── e2e/cypress/e2e/      # Test files
```

---

## 💡 Quick Commands

```bash
# Open Cypress UI
cd e2e && npm run cypress:open

# Run specific test
cd e2e && npx cypress run --spec "cypress/e2e/dashboard.cy.js"

# View backend logs
cd backend && npm start

# Build frontend
cd frontend && npm run build

# Health check
curl http://localhost:5000/api/health
```

---

## ✨ Features

- 💰 Track income and expenses
- 📊 View financial summary
- 📱 Responsive design
- 🔄 Real-time updates
- ✅ Form validation
- 🧪 Comprehensive E2E tests
- 🚀 CI/CD automation
- 📸 Screenshot capture
- 🎥 Video recording

---

## 📚 Documentation

- [README.md](README.md) - Complete project documentation
- [TESTING.md](TESTING.md) - Detailed testing guide
- [ASSIGNMENT.md](ASSIGNMENT.md) - Assignment completion details

---

## 🎓 Next Steps

1. ✅ Run the automated test script
2. ✅ View the application in browser
3. ✅ Check test results and artifacts
4. ✅ Push to GitHub to trigger CI/CD
5. ✅ Review GitHub Actions results

---

**Need Help?** Check [TESTING.md](TESTING.md) for detailed troubleshooting and debugging guide.

**Ready to Deploy?** Check [README.md](README.md) for deployment instructions.
