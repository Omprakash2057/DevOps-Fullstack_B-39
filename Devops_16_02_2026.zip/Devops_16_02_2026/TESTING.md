# Test Execution Guide

## Running E2E Tests Locally

### Quick Start

#### On Windows:
```bash
./run-tests.bat
```

#### On Linux/Mac:
```bash
chmod +x run-tests.sh
./run-tests.sh
```

### Manual Execution

If you prefer to run each step manually:

#### Step 1: Install Dependencies
```bash
# Backend
cd backend
npm install

# Frontend
cd ../frontend
npm install

# E2E Tests
cd ../e2e
npm install
```

#### Step 2: Start Backend Server
```bash
cd backend
npm start
# Server runs on http://localhost:5000
# Keep this terminal open
```

#### Step 3: Start Frontend Server (New Terminal)
```bash
cd frontend
npm start
# App runs on http://localhost:3000
# Keep this terminal open
```

#### Step 4: Run E2E Tests (New Terminal)
```bash
cd e2e
npm run test:e2e
# Or open Cypress UI:
npm run cypress:open
```

## Understanding Test Results

### Success
When all tests pass, you'll see:
```
✓ All E2E tests passed successfully!
```

### Failure
When tests fail:
- Screenshots are saved to: `e2e/cypress/screenshots/`
- Videos are saved to: `e2e/cypress/videos/`
- Check console output for specific failures

## Test Artifacts

### Screenshots
- Captured on test failures
- Located in: `e2e/cypress/screenshots/`
- Organized by test spec and test name
- PNG format

### Videos
- Recorded for all test runs
- Located in: `e2e/cypress/videos/`
- MP4 format
- Shows full test execution

## CI/CD Pipeline

### GitHub Actions
The project includes automated workflows:

1. **e2e-tests.yml** - Dedicated E2E testing
   - Triggers on: push, pull request
   - Runs all E2E tests
   - Uploads artifacts on failure

2. **ci-cd.yml** - Full CI/CD pipeline
   - Lint and unit tests
   - Build application
   - E2E integration tests
   - Artifact storage

### Viewing CI Results
1. Go to Actions tab in GitHub
2. Select workflow run
3. Download artifacts (screenshots, videos)
4. Check job logs for details

## Test Scenarios

### Dashboard Tests (`dashboard.cy.js`)
- Load dashboard and verify summary data
- Check financial calculations
- Test refresh functionality
- Verify transaction counts

### Expense Tests (`expenses.cy.js`)
- Navigate to expenses page
- Display existing expenses
- Add new expense
- Verify expense appears in list
- Form validation

### Income Tests (`income.cy.js`)
- Navigate to income page
- Display existing incomes
- Add new income
- Verify income appears in list
- Form validation

### Integration Tests (`integration.cy.js`)
- Complete workflow tests
- Add income and verify dashboard
- Add expense and verify dashboard
- Full application flow
- Cross-page navigation
- Backend API integration

## Debugging Tests

### Open Cypress Test Runner
```bash
cd e2e
npm run cypress:open
```

This opens the interactive Cypress UI where you can:
- Run tests individually
- See tests execute in real-time
- Use dev tools for debugging
- See network requests
- Inspect DOM elements

### Check Logs

#### Backend Logs
```bash
# If using run-tests script
cat backend.log  # Linux/Mac
type backend.log  # Windows
```

#### Frontend Logs
```bash
# If using run-tests script
cat frontend.log  # Linux/Mac
type frontend.log  # Windows
```

### Common Issues

#### Port Already in Use
```bash
# Kill processes on port 5000 (backend)
lsof -ti:5000 | xargs kill -9  # Linux/Mac
netstat -ano | findstr :5000   # Windows (then use taskkill)

# Kill processes on port 3000 (frontend)
lsof -ti:3000 | xargs kill -9  # Linux/Mac
netstat -ano | findstr :3000   # Windows (then use taskkill)
```

#### Tests Timeout
- Increase timeout in `cypress.config.js`
- Check if servers are running
- Verify network connectivity

#### Module Not Found
```bash
# Reinstall dependencies
cd backend && rm -rf node_modules && npm install
cd ../frontend && rm -rf node_modules && npm install
cd ../e2e && rm -rf node_modules && npm install
```

## Test Configuration

### Cypress Configuration (`e2e/cypress.config.js`)
- Base URL: `http://localhost:3000`
- Screenshot on failure: Enabled
- Video recording: Enabled
- Default timeout: 10 seconds
- Viewport: 1280x720

### Environment Variables

#### Backend
Create `backend/.env`:
```env
PORT=5000
NODE_ENV=test
```

#### Frontend
Create `frontend/.env`:
```env
REACT_APP_API_URL=http://localhost:5000
```

## Best Practices

### Writing Tests
1. Use descriptive test names
2. Use data-testid attributes
3. Reset state before each test
4. Wait for elements properly
5. Assert expected behavior

### Running Tests
1. Always start with clean state
2. Run backend and frontend first
3. Check for port conflicts
4. Monitor test artifacts
5. Review failures immediately

### CI/CD
1. Run tests on every push
2. Store artifacts for 30 days
3. Review screenshots on failures
4. Monitor test duration
5. Update tests with code changes

## Performance Tips

### Faster Test Execution
- Use `cy.intercept()` to stub API calls
- Minimize network requests
- Use shorter timeouts when safe
- Run specific specs during development

### Resource Management
- Clean up after tests
- Close unnecessary processes
- Monitor memory usage
- Clear artifacts periodically

## Continuous Improvement

### Adding New Tests
1. Identify new feature
2. Write test scenario
3. Implement test
4. Verify locally
5. Push to CI

### Updating Existing Tests
1. Review test coverage
2. Identify gaps
3. Update assertions
4. Run full test suite
5. Commit changes

## Support

For issues or questions:
1. Check test logs
2. Review screenshots/videos
3. Inspect CI workflow logs
4. Check GitHub Actions tab
5. Review Cypress documentation

## Quick Reference

### Commands
```bash
# Run tests headless
npm run test:e2e

# Open Cypress UI
npm run cypress:open

# Run specific test
npx cypress run --spec "cypress/e2e/dashboard.cy.js"

# Clear cache
npm run clean  # (if configured)
```

### Paths
- Tests: `e2e/cypress/e2e/`
- Screenshots: `e2e/cypress/screenshots/`
- Videos: `e2e/cypress/videos/`
- Config: `e2e/cypress.config.js`
- Support: `e2e/cypress/support/`

### URLs
- Frontend: http://localhost:3000
- Backend: http://localhost:5000
- API Health: http://localhost:5000/api/health
- API Summary: http://localhost:5000/api/summary
