# Personal Finance Tracker

A full-stack Personal Finance Tracker application with automated E2E integration testing.

## 🚀 Features

- **Dashboard**: View financial summary with total income, expenses, and balance
- **Expense Tracking**: Add and manage expenses with categories
- **Income Tracking**: Record and track various income sources
- **Real-time Updates**: Automatic data refresh across pages
- **Responsive UI**: Modern, user-friendly interface

## 📋 Tech Stack

### Backend
- Node.js
- Express.js
- CORS enabled for cross-origin requests
- RESTful API design

### Frontend
- React 18
- Axios for API calls
- CSS3 with modern styling
- Responsive design

### Testing
- Cypress for E2E testing
- Automated integration tests
- Screenshot capture on failures
- Video recording of test runs

## 🏗️ Project Structure

```
Devops_16_02_2026/
├── backend/                 # Express.js backend
│   ├── server.js           # Main server file
│   ├── package.json        # Backend dependencies
│   └── .gitignore
├── frontend/               # React frontend
│   ├── src/
│   │   ├── components/    # React components
│   │   ├── App.js         # Main app component
│   │   └── index.js       # Entry point
│   ├── public/
│   ├── package.json       # Frontend dependencies
│   └── .gitignore
├── e2e/                    # E2E tests
│   ├── cypress/
│   │   ├── e2e/          # Test files
│   │   └── support/      # Cypress support files
│   ├── cypress.config.js  # Cypress configuration
│   └── package.json       # E2E dependencies
└── .github/
    └── workflows/         # CI/CD pipelines
        ├── e2e-tests.yml  # E2E testing workflow
        └── ci-cd.yml      # Main CI/CD workflow
```

## 🔧 Installation & Setup

### Prerequisites
- Node.js 18.x or higher
- npm or yarn package manager

### Backend Setup
```bash
cd backend
npm install
npm start
# Server runs on http://localhost:5000
```

### Frontend Setup
```bash
cd frontend
npm install
npm start
# App runs on http://localhost:3000
```

### E2E Tests Setup
```bash
cd e2e
npm install
```

## 🧪 Running Tests

### Run E2E Tests (Headless)
```bash
cd e2e
npm run test:e2e
```

### Open Cypress Test Runner
```bash
cd e2e
npm run cypress:open
```

## 📊 API Endpoints

| Method | Endpoint          | Description                |
|--------|------------------|----------------------------|
| GET    | `/api/health`    | Health check               |
| GET    | `/api/summary`   | Get financial summary      |
| GET    | `/api/expenses`  | Get all expenses           |
| POST   | `/api/expenses`  | Add new expense            |
| GET    | `/api/incomes`   | Get all incomes            |
| POST   | `/api/incomes`   | Add new income             |
| POST   | `/api/reset`     | Reset data (for testing)   |

## 🔄 CI/CD Pipeline

The project includes automated CI/CD workflows that:

1. **Build Stage**
   - Install dependencies
   - Build frontend application
   - Run unit tests (if configured)

2. **E2E Testing Stage**
   - Start backend server
   - Start frontend server
   - Run Cypress E2E tests
   - Capture screenshots on failures
   - Record test videos

3. **Artifact Storage**
   - Store test videos
   - Store failure screenshots
   - Save test results
   - 30-day retention period

## 🎯 E2E Test Scenarios

### Dashboard Tests
- ✅ Navigate to Dashboard and load summary data
- ✅ Verify financial calculations
- ✅ Test data refresh functionality

### Expense Tests
- ✅ Add new expense
- ✅ Verify expense appears in list
- ✅ Validate form fields
- ✅ Test multiple expense additions

### Income Tests
- ✅ Add new income
- ✅ Verify income appears in list
- ✅ Validate form fields
- ✅ Test multiple income additions

### Integration Tests
- ✅ Complete workflow: Add income → Add expense → Verify dashboard
- ✅ Cross-page data consistency
- ✅ Backend API integration
- ✅ Navigation flow

## 📸 Screenshot Capture

Screenshots are automatically captured:
- On test failures
- Stored as CI artifacts
- Retained for 30 days
- Named with test details

## 🎥 Video Recording

Test videos are:
- Recorded for all tests
- Stored as CI artifacts
- Retained for 30 days
- Available for debugging

## 🚦 Running Locally

### Start All Services
```bash
# Terminal 1 - Backend
cd backend
npm start

# Terminal 2 - Frontend
cd frontend
npm start

# Terminal 3 - Run E2E Tests
cd e2e
npm run test:e2e
```

## 📝 Environment Variables

### Backend (.env)
```env
PORT=5000
NODE_ENV=development
```

### Frontend (.env)
```env
REACT_APP_API_URL=http://localhost:5000
```

## 🔐 Data Persistence

Currently using in-memory storage. To add database:
- MongoDB with Mongoose
- PostgreSQL with Sequelize
- MySQL with Sequelize
- SQLite for local development

## 🎨 UI Components

- **Dashboard**: Financial summary cards
- **Expense Form**: Add expense with category
- **Income Form**: Add income with source
- **Lists**: Display transactions with details
- **Navigation**: Tab-based routing

## ✨ Features & Highlights

✅ Full E2E integration testing  
✅ Automated CI/CD pipeline  
✅ Screenshot capture on failures  
✅ Video recording of tests  
✅ RESTful API design  
✅ Modern React architecture  
✅ Responsive UI design  
✅ Real-time data updates  
✅ Form validation  
✅ Error handling  

## 🐛 Troubleshooting

### Backend won't start
- Check if port 5000 is available
- Verify Node.js version (18.x+)
- Run `npm install` again

### Frontend won't start
- Check if port 3000 is available
- Clear node_modules and reinstall
- Verify React version compatibility

### E2E Tests fail
- Ensure backend is running on port 5000
- Ensure frontend is running on port 3000
- Check Cypress logs in `e2e/cypress/`

## 📚 Additional Resources

- [React Documentation](https://react.dev/)
- [Express.js Guide](https://expressjs.com/)
- [Cypress Documentation](https://docs.cypress.io/)
- [GitHub Actions](https://docs.github.com/en/actions)

## 👥 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Run E2E tests
5. Submit a pull request

## 📄 License

ISC License

## 🎓 Assignment Completion

This project fulfills the End-to-End Integration Testing assignment:

✅ **Setup**
- Cypress E2E testing configured
- Test scenarios: Dashboard, Expenses, Income
- Complete workflow validation

✅ **CI Pipeline Configuration**
- Build frontend ✓
- Start backend and frontend servers ✓
- Run E2E integration tests ✓
- Shut down services after execution ✓

✅ **Test Flow**
- Start Backend → Start Frontend → Run E2E Tests → Validate Results ✓

✅ **Bonus Challenge**
- Capture screenshots on test failure ✓
- Store test results and screenshots as CI artifacts ✓

✅ **Expected Output**
- Full application flow validated automatically ✓
- CI detects UI–API integration issues ✓
- Reliable end-to-end application verification ✓

---

**Made with ❤️ for DevOps Integration Testing Assignment**
