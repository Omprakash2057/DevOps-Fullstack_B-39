/**
 * Server Entry Point
 * Loads environment variables and starts the Express server
 */

// Load environment variables first
require('dotenv').config({
  path: process.env.NODE_ENV === 'production' 
    ? '.env.production' 
    : '.env.development'
});

const app = require('./src/app');
const { connectDB } = require('./src/config/db');

// ============================================
// ENVIRONMENT VERIFICATION
// ============================================

const PORT = process.env.PORT || 5000;
const NODE_ENV = process.env.NODE_ENV || 'development';
const DB_DIALECT = process.env.DB_DIALECT || 'sqlite';
const DB_PATH = process.env.DB_PATH || `./database_${NODE_ENV}.sqlite`;

console.log('');
console.log('='.repeat(60));
console.log('🚀 PERSONAL FINANCE TRACKER - BACKEND SERVER (SQL)');
console.log('='.repeat(60));
console.log(`📌 Environment: ${NODE_ENV.toUpperCase()}`);
console.log(`🔌 Port: ${PORT}`);
console.log(`🗄️  Database: ${DB_DIALECT.toUpperCase()}`);
if (DB_DIALECT === 'sqlite') {
  console.log(`📁 Database File: ${DB_PATH}`);
} else {
  console.log(`🗄️  DB Name: ${process.env.DB_NAME || 'Not set'}`);
}
console.log(`🕐 Started at: ${new Date().toLocaleString()}`);
console.log('='.repeat(60));
console.log('');

// ============================================
// DATABASE CONNECTION
// ============================================

connectDB();

// ============================================
// START SERVER
// ============================================

const server = app.listen(PORT, () => {
  console.log('');
  console.log('✅ SERVER STARTED SUCCESSFULLY!');
  console.log('');
  console.log(`🌐 Server running on: http://localhost:${PORT}`);
  console.log(`🔗 Health check: http://localhost:${PORT}/`);
  console.log(`📊 API Status: http://localhost:${PORT}/api/status`);
  console.log(`💰 Transactions: http://localhost:${PORT}/api/transactions`);
  console.log('');
  
  if (NODE_ENV === 'development') {
    console.log('🔍 Running in DEVELOPMENT mode:');
    console.log('   - Detailed logging enabled');
    console.log('   - MongoDB debug mode active');
    console.log('   - Stack traces visible');
  } else if (NODE_ENV === 'production') {
    console.log('🏭 Running in PRODUCTION mode:');
    console.log('   - Minimal logging');
    console.log('   - Optimized performance');
    console.log('   - Security enhanced');
  }
  
  console.log('');
  console.log('Press CTRL+C to stop the server');
  console.log('='.repeat(60));
  console.log('');
});

// ============================================
// GRACEFUL SHUTDOWN
// ============================================

process.on('SIGTERM', () => {
  console.log('');
  console.log('🛑 SIGTERM received. Shutting down gracefully...');
  server.close(() => {
    console.log('✅ Server closed');
    process.exit(0);
  });
});

process.on('SIGINT', () => {
  console.log('');
  console.log('🛑 SIGINT received. Shutting down gracefully...');
  server.close(() => {
    console.log('✅ Server closed');
    process.exit(0);
  });
});

// Handle uncaught exceptions
process.on('uncaughtException', (error) => {
  console.error('');
  console.error('💥 UNCAUGHT EXCEPTION:');
  console.error(error);
  console.error('');
  process.exit(1);
});

// Handle unhandled promise rejections
process.on('unhandledRejection', (error) => {
  console.error('');
  console.error('💥 UNHANDLED PROMISE REJECTION:');
  console.error(error);
  console.error('');
  process.exit(1);
});
