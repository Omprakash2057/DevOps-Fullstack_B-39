/**
 * Transaction Model (Sequelize)
 * Defines the schema for financial transactions using SQL
 */

const { DataTypes } = require('sequelize');
const { sequelize } = require('../config/db');

const Transaction = sequelize.define('Transaction', {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  description: {
    type: DataTypes.STRING(200),
    allowNull: false,
    validate: {
      notEmpty: {
        msg: 'Description is required'
      },
      len: {
        args: [1, 200],
        msg: 'Description cannot exceed 200 characters'
      }
    }
  },
  amount: {
    type: DataTypes.DECIMAL(10, 2),
    allowNull: false,
    validate: {
      notNull: {
        msg: 'Amount is required'
      },
      isDecimal: {
        msg: 'Amount must be a valid number'
      },
      min: {
        args: [0.01],
        msg: 'Amount must be greater than zero'
      }
    }
  },
  type: {
    type: DataTypes.ENUM('income', 'expense'),
    allowNull: false,
    validate: {
      notNull: {
        msg: 'Transaction type is required'
      },
      isIn: {
        args: [['income', 'expense']],
        msg: 'Type must be either income or expense'
      }
    }
  },
  category: {
    type: DataTypes.STRING(100),
    allowNull: false,
    validate: {
      notEmpty: {
        msg: 'Category is required'
      }
    }
  },
  date: {
    type: DataTypes.DATE,
    allowNull: false,
    defaultValue: DataTypes.NOW
  }
}, {
  tableName: 'transactions',
  timestamps: true, // Adds createdAt and updatedAt
  indexes: [
    {
      fields: ['type', 'date']
    },
    {
      fields: ['category']
    }
  ]
});

// Instance method to get transaction summary
Transaction.prototype.getSummary = function() {
  return `${this.type.toUpperCase()}: ${this.description} - $${Math.abs(this.amount)}`;
};

// Static method to calculate total by type
Transaction.getTotalByType = async function(type) {
  const result = await this.findOne({
    where: { type },
    attributes: [
      [sequelize.fn('SUM', sequelize.col('amount')), 'total']
    ],
    raw: true
  });
  
  return result && result.total ? parseFloat(result.total) : 0;
};

module.exports = Transaction;
