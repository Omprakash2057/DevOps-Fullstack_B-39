/**
 * Transaction Controller
 * Handles business logic for transaction operations (SQL/Sequelize version)
 */

const Transaction = require('../models/Transaction');
const { ValidationError } = require('sequelize');

// Environment-based logging
const isDevelopment = process.env.NODE_ENV === 'development';

const log = (message, data = null) => {
  if (isDevelopment) {
    console.log(`[DEV LOG] ${message}`, data ? data : '');
  }
};

/**
 * @desc    Get all transactions
 * @route   GET /api/transactions
 * @access  Public
 */
exports.getAllTransactions = async (req, res) => {
  try {
    log('Fetching all transactions...');
    
    const transactions = await Transaction.findAll({
      order: [['date', 'DESC']], // Sort by date, newest first
      limit: 100 // Limit to last 100 transactions
    });

    log('Transactions fetched successfully', { count: transactions.length });

    res.status(200).json({
      success: true,
      count: transactions.length,
      data: transactions,
      environment: process.env.NODE_ENV || 'unknown'
    });
  } catch (error) {
    log('Error fetching transactions', error.message);
    
    res.status(500).json({
      success: false,
      error: 'Server error while fetching transactions',
      message: isDevelopment ? error.message : undefined
    });
  }
};

/**
 * @desc    Create a new transaction
 * @route   POST /api/transactions
 * @access  Public
 */
exports.createTransaction = async (req, res) => {
  try {
    const { description, amount, type, category, date } = req.body;

    log('Creating new transaction', { description, amount, type, category });

    // Validation
    if (!description || !amount || !type || !category) {
      log('Validation failed: Missing required fields');
      return res.status(400).json({
        success: false,
        error: 'Please provide all required fields: description, amount, type, category'
      });
    }

    // Create transaction
    const transaction = await Transaction.create({
      description,
      amount: Math.abs(amount), // Store as positive number
      type: type.toLowerCase(),
      category,
      date: date || new Date()
    });

    log('Transaction created successfully', { id: transaction.id });

    res.status(201).json({
      success: true,
      data: transaction,
      environment: process.env.NODE_ENV || 'unknown'
    });
  } catch (error) {
    log('Error creating transaction', error.message);

    // Handle Sequelize validation errors
    if (error instanceof ValidationError) {
      const messages = error.errors.map(err => err.message);
      return res.status(400).json({
        success: false,
        error: messages
      });
    }

    res.status(500).json({
      success: false,
      error: 'Server error while creating transaction',
      message: isDevelopment ? error.message : undefined
    });
  }
};

/**
 * @desc    Get transaction summary (total income and expenses)
 * @route   GET /api/transactions/summary
 * @access  Public
 */
exports.getTransactionSummary = async (req, res) => {
  try {
    log('Calculating transaction summary...');

    const totalIncome = await Transaction.getTotalByType('income');
    const totalExpense = await Transaction.getTotalByType('expense');
    const balance = totalIncome - totalExpense;

    const summary = {
      totalIncome,
      totalExpense,
      balance,
      currency: 'USD'
    };

    log('Summary calculated', summary);

    res.status(200).json({
      success: true,
      data: summary,
      environment: process.env.NODE_ENV || 'unknown'
    });
  } catch (error) {
    log('Error calculating summary', error.message);

    res.status(500).json({
      success: false,
      error: 'Server error while calculating summary',
      message: isDevelopment ? error.message : undefined
    });
  }
};

/**
 * @desc    Delete a transaction
 * @route   DELETE /api/transactions/:id
 * @access  Public
 */
exports.deleteTransaction = async (req, res) => {
  try {
    const { id } = req.params;

    log(`Deleting transaction with ID: ${id}`);

    const deleted = await Transaction.destroy({
      where: { id }
    });

    if (!deleted) {
      log('Transaction not found');
      return res.status(404).json({
        success: false,
        error: 'Transaction not found'
      });
    }

    log('Transaction deleted successfully');

    res.status(200).json({
      success: true,
      data: {},
      message: 'Transaction deleted successfully'
    });
  } catch (error) {
    log('Error deleting transaction', error.message);

    res.status(500).json({
      success: false,
      error: 'Server error while deleting transaction',
      message: isDevelopment ? error.message : undefined
    });
  }
};
