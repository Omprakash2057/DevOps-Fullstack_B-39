/**
 * Transaction Routes
 * Defines API endpoints for transaction operations
 */

const express = require('express');
const router = express.Router();

const {
  getAllTransactions,
  createTransaction,
  getTransactionSummary,
  deleteTransaction
} = require('../controllers/transactionController');

// @route   GET /api/transactions/summary
// @desc    Get summary of all transactions (income, expense, balance)
// @access  Public
router.get('/summary', getTransactionSummary);

// @route   GET /api/transactions
// @desc    Get all transactions
// @access  Public
router.get('/', getAllTransactions);

// @route   POST /api/transactions
// @desc    Create a new transaction
// @access  Public
router.post('/', createTransaction);

// @route   DELETE /api/transactions/:id
// @desc    Delete a transaction by ID
// @access  Public
router.delete('/:id', deleteTransaction);

module.exports = router;
