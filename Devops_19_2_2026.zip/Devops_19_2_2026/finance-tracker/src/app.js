/**
 * Express Application Setup
 * Configures middleware and routes
 */

const express = require('express');
const cors = require('cors');

const app = express();

// Environment detection
const isDevelopment = process.env.NODE_ENV === 'development';
const isProduction = process.env.NODE_ENV === 'production';

// ============================================
// MIDDLEWARE
// ============================================

// Body parser middleware
app.use(express.json());
app.use(express.urlencoded({ extended: false }));

// Enable pretty-printed JSON responses (for better readability)
if (isDevelopment) {
  app.set('json spaces', 2);
}

// CORS middleware
app.use(cors());

// Environment-based request logging
if (isDevelopment) {
  app.use((req, res, next) => {
    console.log(`🔵 [${new Date().toISOString()}] ${req.method} ${req.url}`);
    next();
  });
}

// ============================================
// ROUTES
// ============================================

// Health check endpoint - HTML Interface
app.get('/', (req, res) => {
  res.status(200).send(`
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Personal Finance Tracker API</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
        }
        .container {
            background: white;
            border-radius: 20px;
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
            padding: 40px;
            max-width: 900px;
            width: 100%;
        }
        .header {
            text-align: center;
            margin-bottom: 40px;
        }
        .header h1 {
            color: #667eea;
            font-size: 2.5em;
            margin-bottom: 10px;
        }
        .header .badge {
            display: inline-block;
            background: #4CAF50;
            color: white;
            padding: 5px 15px;
            border-radius: 20px;
            font-size: 0.9em;
            margin: 5px;
        }
        .badge.dev { background: #FF9800; }
        .badge.prod { background: #4CAF50; }
        .endpoints {
            display: grid;
            gap: 20px;
            margin-top: 30px;
        }
        .endpoint {
            background: #f8f9fa;
            border-left: 4px solid #667eea;
            padding: 20px;
            border-radius: 8px;
            transition: transform 0.2s;
        }
        .endpoint:hover {
            transform: translateX(5px);
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
        }
        .endpoint .method {
            display: inline-block;
            padding: 4px 12px;
            border-radius: 4px;
            font-size: 0.85em;
            font-weight: bold;
            margin-right: 10px;
        }
        .method.get { background: #2196F3; color: white; }
        .method.post { background: #4CAF50; color: white; }
        .method.delete { background: #f44336; color: white; }
        .endpoint .url {
            color: #667eea;
            font-family: monospace;
            font-size: 1.1em;
            word-break: break-all;
        }
        .endpoint .description {
            color: #666;
            margin-top: 10px;
            font-size: 0.95em;
        }
        .endpoint a {
            color: #667eea;
            text-decoration: none;
            font-weight: bold;
        }
        .endpoint a:hover {
            text-decoration: underline;
        }
        .stats {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-top: 30px;
        }
        .stat-card {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 20px;
            border-radius: 12px;
            text-align: center;
        }
        .stat-card .label {
            font-size: 0.9em;
            opacity: 0.9;
            margin-bottom: 5px;
        }
        .stat-card .value {
            font-size: 1.8em;
            font-weight: bold;
        }
        .footer {
            text-align: center;
            margin-top: 40px;
            color: #999;
            font-size: 0.9em;
        }
        .demo-button {
            display: inline-block;
            background: #667eea;
            color: white;
            padding: 12px 30px;
            border-radius: 25px;
            text-decoration: none;
            margin: 10px;
            transition: all 0.3s;
            font-weight: bold;
        }
        .demo-button:hover {
            background: #764ba2;
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>💰 Personal Finance Tracker</h1>
            <div class="badge ${process.env.NODE_ENV === 'production' ? 'prod' : 'dev'}">${process.env.NODE_ENV || 'development'}</div>
            <div class="badge">v1.0.0</div>
            <div class="badge">Port: ${process.env.PORT || '3001'}</div>
        </div>

        <div class="stats">
            <div class="stat-card">
                <div class="label">Database</div>
                <div class="value">SQLite</div>
            </div>
            <div class="stat-card">
                <div class="label">Status</div>
                <div class="value">✅ Online</div>
            </div>
            <div class="stat-card">
                <div class="label">Environment</div>
                <div class="value">${process.env.NODE_ENV || 'dev'}</div>
            </div>
        </div>

        <h2 style="margin-top: 40px; color: #333; margin-bottom: 20px;">📍 API Endpoints</h2>
        
        <div class="endpoints">
            <div class="endpoint">
                <span class="method get">GET</span>
                <div class="url"><a href="/api/status" target="_blank">/api/status</a></div>
                <div class="description">Get server status and environment details</div>
            </div>

            <div class="endpoint">
                <span class="method get">GET</span>
                <div class="url"><a href="/api/transactions" target="_blank">/api/transactions</a></div>
                <div class="description">Retrieve all financial transactions</div>
            </div>

            <div class="endpoint">
                <span class="method post">POST</span>
                <div class="url">/api/transactions</div>
                <div class="description">Create a new transaction (income or expense)</div>
            </div>

            <div class="endpoint">
                <span class="method get">GET</span>
                <div class="url"><a href="/api/transactions/summary" target="_blank">/api/transactions/summary</a></div>
                <div class="description">Get financial summary (total income, expenses, balance)</div>
            </div>

            <div class="endpoint">
                <span class="method delete">DELETE</span>
                <div class="url">/api/transactions/:id</div>
                <div class="description">Delete a specific transaction by ID</div>
            </div>
        </div>

        <div style="text-align: center; margin-top: 40px;">
            <a href="/api/transactions" class="demo-button">📊 View Transactions</a>
            <a href="/api/transactions/summary" class="demo-button">💵 View Summary</a>
        </div>

        <div class="footer">
            <p>Built with Node.js + Express + Sequelize + SQLite</p>
            <p>Server started at: ${new Date().toLocaleString()}</p>
        </div>
    </div>
</body>
</html>
  `);
});

// API status endpoint with environment info
app.get('/api/status', (req, res) => {
  res.status(200).json({
    success: true,
    status: 'Server is running',
    environment: {
      mode: process.env.NODE_ENV || 'unknown',
      port: process.env.PORT || 'unknown',
      database: process.env.MONGO_URI ? 'Connected' : 'Not configured',
      nodeVersion: process.version
    },
    uptime: process.uptime(),
    memoryUsage: process.memoryUsage(),
    timestamp: new Date().toISOString()
  });
});

// Transaction routes
app.use('/api/transactions', require('./routes/transactions'));

// ============================================
// ERROR HANDLING
// ============================================

// 404 handler
app.use((req, res) => {
  res.status(404).json({
    success: false,
    error: 'Route not found',
    path: req.url,
    method: req.method
  });
});

// Global error handler
app.use((err, req, res, next) => {
  if (isDevelopment) {
    console.error('❌ [DEV] Global Error Handler:', err);
  }

  res.status(err.status || 500).json({
    success: false,
    error: err.message || 'Internal Server Error',
    stack: isDevelopment ? err.stack : undefined
  });
});

module.exports = app;
