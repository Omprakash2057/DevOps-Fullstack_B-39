/**
 * Database Configuration
 * Handles SQL database connection with Sequelize and environment-specific settings
 */

const { Sequelize } = require('sequelize');

const isDevelopment = process.env.NODE_ENV === 'development';
const isProduction = process.env.NODE_ENV === 'production';

/**
 * Initialize Sequelize based on database dialect
 * Supports SQLite (default), PostgreSQL, MySQL
 */
let sequelize;

if (process.env.DB_DIALECT === 'postgres' || process.env.DB_DIALECT === 'mysql') {
  // PostgreSQL or MySQL configuration
  sequelize = new Sequelize(process.env.DB_NAME, process.env.DB_USER, process.env.DB_PASSWORD, {
    host: process.env.DB_HOST || 'localhost',
    port: process.env.DB_PORT || (process.env.DB_DIALECT === 'postgres' ? 5432 : 3306),
    dialect: process.env.DB_DIALECT,
    logging: isDevelopment ? console.log : false,
    pool: {
      max: isProduction ? 10 : 5,
      min: 0,
      acquire: 30000,
      idle: 10000
    }
  });
} else {
  // SQLite configuration (default - no external server needed)
  const dbPath = process.env.DB_PATH || `./database_${process.env.NODE_ENV || 'development'}.sqlite`;
  
  sequelize = new Sequelize({
    dialect: 'sqlite',
    storage: dbPath,
    logging: isDevelopment ? console.log : false,
  });
}

/**
 * Connect to Database and Sync Models
 */
const connectDB = async () => {
  try {
    // Environment-based logging
    if (isDevelopment) {
      console.log('🔍 [DEV] SQL Database Debug Mode: ENABLED');
      console.log(`🔗 [DEV] Database Type: ${sequelize.getDialect().toUpperCase()}`);
      if (sequelize.config.storage) {
        console.log(`📁 [DEV] Database File: ${sequelize.config.storage}`);
      } else {
        console.log(`🔗 [DEV] Connecting to: ${sequelize.config.host}:${sequelize.config.port}`);
        console.log(`🗄️  Database: ${sequelize.config.database}`);
      }
    }

    // Test connection
    await sequelize.authenticate();

    // Sync models (create tables if they don't exist)
    await sequelize.sync({ alter: isDevelopment });

    // Success message with environment info
    if (isDevelopment) {
      console.log(`✅ SQL Database Connected Successfully!`);
      console.log(`🗄️  Dialect: ${sequelize.getDialect()}`);
      console.log(`🌍 Environment: ${process.env.NODE_ENV}`);
      console.log(`⚙️  Connection Pool Size: ${sequelize.config.pool?.max || 'N/A (SQLite)'}`);
      console.log(`📊 Models Synced: ${Object.keys(sequelize.models).length} models`);
    } else {
      // Minimal logging in production
      console.log(`✅ SQL Database Connected: ${sequelize.getDialect()}`);
    }

  } catch (error) {
    // Error handling with environment-specific details
    if (isDevelopment) {
      console.error('❌ [DEV] SQL Database Connection Error:');
      console.error(`   Message: ${error.message}`);
      console.error(`   Stack: ${error.stack}`);
    } else {
      console.error(`❌ SQL Database Connection Failed: ${error.message}`);
    }
    
    // Exit process with failure
    process.exit(1);
  }
};

// Graceful shutdown
process.on('SIGINT', async () => {
  await sequelize.close();
  console.log('🛑 SQL Database connection closed due to app termination');
  process.exit(0);
});

// Export sequelize instance and connectDB function
module.exports = { sequelize, connectDB };
