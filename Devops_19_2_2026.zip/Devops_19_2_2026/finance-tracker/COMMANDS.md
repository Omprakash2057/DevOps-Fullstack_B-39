# 🎯 COMMANDS REFERENCE SHEET

## 📦 STEP 1: BUILD DOCKER IMAGES

### Development Image
```powershell
cd c:\Users\malle\OneDrive\Desktop\Devops2026\Devops_19_2_2026\finance-tracker
docker build -f Dockerfile.dev -t finance-dev .
```

### Production Image
```powershell
cd c:\Users\malle\OneDrive\Desktop\Devops2026\Devops_19_2_2026\finance-tracker
docker build -f Dockerfile.prod -t finance-prod .
```

---

## 🚀 STEP 2: RUN CONTAINERS

### Development Container
```powershell
docker run -p 5000:5000 `
  -e PORT=5000 `
  -e MONGO_URI=mongodb://host.docker.internal:27017/finance-dev `
  -e NODE_ENV=development `
  finance-dev
```

**Access at:** http://localhost:5000

---

### Production Container
```powershell
docker run -p 8000:8000 `
  -e PORT=8000 `
  -e MONGO_URI=mongodb://host.docker.internal:27017/finance-prod `
  -e NODE_ENV=production `
  finance-prod
```

**Access at:** http://localhost:8000

---

## 🧪 STEP 3: TEST THE API

### Health Check
```powershell
curl http://localhost:5000/
```

### Create Income Transaction
```powershell
curl -X POST http://localhost:5000/api/transactions `
  -H "Content-Type: application/json" `
  -d '{"description":"Salary","amount":5000,"type":"income","category":"Salary"}'
```

### Create Expense Transaction
```powershell
curl -X POST http://localhost:5000/api/transactions `
  -H "Content-Type: application/json" `
  -d '{"description":"Groceries","amount":150,"type":"expense","category":"Food"}'
```

### Get All Transactions
```powershell
curl http://localhost:5000/api/transactions
```

### Get Summary
```powershell
curl http://localhost:5000/api/transactions/summary
```

### Get API Status
```powershell
curl http://localhost:5000/api/status
```

---

## 🛠️ DOCKER MANAGEMENT COMMANDS

### View Running Containers
```powershell
docker ps
```

### View All Containers
```powershell
docker ps -a
```

### View Container Logs
```powershell
docker logs <container-id>
```

### Stop Container
```powershell
docker stop <container-id>
```

### Remove Container
```powershell
docker rm <container-id>
```

### Remove Image
```powershell
docker rmi finance-dev
docker rmi finance-prod
```

### View Images
```powershell
docker images
```

### Clean Up Everything
```powershell
docker system prune -a
```

---

## 🗄️ MONGODB SETUP (If needed)

### Start MongoDB with Docker
```powershell
docker run -d `
  --name mongodb `
  -p 27017:27017 `
  mongo:latest
```

### Verify MongoDB is Running
```powershell
docker ps | findstr mongo
```

---

## 📊 VERIFICATION CHECKLIST

### Development Container
- [ ] Container starts successfully
- [ ] Console shows "Running in DEVELOPMENT mode"
- [ ] Console shows "MongoDB Connected"
- [ ] Detailed logs are visible
- [ ] Port 5000 is accessible
- [ ] Health check returns environment: "development"

### Production Container
- [ ] Container starts successfully
- [ ] Console shows "Running in PRODUCTION mode"
- [ ] Console shows "MongoDB Connected"
- [ ] Minimal logs (no verbose output)
- [ ] Port 8000 is accessible
- [ ] Health check returns environment: "production"

---

## 🔍 ENVIRONMENT DIFFERENCES

| Feature | Development | Production |
|---------|-------------|------------|
| **Port** | 5000 | 8000 |
| **Database** | `finance-dev` | `finance-prod` |
| **Logging** | Verbose (all requests/queries) | Minimal (errors only) |
| **MongoDB Debug** | Enabled | Disabled |
| **Stack Traces** | Visible | Hidden |
| **Container Size** | ~180 MB | ~150 MB (multi-stage) |
| **Hot Reload** | Yes (nodemon) | No (node) |

---

## 🐞 TROUBLESHOOTING

### Cannot connect to MongoDB
**Solution:**
```powershell
# Check if MongoDB is running
docker ps | findstr mongo

# If not, start it
docker run -d --name mongodb -p 27017:27017 mongo:latest
```

### Port already in use
**Solution:**
```powershell
# Find process using port
netstat -ano | findstr :5000

# Kill the process
taskkill /PID <PID> /F

# Or use different port
docker run -p 5001:5000 ...
```

### Container not starting
**Solution:**
```powershell
# View logs
docker logs <container-id>

# Rebuild without cache
docker build --no-cache -f Dockerfile.dev -t finance-dev .
```

---

## 📝 NOTES

1. **MongoDB URI:** 
   - Windows/Mac Docker: `mongodb://host.docker.internal:27017/dbname`
   - Linux Docker: `mongodb://172.17.0.1:27017/dbname`
   - Local (no Docker): `mongodb://localhost:27017/dbname`

2. **Environment Variables:**
   - Passed via `-e` flag when running container
   - Can also use `-env-file .env.development`

3. **Image Sizes:**
   - Development: ~180 MB (includes nodemon)
   - Production: ~150 MB (optimized, multi-stage build)

4. **Container Stops:**
   - Use Ctrl+C to stop gracefully
   - Container handles SIGTERM/SIGINT properly

---

🎉 **All commands ready to use! Copy and paste as needed.**
