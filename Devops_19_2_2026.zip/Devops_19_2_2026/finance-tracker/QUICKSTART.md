# 🚀 QUICK START GUIDE

## Prerequisites
- Docker installed
- MongoDB running (local or Atlas)

---

## 🏃 Quick Commands

### Development Mode

```bash
# Build
docker build -f Dockerfile.dev -t finance-dev .

# Run
docker run -p 5000:5000 \
  -e PORT=5000 \
  -e MONGO_URI=mongodb://host.docker.internal:27017/finance-dev \
  -e NODE_ENV=development \
  finance-dev

# Access
http://localhost:5000
```

---

### Production Mode

```bash
# Build
docker build -f Dockerfile.prod -t finance-prod .

# Run
docker run -p 8000:8000 \
  -e PORT=8000 \
  -e MONGO_URI=mongodb://host.docker.internal:27017/finance-prod \
  -e NODE_ENV=production \
  finance-prod

# Access
http://localhost:8000
```

---

## 🧪 Test the API

```bash
# Health Check
curl http://localhost:5000/

# Create Income Transaction
curl -X POST http://localhost:5000/api/transactions \
  -H "Content-Type: application/json" \
  -d '{"description":"Salary","amount":5000,"type":"income","category":"Salary"}'

# Create Expense Transaction
curl -X POST http://localhost:5000/api/transactions \
  -H "Content-Type: application/json" \
  -d '{"description":"Groceries","amount":150,"type":"expense","category":"Food"}'

# Get All Transactions
curl http://localhost:5000/api/transactions

# Get Summary
curl http://localhost:5000/api/transactions/summary
```

---

## 🔧 Common Issues

### MongoDB Connection Error?
- Windows/Mac: Use `host.docker.internal`
- Linux: Use `172.17.0.1`

### Port Already in Use?
```bash
# Use different port
docker run -p 5001:5000 ...
```

---

## 📊 Verify Deployment

✅ Checks:
- [ ] Server starts
- [ ] Correct environment shown
- [ ] MongoDB connected
- [ ] API responds
- [ ] Transactions work

---

For full documentation, see [README.md](README.md)
