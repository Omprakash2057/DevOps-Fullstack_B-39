# Scalable Cloud Application Infrastructure with Terraform

## Overview

This Terraform project provides a complete, scalable cloud infrastructure for deploying high-availability applications on AWS. The infrastructure supports dynamic scaling, zero-downtime updates, and environment separation.

## Architecture

### Components

1. **Networking Module**
   - VPC with public and private subnets across multiple availability zones
   - Internet Gateway and NAT Gateways for traffic routing
   - Security Groups for access control
   - VPC Flow Logs for monitoring and compliance

2. **Compute Module**
   - EC2 Launch Template for consistent instance configuration
   - Auto Scaling Group with dynamic scaling policies
   - IAM roles and policies for secure resource access
   - CloudWatch integration for monitoring

3. **Load Balancer Module**
   - Application Load Balancer (ALB) for traffic distribution
   - Target Group with health checks
   - S3 logging for ALB access logs
   - CloudWatch alarms for health monitoring

## Prerequisites

### Required Software
- **Terraform** >= 1.0 (Download from https://www.terraform.io/downloads.html)
- **AWS CLI** >= 2.0 (Download from https://aws.amazon.com/cli/)
- **PowerShell** (for Windows batch scripts)

### AWS Requirements
- AWS Account with appropriate permissions
- AWS credentials configured (via AWS CLI or environment variables)
- IAM permissions for:
  - EC2, VPC, Auto Scaling
  - Application Load Balancer
  - S3, DynamoDB, CloudWatch
  - IAM role creation

### AWS Credentials Setup

```powershell
# Configure AWS CLI
aws configure
# Enter: AWS Access Key ID
# Enter: AWS Secret Access Key
# Enter: Default region (us-east-1)
# Enter: Default output format (json)

# Verify credentials
aws sts get-caller-identity
```

## Project Structure

```
├── terraform/                 # Main Terraform code
│   ├── provider.tf           # AWS provider configuration
│   ├── main.tf               # Infrastructure orchestration
│   ├── variables.tf          # Variable definitions
│   ├── outputs.tf            # Output definitions
│   ├── modules/
│   │   ├── networking/       # VPC and network configuration
│   │   ├── compute/          # EC2 and Auto Scaling
│   │   └── loadbalancer/     # Load Balancer and Target Groups
│   └── environments/
│       ├── dev/              # Development environment config
│       └── prod/             # Production environment config
│
├── init.bat                  # Initialize Terraform
├── plan.bat                  # Generate infrastructure plan
├── apply.bat                 # Apply infrastructure changes
├── destroy.bat               # Destroy infrastructure
├── scale.bat                 # Scale instances
├── output.bat                # Display infrastructure info
├── rollback.bat              # Rollback to previous state
├── locks.bat                 # Manage state locks
└── README.md                 # This file
```

## Quick Start

### 1. Initialize Terraform Backend

The first step sets up S3 and DynamoDB for state management:

```powershell
# For Development
.\init.bat dev

# For Production
.\init.bat prod
```

This script:
- Creates S3 bucket for Terraform state
- Enables versioning and encryption
- Creates DynamoDB table for state locking
- Initializes Terraform backend

### 2. Plan Infrastructure Changes

Preview all changes before applying:

```powershell
# Development environment
.\plan.bat dev

# Production environment
.\plan.bat prod
```

### 3. Apply Infrastructure

Deploy the infrastructure:

```powershell
# Development
.\apply.bat dev

# Production
.\apply.bat prod
```

The script creates:
- VPC with proper networking
- EC2 instances
- Auto Scaling Group
- Application Load Balancer
- Security Groups and IAM roles

### 4. Access Your Application

```powershell
# Get the Load Balancer DNS name
.\output.bat dev load_balancer_dns

# Access via browser
http://<load_balancer_dns>
```

## Environment Configurations

### Development Environment
- **Instance Type**: t3.micro (cost-optimized)
- **Min Instances**: 1
- **Max Instances**: 2
- **Desired Instances**: 1
- **Single AZ**: us-east-1a
- **Health Check**: Every 60 seconds
- **Auto-scaling**: 80% CPU threshold

### Production Environment
- **Instance Type**: t3.small (better performance)
- **Min Instances**: 2
- **Max Instances**: 5
- **Desired Instances**: 3
- **Multi-AZ**: us-east-1a, us-east-1b, us-east-1c
- **Health Check**: Every 30 seconds
- **Auto-scaling**: 70% CPU threshold
- **Session Stickiness**: Enabled

## Scaling Operations

### Dynamic Scaling

Instances automatically scale based on CPU utilization:

```powershell
# View current scaling metrics
aws autoscaling describe-auto-scaling-groups ^
    --auto-scaling-group-names devops-app-asg-dev ^
    --region us-east-1
```

### Manual Scaling

Quickly adjust instance count:

```powershell
# Scale to 5 instances
.\scale.bat dev 5

# Scale to 2 instances
.\scale.bat prod 2
```

The scaling operation:
- Updates the desired capacity
- Preserves existing instances (no termination/recreation)
- Triggers rolling updates if configuration changed
- Maintains 90% minimum healthy percentage

## Zero-Downtime Updates

### Update Configuration Without Downtime

1. **Update variables** in `environments/<env>/terraform.tfvars`

2. **Plan the changes**:
   ```powershell
   .\plan.bat dev
   ```

3. **Apply with rolling updates**:
   ```powershell
   .\apply.bat dev
   ```

The Auto Scaling Group's `instance_refresh` policy ensures:
- Minimum 90% healthy instances maintained
- New instances launched before terminating old ones
- Zero downtime during updates

### Update Application Code

To update application code without Terraform:

```powershell
# Update user_data.sh with new configuration
# Then trigger an instance refresh
aws autoscaling start-instance-refresh ^
    --auto-scaling-group-name devops-app-asg-dev
```

## State Management

### State Locking

Prevents concurrent modifications that could corrupt state:

```powershell
# Check for active locks
.\locks.bat list dev

# Release a stuck lock (use with caution)
.\locks.bat release dev
```

### State Backup and Recovery

Automatic backups are created before each apply:

```powershell
# List available backups
dir terraform.dev.tfstate.backup.*

# Restore from backup
.\rollback.bat dev
```

### State Versioning

S3 versioning allows complete history:

```powershell
# View state versions in AWS Console
# S3 → devops-app-terraform-state-dev → Versions
```

## Monitoring and Logging

### CloudWatch Monitoring

View metrics and logs:

```powershell
# View Auto Scaling Group metrics
aws autoscaling describe-auto-scaling-groups ^
    --auto-scaling-group-names devops-app-asg-dev

# View application logs
aws logs tail /aws/ec2/devops-app/dev --follow

# View ALB logs (stored in S3)
aws s3 ls s3://devops-app-alb-logs-dev-[account-id]/
```

### Health Checks

ALB performs continuous health checks:

```powershell
# View target health
aws elbv2 describe-target-health ^
    --target-group-arn arn:aws:elasticloadbalancing:... ^
    --region us-east-1
```

## Troubleshooting

### Common Issues

#### Issue: "Access Denied" errors
**Solution**: Verify AWS credentials and IAM permissions
```powershell
aws sts get-caller-identity
```

#### Issue: State lock timeout
**Solution**: Check for stuck locks and release if necessary
```powershell
.\locks.bat list dev
.\locks.bat release dev
```

#### Issue: Instances not starting
**Solution**: Check user data and security groups
```powershell
# View instance details
aws ec2 describe-instances ^
    --region us-east-1 ^
    --query 'Reservations[0].Instances[0]'
```

#### Issue: Load Balancer shows "unhealthy" targets
**Solution**: Verify health check configuration and security groups
```powershell
# Check target health
aws elbv2 describe-target-health ^
    --target-group-arn [arn]
    
# SSH into instance and check web server
ssh -i key.pem ec2-user@[instance-ip]
curl http://localhost/health
```

## Advanced Operations

### Workspace Management

Workspaces isolate state for different environments:

```powershell
# List workspaces
cd terraform
terraform workspace list

# Create new workspace
terraform workspace new staging

# Switch workspace
terraform workspace select dev
```

### Modify Scaling Policies

Edit `environments/<env>/terraform.tfvars`:

```hcl
cpu_target_utilization = 75  # Increase threshold
max_instances = 10            # Increase max capacity
```

Then apply:
```powershell
.\apply.bat dev
```

### Add HTTPS Support

Uncomment HTTPS listener in `modules/loadbalancer/main.tf`:

1. Create/import ACM certificate
2. Update certificate ARN in the listener configuration
3. Apply changes

### Enable Session Affinity

Update in `environments/<env>/terraform.tfvars`:

```hcl
enable_stickiness = true
```

## Cleanup and Destruction

### Destroy Infrastructure

When done, destroy all resources:

```powershell
# Development
.\destroy.bat dev

# Production (requires confirmation)
.\destroy.bat prod
```

This removes:
- EC2 instances and Auto Scaling Group
- Load Balancer
- VPC and networking components
- Security Groups
- IAM roles

**Note**: S3 buckets and DynamoDB table are retained for safety.

## Best Practices

1. **Always use `plan` before `apply`**
   - Review changes carefully
   - Catch configuration errors early

2. **Maintain separate environments**
   - Dev for testing configuration changes
   - Prod for stable, production workloads

3. **Use state locking**
   - Prevents concurrent modifications
   - Maintains infrastructure consistency

4. **Regular backups**
   - Monitor S3 versioning
   - Test rollback procedures regularly

5. **Monitor and alert**
   - Set up CloudWatch alarms
   - Review ALB logs regularly

6. **Update in stages**
   - Test changes in dev first
   - Apply to prod during maintenance window

7. **Document changes**
   - Maintain git history
   - Record deployment notes

## Cost Estimation

### Development Environment (Monthly)
- 1 t3.micro instance: ~$9
- ALB: ~$16
- Data transfer: ~$5
- **Total**: ~$30/month

### Production Environment (Monthly)
- 3 t3.small instances: ~$90
- ALB: ~$16
- Data transfer: ~$10
- **Total**: ~$116/month

Costs vary by region and usage patterns.

## Support and Resources

- **Terraform Documentation**: https://www.terraform.io/docs
- **AWS Terraform Provider**: https://registry.terraform.io/providers/hashicorp/aws
- **Terraform Best Practices**: https://learn.hashicorp.com/terraform
- **AWS CLI Reference**: https://docs.aws.amazon.com/cli/

## License

This infrastructure is provided as-is for educational and operational purposes.

## Version History

### v1.0 (Initial Release)
- VPC with multi-AZ support
- Auto Scaling with CPU-based policies
- Application Load Balancer
- State management with locking
- Environment separation (dev/prod)
- Comprehensive monitoring and logging

---

**Last Updated**: 2026-03-26
**Terraform Version**: >= 1.0
**AWS Provider Version**: ~> 5.0
