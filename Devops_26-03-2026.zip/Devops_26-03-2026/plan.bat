# Terraform Plan Script - Preview Infrastructure Changes
# This script generates a plan showing what changes will be made to the infrastructure

@echo off
REM Generate Terraform plan for infrastructure changes

if "%1"=="" (
    echo Usage: plan.bat [dev^|prod] [optional: save to file]
    echo Example: plan.bat dev
    echo Example: plan.bat prod true
    exit /b 1
)

setlocal enabledelayedexpansion
set ENVIRONMENT=%1
set SAVE_PLAN=%2

echo ========================================
echo Terraform Plan - %ENVIRONMENT% Environment
echo ========================================
echo.

REM Navigate to terraform directory
cd terraform

REM Select workspace
echo Selecting workspace: %ENVIRONMENT%...
terraform workspace select %ENVIRONMENT%
if errorlevel 1 (
    echo ERROR: Workspace %ENVIRONMENT% not found
    cd ..
    exit /b 1
)

REM Run terraform plan
echo.
echo Generating Terraform plan...
echo.

if "%SAVE_PLAN%"=="true" (
    set PLAN_FILE=terraform.%ENVIRONMENT%.plan
    echo Saving plan to file: %PLAN_FILE%...
    terraform plan -var-file=../environments/%ENVIRONMENT%/terraform.tfvars -out=!PLAN_FILE!
) else (
    terraform plan -var-file=../environments/%ENVIRONMENT%/terraform.tfvars
)

if errorlevel 1 (
    echo ERROR: Terraform plan failed
    cd ..
    exit /b 1
)

cd ..

echo.
echo ========================================
echo Plan Generation Completed!
echo.
if "%SAVE_PLAN%"=="true" (
    echo Plan saved. To apply the changes, run: apply.bat %ENVIRONMENT%
)
echo Next steps:
echo - Review the plan output above
echo - If satisfied, run: apply.bat %ENVIRONMENT%
echo - To cancel, run: destroy.bat %ENVIRONMENT%
echo ========================================
