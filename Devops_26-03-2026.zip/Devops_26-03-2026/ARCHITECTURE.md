# Infrastructure Architecture Diagram

## System Architecture Overview

```
┌─────────────────────────────────────────────────────────────────┐
│                         AWS Region (us-east-1)                  │
├─────────────────────────────────────────────────────────────────┤
│                                                                   │
│  ┌──────────────────────────────────────────────────────────┐   │
│  │                    Internet (0.0.0.0/0)                  │   │
│  └────────────────────────┬─────────────────────────────────┘   │
│                           │ HTTP/HTTPS:80,443                    │
│                           ▼                                       │
│  ┌──────────────────────────────────────────────────────────┐   │
│  │    Application Load Balancer (Public)                    │   │
│  │    - Listeners: HTTP(80), HTTPS(443)                     │   │
│  │    - Health Check: /health (30s interval)                │   │
│  │    - Logging: S3 Bucket                                  │   │
│  │    - Alarms: HealthyHostCount, RequestCount             │   │
│  └────────────────────┬─────────────────────────────────────┘   │
│                       │ Port 80 to Instances                      │
│                       ▼                                           │
│  ┌──────────────────────────────────────────────────────────┐   │
│  │              Target Group (HTTP:80)                      │   │
│  │  - Instance Registration: Automatic (ASG)               │   │
│  │  - Deregistration Delay: 30s                            │   │
│  │  - Stickiness: [Dev: OFF | Prod: ON]                    │   │
│  └────────────────────┬─────────────────────────────────────┘   │
│                       │                                          │
│     ┌─────────────────┼─────────────────┐                       │
│     │                 │                 │                       │
│     ▼                 ▼                 ▼                       │
│  ┌────────────┐  ┌────────────┐  ┌────────────┐               │
│  │ Instance 1 │  │ Instance 2 │  │ Instance 3 │               │
│  │ t3.micro   │  │ t3.micro   │  │ t3.micro   │               │
│  │ Private AZ1│  │ Private AZ2│  │ Private AZ1│               │
│  └────────────┘  └────────────┘  └────────────┘   [Dev]       │
│                                                              │
│  Auto Scaling Group                                        │
│  - Min: 1 | Desired: 1 | Max: 2                            │
│  - CPU Target: 80%                                         │
│  - Launch Template: Latest AMI                             │
│  - Instance Refresh: 90% Min Healthy                       │
│                                                              │
└─────────────────────────────────────────────────────────────────┘
```

## Data Flow

```
Internet Request Flow:
─────────────────────

1. User Request
   │
   ▼
2. ALB (DNS resolution)
   │
   ├─→ Route53 (Optional DNS)
   │
   ▼
3. ALB Listener (Port 80)
   │
   ├─→ Security Group Check ✓
   │
   ▼
4. Target Group
   │
   ├─→ Health Check: GET /health
   ├─→ Routing Rule
   │
   ▼
5. EC2 Instance (Apache/HTTP)
   │
   ├─→ Security Group Check ✓
   ├─→ Application Processing
   │
   ▼
6. Response
   │
   └─→ Back to Client

CloudWatch Monitoring:
──────────────────────

ALB Metrics          Instance Metrics       ASG Metrics
├─ RequestCount      ├─ CPUUtilization      ├─ GroupInServiceInstances
├─ TargetResponseTime│ ├─ NetworkIn         ├─ GroupPendingInstances
├─ HTTPCode_Target_2XX├─ NetworkOut        ├─ GroupTerminatingInstances
└─ HealthyHostCount  ├─ DiskReadBytes      └─ GroupDesiredCapacity
                     └─ Memory

       ▼
CloudWatch Logs Insights
├─ VPC Flow Logs
├─ ALB Access Logs → S3
└─ Application Logs
```

## Scaling Behavior

```
CPU Utilization Timeline:
──────────────────────────

100% ┤                              
     │        ╱╲                   
 80% ┤       ╱  ╲        Scaling Trigger
     │      ╱    ╲╲                
 70% ┤─────╱──────╲╱──────         Target (70%)
     │                ╲╱           
 50% ┤                            
     │
Time: ────────────────────────────
      0      5     10    15    20 min

Scaling Actions:
────────────────
T+0:    CPU exceeds threshold (70%)
T+1:    Scaling decision triggered
T+2:    New EC2 instance launching
T+5:    Instance passes health checks
T+8:    Instance added to ALB target group
T+12:   Full capacity online
```

## Security Architecture

```
Security Layers:
────────────────

Layer 1: AWS Account & IAM
├─ AWS Account ID: [Masked]
├─ IAM Roles: EC2 Instance Role
├─ IAM Policies: CloudWatch, SSM, S3
└─ MFA: Enabled on root account (recommended)

Layer 2: VPC & Network
├─ VPC CIDR: 10.0.0.0/16 (dev) | 10.1.0.0/16 (prod)
├─ Public Subnets: 10.0.0.0/18, 10.0.64.0/18
├─ Private Subnets: 10.0.128.0/18, 10.0.192.0/18
├─ NAT Gateways: 2 per region (HA)
└─ VPC Flow Logs: Enabled

Layer 3: Security Groups
ALB Security Group:
├─ Inbound: 80 (HTTP) from 0.0.0.0/0
├─ Inbound: 443 (HTTPS) from 0.0.0.0/0
└─ Outbound: All to 0.0.0.0/0

App Security Group:
├─ Inbound: 80 (HTTP) from ALB SG
├─ Inbound: 443 (HTTPS) from ALB SG
├─ Inbound: 22 (SSH) from 10.0.0.0/8
└─ Outbound: All to 0.0.0.0/0

Layer 4: Data Encryption
├─ EBS Volumes: Encrypted (AES-256)
├─ S3 State Storage: Encrypted (AES-256)
├─ Transit: HTTPS (optional, ALB to instances internal)
└─ IMDSv2: Enabled (secure token requirement)
```

## State Management Architecture

```
Terraform State Flow:
─────────────────────

Local Machine
     │
     │ plan / apply
     │
     ▼
Terraform Lock
(DynamoDB: terraform-locks)
     │
     ├─→ Acquire Lock
     │   ├─ LockID: state file path
     │   ├─ Timestamp: 2026-03-26 XX:XX:XX
     │   └─ Digest: State version hash
     │
     ▼
S3 Backend Storage
(Bucket: devops-app-terraform-state-dev)
     │
     ├─→ Current State (terraform.tfstate)
     │   └─ Latest infrastructure snapshot
     │
     ├─→ Version History (S3 Versioning)
     │   ├─ Version 1: Initial deployment
     │   ├─ Version 2: Scaled to 3 instances
     │   ├─ Version 3: Updated instance type
     │   └─ ...more versions
     │
     └─→ Encryption
         ├─ Server-side: AES-256
         ├─ Versioning: All versions encrypted
         └─ Access: Only via IAM role
```

## Deployment Environments

```
Development Environment
───────────────────────
VPC:            10.0.0.0/16
Instances:      1 (t3.micro)
Min/Max:        1/2
Availability:   Single AZ
Health Check:   60 seconds
Scaling:        CPU > 80%
Cost/Month:     ~$30-40

Production Environment
──────────────────────
VPC:            10.1.0.0/16
Instances:      3 (t3.small)
Min/Max:        2/5
Availability:   Multi-AZ (3 zones)
Health Check:   30 seconds
Scaling:        CPU > 70%
Cost/Month:     ~$110-130
```

## Update Procedure (Zero-Downtime)

```
Rolling Instance Update Timeline:
──────────────────────────────────

Starting State: 3 instances running
                Instance-A (v1)
                Instance-B (v1)
                Instance-C (v1)

Step 1: Launch new instance (v2)
        Instance-A (v1) ✓ healthy
        Instance-B (v1) ✓ healthy
        Instance-C (v1) ✓ healthy
        Instance-D (v2) launching...

Step 2: Instance-D health check passes
        Instance-A (v1) ✓ removing
        Instance-B (v1) ✓ healthy
        Instance-C (v1) ✓ healthy
        Instance-D (v2) ✓ healthy
        
Step 3: Deregister Instance-A (drain connections)
        Instance-A (v1) draining (30s)
        Instance-B (v1) ✓ healthy
        Instance-C (v1) ✓ healthy
        Instance-D (v2) ✓ healthy

Step 4: Terminate Instance-A, launch Instance-E (v2)
        Instance-B (v1) ✓ healthy
        Instance-C (v1) ✓ healthy
        Instance-D (v2) ✓ healthy
        Instance-E (v2) launching...

Step 5: Instance-E health check passes
        Instance-B (v1) ✓ removing
        Instance-C (v1) ✓ healthy
        Instance-D (v2) ✓ healthy
        Instance-E (v2) ✓ healthy

...continues until all instances updated...

Final State: All instances v2
            Instance-C (v2)
            Instance-D (v2)
            Instance-E (v2)

Total Downtime: 0 minutes
Min Healthy %:  90% (maintained)
Connection Loss: 0
```

## Monitoring Dashboard

```
CloudWatch Monitoring Layout:
────────────────────────────

┌─────────────────────────┬─────────────────────────┐
│  ALB RequestCount       │   TargetHealth Status   │
│  [Graph: Last 24h]      │   [Gauge: 3/3 healthy]  │
└─────────────────────────┴─────────────────────────┘

┌─────────────────────────┬─────────────────────────┐
│  Instance CPUUtilization│   ASG Capacity          │
│  [Graph: 3 lines]       │   Min: 1 Current: 3     │
│  Avg: 45% Max: 78%      │   Max: 5 Desired: 3     │
└─────────────────────────┴─────────────────────────┘

┌─────────────────────────┬─────────────────────────┐
│  Network In/Out         │   Health Check Status   │
│  [Stacked Area Chart]   │   ✓ ALB: Active         │
│  In: 2.5 MB/s           │   ✓ Targets: Passing    │
│  Out: 1.2 MB/s          │   ✓ Alarms: OK          │
└─────────────────────────┴─────────────────────────┘

Alarms Status:
├─ ✓ HealthyHostCount (Green) - 3/3 healthy
├─ ✓ RequestCount (Green) - 450 req/min (below 1000 threshold)
└─ ✓ TargetResponseTime (Green) - 45ms average
```

## File Structure with Resource Mapping

```
Terraform Files → AWS Resources
───────────────────────────────

provider.tf → 
└─ AWS Provider Configuration
   └─ S3 Backend (state storage)
   └─ DynamoDB Backend (state lock)

main.tf →
├─ module.networking
│  └─ VPC, Subnets, Route Tables, etc.
├─ module.compute
│  └─ EC2, Auto Scaling, IAM roles
└─ module.loadbalancer
   └─ ALB, Target Groups, Logging

variables.tf →
└─ Input Variables (60+ parameters)
   └─ Used by all modules

outputs.tf →
└─ Output Values
   └─ ALB DNS, Instance IDs, etc.

modules/networking/main.tf →
├─ aws_vpc
├─ aws_subnet (public & private)
├─ aws_internet_gateway
├─ aws_nat_gateway
├─ aws_route_table
├─ aws_security_group
└─ aws_flow_log

modules/compute/main.tf →
├─ aws_launch_template
├─ aws_autoscaling_group
├─ aws_autoscaling_policy
├─ aws_iam_role
├─ aws_iam_instance_profile
└─ aws_cloudwatch_log_group

modules/loadbalancer/main.tf →
├─ aws_lb
├─ aws_lb_target_group
├─ aws_lb_listener
├─ aws_s3_bucket (for ALB logs)
└─ aws_cloudwatch_metric_alarm
```

---

**Architecture Version**: 1.0
**Last Updated**: 2026-03-26
**Cloud Provider**: AWS
**Terraform Version**: >= 1.0
