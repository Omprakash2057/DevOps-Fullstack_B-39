# Terraform Initialization and Backend Setup Script
# This script initializes Terraform with proper backend configuration for state management and locking

@echo off
REM Initialize Terraform with S3 backend for state management

if "%1"=="" (
    echo Usage: init.bat [dev^|prod]
    echo Example: init.bat dev
    exit /b 1
)

set ENVIRONMENT=%1
set REGION=us-east-1
set STATE_BUCKET=devops-app-terraform-state-%ENVIRONMENT%
set LOCK_TABLE=terraform-locks
set PROJECT_NAME=devops-app

echo ========================================
echo Terraform Initialization Script
echo Environment: %ENVIRONMENT%
echo ========================================

REM Check AWS CLI is installed
where aws >nul 2>nul
if errorlevel 1 (
    echo ERROR: AWS CLI is not installed or not in PATH
    exit /b 1
)

REM Check Terraform is installed
where terraform >nul 2>nul
if errorlevel 1 (
    echo ERROR: Terraform is not installed or not in PATH
    exit /b 1
)

REM Create S3 bucket for state if it doesn't exist
echo.
echo Creating S3 bucket for Terraform state...
aws s3api head-bucket --bucket %STATE_BUCKET% --region %REGION% 2>nul
if errorlevel 1 (
    echo Bucket does not exist. Creating %STATE_BUCKET%...
    aws s3api create-bucket ^
        --bucket %STATE_BUCKET% ^
        --region %REGION% ^
        --acl private
    
    REM Enable versioning
    aws s3api put-bucket-versioning ^
        --bucket %STATE_BUCKET% ^
        --versioning-configuration Status=Enabled
    
    REM Enable encryption
    aws s3api put-bucket-encryption ^
        --bucket %STATE_BUCKET% ^
        --server-side-encryption-configuration '{
            "Rules": [
                {
                    "ApplyServerSideEncryptionByDefault": {
                        "SSEAlgorithm": "AES256"
                    }
                }
            ]
        }'
    
    REM Block public access
    aws s3api put-public-access-block ^
        --bucket %STATE_BUCKET% ^
        --public-access-block-configuration "BlockPublicAcls=true,IgnorePublicAcls=true,BlockPublicPolicy=true,RestrictPublicBuckets=true"
    
    echo Bucket %STATE_BUCKET% created successfully
) else (
    echo Bucket %STATE_BUCKET% already exists
)

REM Create DynamoDB table for state locking if it doesn't exist
echo.
echo Creating DynamoDB table for state locking...
aws dynamodb describe-table ^
    --table-name %LOCK_TABLE% ^
    --region %REGION% >nul 2>&1
if errorlevel 1 (
    echo Table does not exist. Creating %LOCK_TABLE%...
    aws dynamodb create-table ^
        --table-name %LOCK_TABLE% ^
        --attribute-definitions AttributeName=LockID,AttributeType=S ^
        --key-schema AttributeName=LockID,KeyType=HASH ^
        --billing-mode PAY_PER_REQUEST ^
        --region %REGION%
    
    REM Wait for table to be created
    echo Waiting for table to be active...
    aws dynamodb wait table-exists --table-name %LOCK_TABLE% --region %REGION%
    echo Table %LOCK_TABLE% created successfully
) else (
    echo Table %LOCK_TABLE% already exists
)

REM Initialize Terraform
echo.
echo Initializing Terraform in terraform directory...
cd terraform

terraform init ^
    -backend-config="bucket=%STATE_BUCKET%" ^
    -backend-config="key=%ENVIRONMENT%/terraform.tfstate" ^
    -backend-config="region=%REGION%" ^
    -backend-config="dynamodb_table=%LOCK_TABLE%" ^
    -backend-config="encrypt=true"

if errorlevel 1 (
    echo ERROR: Terraform initialization failed
    exit /b 1
)

REM Create/Select workspace
echo.
echo Selecting Terraform workspace: %ENVIRONMENT%...
terraform workspace list
terraform workspace new %ENVIRONMENT% 2>nul
terraform workspace select %ENVIRONMENT%

cd ..

echo.
echo ========================================
echo Initialization Completed Successfully!
echo Next steps:
echo 1. Review the infrastructure plan: plan.bat %ENVIRONMENT%
echo 2. Apply the infrastructure: apply.bat %ENVIRONMENT%
echo ========================================
