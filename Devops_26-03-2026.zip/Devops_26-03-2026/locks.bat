# Terraform State Locking Script - View and Manage State Locks
# This script helps manage Terraform state locks

@echo off
REM Display and manage Terraform state locks

if "%1"=="" (
    echo Usage: locks.bat [list^|release] [environment]
    echo Example: locks.bat list dev
    echo Example: locks.bat release dev
    exit /b 1
)

set OPERATION=%1
set ENVIRONMENT=%2

if "%ENVIRONMENT%"=="" (
    echo ERROR: Environment not specified
    exit /b 1
)

set LOCK_TABLE=terraform-locks
set REGION=us-east-1
set STATE_BUCKET=devops-app-terraform-state-%ENVIRONMENT%
set LOCK_ID=%STATE_BUCKET%/%ENVIRONMENT%/terraform.tfstate

echo ========================================
echo Terraform State Locking Management
echo ========================================
echo Environment: %ENVIRONMENT%
echo.

if "%OPERATION%"=="list" (
    echo Checking for active locks on DynamoDB table: %LOCK_TABLE%
    echo.
    
    aws dynamodb scan ^
        --table-name %LOCK_TABLE% ^
        --region %REGION% ^
        --output table
    
    echo.
    echo If a lock exists, note the LockID for release operation
    
) else if "%OPERATION%"=="release" (
    echo.
    set /p LOCK_ID_INPUT="Enter the LockID to release (press Enter for default): "
    
    if not "!LOCK_ID_INPUT!"=="" (
        set LOCK_ID=!LOCK_ID_INPUT!
    )
    
    echo Releasing lock: %LOCK_ID%
    echo.
    
    aws dynamodb delete-item ^
        --table-name %LOCK_TABLE% ^
        --region %REGION% ^
        --key "{\"LockID\": {\"S\": \"%LOCK_ID%\"}}"
    
    echo Lock released successfully
    
) else (
    echo ERROR: Unknown operation: %OPERATION%
    exit /b 1
)

echo.
echo ========================================
