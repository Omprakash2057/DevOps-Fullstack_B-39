# AWS Cloud Console Verification Guide

## AWS Console Access

1. **Login to AWS Console**
   - Navigate to: https://console.aws.amazon.com
   - Enter AWS Account ID, IAM username, and password

## Infrastructure Verification

### 1. VPC and Networking

**Navigate to**: EC2 → VPCs

✓ Verify:
- [ ] VPC created with correct CIDR (10.0.0.0/16 for dev, 10.1.0.0/16 for prod)
- [ ] Public subnets visible (with Internet Gateway)
- [ ] Private subnets visible

**Navigate to**: EC2 → Security Groups

✓ Verify:
- [ ] ALB security group allows HTTP (80) and HTTPS (443) inbound
- [ ] App security group allows traffic from ALB
- [ ] Outbound rules configured correctly

### 2. Compute Instances

**Navigate to**: EC2 → Instances

✓ Verify:
- [ ] Instances running (number matches desired_instances)
- [ ] Instances have proper tags (Environment, Project)
- [ ] Security group correctly assigned
- [ ] Instance type correct (t3.micro for dev, t3.small for prod)

**Instance Details**:
- Click on instance → Details tab
  - [ ] IAM instance profile assigned
  - [ ] VPC and Subnet correct
  - [ ] Public IP visible (for troubleshooting via SSM)

### 3. Auto Scaling

**Navigate to**: EC2 → Auto Scaling Groups

✓ Verify:
- [ ] ASG created with correct name pattern (`devops-app-asg-<env>`)
- [ ] Correct lifecycle: Instances available
- [ ] Min/Max/Desired capacity matches configuration
- [ ] Launch template version displays latest

**ASG Details**:
- Click ASG → Activity tab
  - [ ] Recent instances successfully launched
  - [ ] No failed launch attempts
  - [ ] Rolling update in progress if applicable (status shows in Progress)

### 4. Application Load Balancer

**Navigate to**: EC2 → Load Balancers

✓ Verify:
- [ ] ALB created and active
- [ ] DNS name is accessible (copy and test in browser)
- [ ] Scheme: internet-facing
- [ ] Type: Application Load Balancer

**ALB Details**:
- [ ] VPC correct
- [ ] Availability Zones have public subnets

**Target Group Health**:
- Click ALB → Target Groups tab
  - [ ] Target group created
  - [ ] All targets showing "healthy"
  - [ ] Health check path: /health
  - [ ] Health check interval: 30s (prod) or 60s (dev)

**Example Health Status**:
```
Instance ID          Status       Description
i-0123456789abcdef0  healthy      N/A
i-0123456789abcdef1  healthy      N/A
i-0123456789abcdef2  healthy      N/A
```

### 5. Monitoring and Alarms

**Navigate to**: CloudWatch → Alarms

✓ Verify:
- [ ] Health Check alarm created
- [ ] Request count alarm created
- [ ] All alarms in OK state (green)

**Navigate to**: CloudWatch → Log Groups

✓ Verify:
- [ ] VPC Flow Logs group: `/aws/vpc/flowlogs/devops-app-<env>`
- [ ] Application logs group: `/aws/ec2/devops-app/<env>`
- [ ] Recent log entries visible

### 6. Storage

**Navigate to**: S3

✓ Verify:
- [ ] Terraform state bucket created: `devops-app-terraform-state-<env>`
- [ ] Versioning enabled (under Bucket Versioning)
- [ ] Encryption enabled (under Encryption)
- [ ] ALB logs bucket created: `devops-app-alb-logs-<env>-[account-id]`
- [ ] Public access blocked on all buckets

### 7. State Lock Table

**Navigate to**: DynamoDB → Tables

✓ Verify:
- [ ] Table created: `terraform-locks`
- [ ] Partition key: `LockID` (String)
- [ ] Billing mode: Pay-per-request

**View Lock Status**:
```powershell
aws dynamodb scan --table-name terraform-locks --region us-east-1
```

## Application Endpoint Testing

### Step 1: Get Application URL

```powershell
# Method 1: Via Terraform output
cd terraform
terraform output -raw load_balancer_dns

# Method 2: Via AWS CLI
$ALB_ARN = $(aws elbv2 describe-load-balancers `
    --region us-east-1 `
    --query "LoadBalancers[?contains(LoadBalancerName, 'devops-app')].LoadBalancerArn" `
    --output text)
aws elbv2 describe-load-balancers --load-balancer-arns $ALB_ARN --region us-east-1
```

### Step 2: Test Health Endpoint

```powershell
$ALB_DNS = "devops-app-alb-dev-[id].us-east-1.elb.amazonaws.com"

# Health check
curl http://$ALB_DNS/health
# Expected response: OK

# Application endpoint
curl http://$ALB_DNS/
# Expected response: HTML page with "Application Server Active"
```

### Step 3: Test Load Distribution

```powershell
# Multiple requests should distribute across instances
for ($i = 0; $i -lt 10; $i++) {
    curl http://$ALB_DNS/ | grep "Instance:"
    Start-Sleep -Seconds 1
}
```

## Performance Testing

### Test Auto-Scaling Trigger

**Generate Load**:

```powershell
# Using Apache Bench (if installed)
ab -n 10000 -c 100 http://$ALB_DNS/

# Or using PowerShell
$ALB_DNS = "..."
for ($i = 0; $i -lt 100; $i++) {
    $job = Start-Job -ScriptBlock { 
        curl http://$ALB_DNS/ 
    }
}
```

**Monitor Scaling**:

```powershell
# Watch Auto Scaling activities
aws autoscaling describe-scaling-activities `
    --auto-scaling-group-name devops-app-asg-dev `
    --max-records 5 `
    --region us-east-1
```

## Cost Analysis

### Monthly Estimate Viewer

**Navigate to**: Cost Explorer

✓ Check:
- [ ] EC2 instance costs
- [ ] Load Balancer costs
- [ ] Data transfer costs
- [ ] Storage costs

**Filter by Tag**:
- Project: devops-app
- Environment: dev/prod

Example output:
```
Service         | Dev/Month | Prod/Month
EC2 Instances   | $9        | $90
Load Balancer   | $16       | $16
Data Transfer   | $5        | $10
Storage         | $2        | $5
Total           | $32       | $121
```

## Troubleshooting Verification

### Check Instance Logs

```powershell
# View instance system log
aws ec2 get-console-output --instance-id i-0123456789abcdef0

# View user data execution log (on instance)
# SSH into instance and check:
# /var/log/user-data-init.log
```

### Check Application Health

**Via AWS Systems Manager Session Manager** (requires IAM permission):

```powershell
# List available instances
aws ssm describe-instance-information `
    --query "InstanceInformationList[*].[InstanceId,ComputerName]" `
    --region us-east-1

# Start session
aws ssm start-session --target i-0123456789abcdef0

# Inside session:
curl http://localhost/health
sudo systemctl status httpd
sudo tail -f /var/log/httpd/access_log
```

### Monitor Real-time Metrics

```powershell
# CPU Utilization
aws cloudwatch get-metric-statistics `
    --namespace AWS/EC2 `
    --metric-name CPUUtilization `
    --start-time (Get-Date).AddHours(-1) `
    --end-time (Get-Date) `
    --period 300 `
    --statistics Maximum,Average `
    --dimensions Name=AutoScalingGroupName,Value=devops-app-asg-dev

# Target Group Health
aws elbv2 describe-target-health `
    --target-group-arn arn:aws:elasticloadbalancing:... `
    --region us-east-1
```

## Scaling Verification Checklist

After scaling operation, verify:

- [ ] Desired instance count matches configuration
- [ ] All instances registered with ALB
- [ ] All instances passing health checks
- [ ] Application responding on all instances
- [ ] Load balanced across instances
- [ ] No errors in CloudWatch logs
- [ ] ALB metrics (RequestCount, HealthyHostCount) correct
- [ ] Auto-scaling activity logged successfully

## Clean-up Verification

Before destroying infrastructure, verify:

- [ ] Data backed up (state, logs, etc.)
- [ ] All applications stopped cleanly
- [ ] No ongoing deployments
- [ ] S3 buckets backed up to secondary location
- [ ] Documentation of configuration saved

After destruction, verify:

- [ ] All EC2 instances terminated
- [ ] ALB removed
- [ ] VPC subnets and IGW removed
- [ ] Security groups deleted
- [ ] Billing no longer shows EC2/ALB charges
- [ ] S3 buckets and DynamoDB retained (for recovery)

---

**Last Updated**: 2026-03-26
