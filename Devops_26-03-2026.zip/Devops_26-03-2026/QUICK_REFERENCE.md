# Quick Reference - Essential Commands

## Setup Commands

```powershell
# 1. Configure AWS Credentials
aws configure

# 2. Initialize Terraform (first time only)
.\init.bat dev
.\init.bat prod

# 3. Verify setup
terraform -version
aws sts get-caller-identity
```

## Deployment Commands

```powershell
# Plan infrastructure changes
.\plan.bat dev         # Preview without applying
.\plan.bat dev true    # Save plan to file

# Apply infrastructure
.\apply.bat dev        # Deploy to development
.\apply.bat prod       # Deploy to production

# Get application endpoint
.\output.bat dev load_balancer_dns
```

## Scaling Commands

```powershell
# View current capacity
aws autoscaling describe-auto-scaling-groups `
    --auto-scaling-group-names devops-app-asg-dev `
    --query 'AutoScalingGroups[0].[DesiredCapacity,MinSize,MaxSize]'

# Scale to N instances
.\scale.bat dev 5      # Scale dev to 5 instances
.\scale.bat prod 10    # Scale prod to 10 instances

# Monitor scaling progress
aws autoscaling describe-scaling-activities `
    --auto-scaling-group-name devops-app-asg-dev `
    --max-records 5
```

## Monitoring Commands

```powershell
# Get ALB endpoint
$ALB = $(.\output.bat dev load_balancer_dns)

# Test health
curl http://$ALB/health

# View application logs
aws logs tail /aws/ec2/devops-app/dev --follow

# CPU metrics
aws cloudwatch get-metric-statistics `
    --namespace AWS/EC2 `
    --metric-name CPUUtilization `
    --start-time (Get-Date).AddHours(-1) `
    --end-time (Get-Date) `
    --period 300 `
    --statistics Average

# Target health
aws elbv2 describe-target-health `
    --target-group-arn $(.\output.bat dev target_group_arn)
```

## State Management Commands

```powershell
# Check state locks
.\locks.bat list dev
.\locks.bat list prod

# Release stuck lock (use with caution)
.\locks.bat release dev

# View state
cd terraform
terraform state list
terraform state show 'aws_instance.app[0]'  # Show specific resource

# Pull state locally (for backup)
terraform state pull > backup.tfstate
```

## Update Commands

```powershell
# Update instance count (no downtime)
.\scale.bat dev 3

# Update instance type (with rolling update)
# 1. Edit environments/dev/terraform.tfvars
# 2. Change instance_type = "t3.small"
# 3. Then:
.\plan.bat dev
.\apply.bat dev

# Update application code
# 1. Edit terraform/modules/compute/user_data.sh
# 2. Then:
.\apply.bat dev
# This triggers instance refresh

# Update load balancer settings
# 1. Edit terraform/modules/loadbalancer/main.tf
# 2. Or modify environments/dev/terraform.tfvars
# 3. Then:
.\apply.bat dev
```

## Rollback Commands

```powershell
# List available backups
dir terraform.dev.tfstate.backup.*

# Restore from backup
.\rollback.bat dev

# Verify restoration
.\plan.bat dev   # Should show minimal or no changes
```

## Troubleshooting Commands

```powershell
# Check instance status
aws ec2 describe-instances `
    --filters "Name=tag:aws:autoscaling:groupName,Values=devops-app-asg-dev" `
    --query 'Reservations[].Instances[].[InstanceId,State.Name]'

# View security groups
aws ec2 describe-security-groups `
    --filters "Name=group-name,Values=devops-app-*" `
    --query 'SecurityGroups[].[GroupName,GroupId]'

# Test SSH (if needed)
aws ssm start-session --target i-0123456789abcdef0

# View ALB details
aws elbv2 describe-load-balancers `
    --query "LoadBalancers[?contains(LoadBalancerName, 'devops-app')].LoadBalancerArn"

# Describe ASG details
aws autoscaling describe-auto-scaling-groups `
    --auto-scaling-group-names devops-app-asg-dev
```

## Cleanup Commands

```powershell
# Destroy infrastructure
.\destroy.bat dev
.\destroy.bat prod

# Remove Terraform state (after resources deleted)
aws s3 rm s3://devops-app-terraform-state-dev --recursive

# Remove DynamoDB table (optional)
aws dynamodb delete-table --table-name terraform-locks
```

## Useful Variables

```powershell
# Store commonly used values
$ENVIRONMENT = "dev"
$ALB_DNS = $(.\output.bat $ENVIRONMENT load_balancer_dns)
$INSTANCE_IDS = $(aws autoscaling describe-auto-scaling-groups `
    --auto-scaling-group-names devops-app-asg-$ENVIRONMENT `
    --query 'AutoScalingGroups[0].Instances[*].InstanceId' --output text).Split()
$TG_ARN = $(.\output.bat $ENVIRONMENT target_group_arn)

# Usage examples:
Write-Host "ALB: $ALB_DNS"
Write-Host "Instances: $INSTANCE_IDS"
```

## Common Workflows

### Deploy New Environment (Development)

```powershell
1. .\init.bat dev
2. .\plan.bat dev
3. .\apply.bat dev
4. $ALB = .\output.bat dev load_balancer_dns
5. curl http://$ALB/health
```

### Scale Up During Peak Hours

```powershell
1. .\scale.bat prod 10
2. # Wait 5-10 minutes
3. aws autoscaling describe-auto-scaling-groups `
       --auto-scaling-group-names devops-app-asg-prod
```

### Update Application Code

```powershell
1. # Edit terraform/modules/compute/user_data.sh
2. .\plan.bat dev
3. .\apply.bat dev
4. # Wait for instance refresh to complete
5. aws autoscaling describe-instance-refreshes `
       --auto-scaling-group-name devops-app-asg-dev
```

### Troubleshoot Unhealthy Targets

```powershell
1. aws elbv2 describe-target-health --target-group-arn [arn]
2. aws ec2 describe-instances --instance-ids [id]
3. aws logs tail /aws/ec2/devops-app/dev --since 5m
4. # SSH to instance if needed:
5. aws ssm start-session --target [instance-id]
```

### Full Infrastructure Rollback

```powershell
1. .\locks.bat list dev              # Verify no one else working
2. .\rollback.bat dev                # Restore previous state
3. .\plan.bat dev                    # Verify plan
4. .\apply.bat dev                   # Reapply restored state
```

## One-Liners

```powershell
# Get all instance IPs
aws ec2 describe-instances --filters "Name=tag:Environment,Values=dev" --query 'Reservations[].Instances[].[PrivateIpAddress,PublicIpAddress]'

# Monitor logs in real-time
aws logs tail /aws/ec2/devops-app/dev --follow

# Calculate monthly cost (rough estimate)
# Dev: ($9 ec2 + $16 alb + $5 data) = $30
# Prod: ($90 ec2 + $16 alb + $10 data) = $116

# Clear old backups (keep last 5)
# List: ls terraform.dev.tfstate.backup.* | Sort LastWriteTime | Select -First -5
```

## Important Notes

- Always use `.\plan.bat` before `.\apply.bat`
- Verify state backups before any major operation
- Test changes in `dev` before applying to `prod`
- Never manually modify state files directly
- Keep AWS credentials secure
- Use IAM roles instead of root account
- Enable MFA on AWS console account
- Review cost regularly

## Support Resources

- **Terraform Docs**: https://www.terraform.io/docs
- **AWS Services**: https://docs.aws.amazon.com/
- **AWS CLI Reference**: https://awscli.amazonaws.com/v2/documentation/api/latest/index.html
- **CloudWatch Monitoring**: https://docs.aws.amazon.com/cloudwatch/

---

**Last Updated**: 2026-03-26
