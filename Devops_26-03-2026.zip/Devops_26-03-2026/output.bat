# Terraform Output Script - Display Infrastructure Information
# This script outputs detailed infrastructure information

@echo off
REM Show Terraform outputs for the environment

if "%1"=="" (
    echo Usage: output.bat [dev^|prod] [optional: output_name]
    echo Example: output.bat dev
    echo Example: output.bat prod load_balancer_dns
    exit /b 1
)

set ENVIRONMENT=%1
set OUTPUT_NAME=%2

echo ========================================
echo Terraform Outputs - %ENVIRONMENT% Environment
echo ========================================
echo.

cd terraform

REM Select workspace
terraform workspace select %ENVIRONMENT%

echo Infrastructure Details:
echo.

if "%OUTPUT_NAME%"=="" (
    REM Show all outputs
    terraform output
) else (
    REM Show specific output
    terraform output %OUTPUT_NAME%
)

cd ..

echo.
echo ========================================
echo Use the Load Balancer DNS to access your application
echo Endpoint: http://[load_balancer_dns]
echo ========================================
