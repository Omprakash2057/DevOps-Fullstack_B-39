# Terraform Destroy Script - Destroy Infrastructure
# This script safely destroys the infrastructure with confirmation

@echo off
REM Destroy Terraform infrastructure

if "%1"=="" (
    echo Usage: destroy.bat [dev^|prod]
    echo Example: destroy.bat dev
    exit /b 1
)

set ENVIRONMENT=%1

echo ========================================
echo WARNING: Terraform Destroy
echo ========================================
echo.
echo This will DELETE all infrastructure for: %ENVIRONMENT%
echo This action CANNOT be undone!
echo.
echo Resources to be destroyed:
echo - VPC and Subnets
echo - EC2 Instances and Auto Scaling Group
echo - Application Load Balancer
echo - Security Groups
echo - IAM Roles and Policies
echo.

REM Safer: include confirmation message
setlocal enabledelayedexpansion
set /p CONFIRM="Are you ABSOLUTELY SURE? Type 'destroy-%ENVIRONMENT%' to confirm: "

if not "!CONFIRM!"=="destroy-%ENVIRONMENT%" (
    echo Destruction cancelled
    exit /b 0
)

echo.
echo Proceeding with destruction...
cd terraform

REM Select workspace
terraform workspace select %ENVIRONMENT%

REM Run terraform destroy
terraform destroy -var-file=../environments/%ENVIRONMENT%/terraform.tfvars -auto-approve

if errorlevel 1 (
    echo ERROR: Terraform destroy failed
    cd ..
    exit /b 1
)

cd ..

echo.
echo ========================================
echo Infrastructure Destroyed
echo ========================================
