# Terraform Apply Script - Apply Infrastructure Changes
# This script applies the infrastructure changes with proper safeguards

@echo off
REM Apply Terraform configuration to create/update infrastructure

if "%1"=="" (
    echo Usage: apply.bat [dev^|prod]
    echo Example: apply.bat dev
    exit /b 1
)

setlocal enabledelayedexpansion
set ENVIRONMENT=%1
set /A CONFIRMATION_TIMEOUT=30

echo ========================================
echo Terraform Apply - %ENVIRONMENT% Environment
echo ========================================
echo.
echo WARNING: This will modify infrastructure in %ENVIRONMENT%
echo.
echo Configuration Details:
if "%ENVIRONMENT%"=="dev" (
    echo - Instance Type: t3.micro
    echo - Instance Count: 1
    echo - Max Instances: 2
) else if "%ENVIRONMENT%"=="prod" (
    echo - Instance Type: t3.small
    echo - Instance Count: 3
    echo - Max Instances: 5
)
echo.

REM Navigate to terraform directory
cd terraform

REM Select workspace
echo Selecting workspace: %ENVIRONMENT%...
terraform workspace select %ENVIRONMENT%
if errorlevel 1 (
    echo ERROR: Workspace %ENVIRONMENT% not found
    cd ..
    exit /b 1
)

REM Backup current state
echo.
echo Creating state backup...
set BACKUP_FILE=terraform.%ENVIRONMENT%.tfstate.backup.%date:~-4%.%date:~-10,2%.%date:~-7,2%.%time:~0,2%.%time:~3,2%.%time:~6,2%
if exist terraform.%ENVIRONMENT%.tfstate (
    copy terraform.%ENVIRONMENT%.tfstate !BACKUP_FILE!
    echo State backed up to: !BACKUP_FILE!
) else (
    echo No existing state to back up
)

REM Run terraform apply
echo.
echo Applying infrastructure changes...
echo.

terraform apply -var-file=../environments/%ENVIRONMENT%/terraform.tfvars -auto-approve

if errorlevel 1 (
    echo ERROR: Terraform apply failed
    cd ..
    exit /b 1
)

REM Get outputs
echo.
echo ========================================
echo Infrastructure Applied Successfully!
echo ========================================
echo.
echo Retrieving infrastructure details...
terraform output -json > ../infrastructure_output_%ENVIRONMENT%.json
echo Outputs saved to: infrastructure_output_%ENVIRONMENT%.json

echo.
echo SSH Access:
echo terraform output -raw instance_ids

echo.
cd ..

echo.
echo ========================================
echo Next steps:
echo 1. Verify infrastructure in AWS Console
echo 2. Monitor logs: logs.bat %ENVIRONMENT%
echo 3. Scale infrastructure: scale.bat %ENVIRONMENT% [count]
echo 4. Rollback (if needed): rollback.bat %ENVIRONMENT%
echo ========================================
