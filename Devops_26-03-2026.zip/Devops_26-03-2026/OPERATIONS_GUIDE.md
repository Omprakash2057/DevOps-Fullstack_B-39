# Infrastructure Operations Guide

## Daily Operations

### Morning Health Check

1. **Verify Infrastructure Status**
   ```powershell
   # Check Auto Scaling Group
   aws autoscaling describe-auto-scaling-groups `
       --auto-scaling-group-names devops-app-asg-dev `
       --query 'AutoScalingGroups[0].[DesiredCapacity,MinSize,MaxSize]'
   ```

2. **Monitor Application Endpoints**
   ```powershell
   # Get ALB endpoint
   $ALB_DNS = terraform output -raw load_balancer_dns
   curl http://$ALB_DNS/health
   ```

3. **Review CloudWatch Logs**
   ```powershell
   # Recent application logs
   aws logs tail /aws/ec2/devops-app/dev --follow --lines 50
   ```

## Scaling Operations

### Scenario 1: Handle Traffic Spike

**Issue**: Traffic spike detected, current capacity insufficient

**Solution**:
```powershell
# Immediate manual scaling
.\scale.bat prod 5

# Monitor auto-scaling
aws autoscaling describe-auto-scaling-activities `
    --auto-scaling-group-name devops-app-asg-prod `
    --max-records 10
```

**Timeline**:
- T+0: Scaling triggered
- T+2 min: New instances starting
- T+5 min: Instance registration complete
- T+8 min: Full capacity online

### Scenario 2: Reduce Costs During Off-Peak

**Issue**: Off-peak hours, reduce infrastructure cost

**Solution**:
```powershell
# Scale down (minimum stays at min_instances)
.\scale.bat dev 1

# Or update auto-scaling thresholds
cd terraform
terraform apply `
    -var-file=../environments/dev/terraform.tfvars `
    -var="cpu_target_utilization=50"
```

## Update Operations

### Update Instance Type

**Scenario**: Upgrade from t3.micro to t3.small

**Steps**:
1. Update `environments/dev/terraform.tfvars`:
   ```hcl
   instance_type = "t3.small"
   ```

2. Plan changes:
   ```powershell
   .\plan.bat dev
   ```

3. Review the plan - should show:
   - Launch template update
   - Instance refresh triggered

4. Apply changes:
   ```powershell
   .\apply.bat dev
   ```

5. Monitor refresh progress:
   ```powershell
   aws autoscaling describe-instance-refreshes `
       --auto-scaling-group-name devops-app-asg-dev
   ```

### Update Application Configuration

**Scenario**: Deploy new application version

**Steps**:
1. Update `terraform/modules/compute/user_data.sh`

2. Plan (will update launch template):
   ```powershell
   .\plan.bat dev
   ```

3. Apply:
   ```powershell
   .\apply.bat dev
   ```

4. Trigger instance refresh:
   ```powershell
   aws autoscaling start-instance-refresh `
       --auto-scaling-group-name devops-app-asg-dev `
       --preferences '{MinHealthyPercentage=90}'
   ```

## Troubleshooting Guide

### Issue: Instances Failing Health Checks

**Symptoms**:
- ALB showing unhealthy targets
- New instances being terminated

**Diagnosis**:
```powershell
# Check target health
$TARGET_GROUP_ARN = "arn:aws:elasticloadbalancing:..."
aws elbv2 describe-target-health --target-group-arn $TARGET_GROUP_ARN

# SSH into problematic instance
ssh -i key.pem ec2-user@[instance-ip]

# Test health endpoint
curl http://localhost/health
curl http://localhost/

# Check web server status
sudo systemctl status httpd
sudo systemctl restart httpd
```

**Solution**:
- Verify security groups allow ALB traffic
- Check user_data script for errors
- Increase health_check_grace_period if needed
- Review application logs

### Issue: Scaling Not Triggering

**Symptoms**:
- CPU at 90% but no new instances launching
- Desired capacity matches current capacity

**Diagnosis**:
```powershell
# Check ASG configuration
aws autoscaling describe-auto-scaling-groups `
    --auto-scaling-group-names devops-app-asg-dev `
    --query 'AutoScalingGroups[0].[MinSize,MaxSize,DesiredCapacity]'

# Check scaling policies
aws autoscaling describe-policies `
    --auto-scaling-group-name devops-app-asg-dev
```

**Solutions**:
- Increase `max_instances` if at limit
- Verify scaling policy is attached
- Check CloudWatch metrics configuration
- Review AWS account service limits

### Issue: State Lock Stuck

**Symptoms**:
- Terraform commands hanging
- "Acquiring lock" message stays indefinitely

**Diagnosis**:
```powershell
# Check locks
.\locks.bat list dev

# See who locked it and when
aws dynamodb scan --table-name terraform-locks
```

**Solution**:
```powershell
# Release stuck lock (only if certain no one else using terraform)
.\locks.bat release dev

# Or wait for lock to timeout (5 min default)
```

## Monitoring Queries

### Real-time Traffic Monitor

```powershell
# Request count in ALB
aws cloudwatch get-metric-statistics `
    --namespace AWS/ApplicationELB `
    --metric-name RequestCount `
    --start-time (Get-Date).AddHours(-1) `
    --end-time (Get-Date) `
    --period 60 `
    --statistics Sum
```

### Instance Status

```powershell
# Full instance details
aws ec2 describe-instances `
    --filters "Name=tag:aws:autoscaling:groupName,Values=devops-app-asg-dev" `
    --query 'Reservations[].Instances[].[InstanceId,State.Name,InstanceType,PublicIpAddress]'
```

### Auto-scaling Activity Log

```powershell
# Last 10 scaling activities
aws autoscaling describe-scaling-activities `
    --auto-scaling-group-name devops-app-asg-dev `
    --max-records 10
```

## Backup and Recovery

### Automated Backups

Backups occur automatically before each apply:

```powershell
# List backups
dir terraform.*.tfstate.backup.*

# Size and timestamp
ls terraform.*.tfstate.backup.* -File | Select-Object Name, Length, LastWriteTime
```

### Manual State Backup

```powershell
# Backup current state
$timestamp = Get-Date -Format "yyyyMMdd_HHmmss"
Copy-Item terraform/terraform.tfstate "backup_$timestamp.tfstate"

# Upload to S3
aws s3 cp "backup_$timestamp.tfstate" s3://devops-app-backups/
```

### Recovery Process

**If infrastructure is corrupted**:

1. Identify last good backup:
   ```powershell
   dir terraform.dev.tfstate.backup.* | Sort-Object LastWriteTime -Descending | Select-Object -First 5
   ```

2. Restore state:
   ```powershell
   .\rollback.bat dev
   ```

3. Verify and apply:
   ```powershell
   .\plan.bat dev
   .\apply.bat dev
   ```

## Maintenance Windows

### Recommended Maintenance Schedule

**Weekly**:
- Review CloudWatch metrics
- Check for failed auto-scaling activities
- Verify health check status

**Monthly**:
- Test backup restore procedure
- Review and clean up logs
- Audit IAM permissions
- Review cost trends

**Quarterly**:
- Update Terraform provider versions
- Review security configurations
- Test disaster recovery procedures

## Change Management

### Before Any Change

1. **Create backup**:
   ```powershell
   Copy-Item terraform/terraform.tfstate "pre-change.backup"
   ```

2. **Plan thoroughly**:
   ```powershell
   .\plan.bat dev > change_plan.txt
   ```

3. **Review with team**:
   - Share plan output
   - Discuss potential impact
   - Get approval

4. **Prepare rollback**:
   ```powershell
   .\rollback.bat dev  # Know the procedure
   ```

### During Change

1. **Apply changes**:
   ```powershell
   .\apply.bat dev
   ```

2. **Monitor progress**:
   ```powershell
   # Watch instance refresh
   aws autoscaling describe-instance-refreshes `
       --auto-scaling-group-name devops-app-asg-dev `
       --query 'InstanceRefreshes[0].[Status,PercentageComplete]' `
       --interval 5
   ```

3. **Verify application**:
   ```powershell
   curl http://[alb-dns]/
   ```

### After Change

1. **Verify all targets healthy**:
   ```powershell
   aws elbv2 describe-target-health --target-group-arn [arn]
   ```

2. **Monitor for 30 minutes**
3. **Confirm successful rollout**
4. **Document change** in change log

## Documentation Template

Create a `CHANGE_LOG.md` to track all infrastructure changes:

```markdown
## 2026-03-26 - Scaled from 2 to 3 instances

### Change Details
- **Environment**: Production
- **Initiated By**: DevOps Team
- **Duration**: 15 minutes
- **Downtime**: 0 minutes

### Changes Made
- Increased desired_instances from 2 to 3
- Triggered instance refresh for rolling update

### Verification
- All instances passed health checks
- No failed requests during update
- Application responsiveness normal

### Rollback Plan
- Revert to 2 instances: `.\scale.bat prod 2`
- Previous state backed up: terraform.prod.tfstate.backup.20260326

### Notes
- Traffic remained under 500 req/min during scaling
- New instances launched successfully
- No manual intervention required
```

---

**Last Updated**: 2026-03-26
