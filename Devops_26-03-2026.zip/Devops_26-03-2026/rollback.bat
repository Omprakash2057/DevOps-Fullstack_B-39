# Terraform State Rollback Script - Revert to Previous Infrastructure State
# This script allows rolling back to a previous Terraform state

@echo off
REM Rollback infrastructure to a previous state

if "%1"=="" (
    echo Usage: rollback.bat [dev^|prod]
    echo Example: rollback.bat dev
    exit /b 1
)

set ENVIRONMENT=%1

echo ========================================
echo Terraform State Rollback
echo ========================================
echo Environment: %ENVIRONMENT%
echo.

REM List available backups
echo Available state backups:
dir terraform.%ENVIRONMENT%.tfstate.backup.* 2>nul
if errorlevel 1 (
    echo No backups found!
    exit /b 1
)

echo.
set /p BACKUP_FILE="Enter the backup filename to restore: "

if not exist "!BACKUP_FILE!" (
    echo ERROR: Backup file not found: !BACKUP_FILE!
    exit /b 1
)

echo.
echo WARNING: This will restore infrastructure to a previous state
echo Current state will be backed up first
echo.

cd terraform

REM Backup current state
set CURRENT_BACKUP=terraform.%ENVIRONMENT%.tfstate.backup.before-rollback
copy terraform.%ENVIRONMENT%.tfstate !CURRENT_BACKUP!
echo Current state backed up to: !CURRENT_BACKUP!

REM Restore backup
echo.
echo Restoring from backup: !BACKUP_FILE!
copy ..\!BACKUP_FILE! terraform.%ENVIRONMENT%.tfstate

echo.
echo State restored successfully
echo.

cd ..

echo ========================================
echo Rollback Completed
echo Next steps:
echo 1. Review the restored state
echo 2. Run: plan.bat %ENVIRONMENT%
echo 3. If satisfied, run: apply.bat %ENVIRONMENT%
echo ========================================
