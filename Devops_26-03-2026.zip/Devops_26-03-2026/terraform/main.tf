# Main orchestration file
# This file calls the modules to build the complete infrastructure

# Networking Module
module "networking" {
  source = "./modules/networking"

  environment           = var.environment
  project_name          = var.project_name
  vpc_cidr              = var.vpc_cidr
  availability_zones    = var.availability_zones
  aws_region            = var.aws_region
}

# Compute Module
module "compute" {
  source = "./modules/compute"

  depends_on = [module.networking]

  environment            = var.environment
  project_name           = var.project_name
  instance_type          = var.instance_type
  instance_count         = var.instance_count
  min_instances          = var.min_instances
  max_instances          = var.max_instances
  desired_instances      = var.desired_instances
  cpu_target_utilization = var.cpu_target_utilization
  
  vpc_id                 = module.networking.vpc_id
  private_subnet_ids     = module.networking.private_subnet_ids
  security_group_id      = module.networking.app_security_group_id
  target_group_arn       = module.loadbalancer.target_group_arn
}

# Load Balancer Module
module "loadbalancer" {
  source = "./modules/loadbalancer"

  depends_on = [module.networking]

  environment           = var.environment
  project_name          = var.project_name
  vpc_id                = module.networking.vpc_id
  public_subnet_ids     = module.networking.public_subnet_ids
  security_group_id     = module.networking.alb_security_group_id
  
  enable_stickiness     = var.enable_stickiness
  health_check_interval = var.health_check_interval
  health_check_timeout  = var.health_check_timeout
  healthy_threshold     = var.healthy_threshold
  unhealthy_threshold   = var.unhealthy_threshold
}
