# Core Variables
variable "aws_region" {
  description = "AWS region for resources"
  type        = string
  default     = "us-east-1"
}

variable "environment" {
  description = "Environment name (dev, prod)"
  type        = string
  validation {
    condition     = contains(["dev", "prod"], var.environment)
    error_message = "Environment must be 'dev' or 'prod'."
  }
}

variable "project_name" {
  description = "Project name for resource naming"
  type        = string
}

# Compute Variables
variable "instance_count" {
  description = "Number of application instances"
  type        = number
  default     = 2
  validation {
    condition     = var.instance_count >= 1 && var.instance_count <= 10
    error_message = "Instance count must be between 1 and 10."
  }
}

variable "instance_type" {
  description = "EC2 instance type"
  type        = string
  default     = "t3.micro"
}

variable "sns_email" {
  description = "Email for SNS notifications"
  type        = string
  default     = "ops@example.com"
}

# Networking Variables
variable "vpc_cidr" {
  description = "CIDR block for VPC"
  type        = string
  default     = "10.0.0.0/16"
}

variable "availability_zones" {
  description = "List of availability zones"
  type        = list(string)
  default     = ["us-east-1a", "us-east-1b"]
}

# Load Balancer Variables
variable "enable_stickiness" {
  description = "Enable session stickiness on load balancer"
  type        = bool
  default     = false
}

variable "health_check_interval" {
  description = "Health check interval in seconds"
  type        = number
  default     = 30
  validation {
    condition     = var.health_check_interval >= 5 && var.health_check_interval <= 300
    error_message = "Health check interval must be between 5 and 300 seconds."
  }
}

variable "health_check_timeout" {
  description = "Health check timeout in seconds"
  type        = number
  default     = 5
}

variable "healthy_threshold" {
  description = "Number of successful checks before marking healthy"
  type        = number
  default     = 2
}

variable "unhealthy_threshold" {
  description = "Number of failed checks before marking unhealthy"
  type        = number
  default     = 2
}

# Auto Scaling Variables
variable "min_instances" {
  description = "Minimum number of instances in auto-scaling group"
  type        = number
  default     = 2
  validation {
    condition     = var.min_instances >= 1
    error_message = "Minimum instances must be at least 1."
  }
}

variable "max_instances" {
  description = "Maximum number of instances in auto-scaling group"
  type        = number
  default     = 5
  validation {
    condition     = var.max_instances >= var.min_instances
    error_message = "Maximum instances must be >= minimum instances."
  }
}

variable "desired_instances" {
  description = "Desired number of instances"
  type        = number
  default     = 2
}

variable "cpu_target_utilization" {
  description = "Target CPU utilization for auto-scaling (%)"
  type        = number
  default     = 70
  validation {
    condition     = var.cpu_target_utilization > 0 && var.cpu_target_utilization < 100
    error_message = "CPU target utilization must be between 0 and 100."
  }
}

# State Management Variables
variable "enable_state_locking" {
  description = "Enable DynamoDB state locking"
  type        = bool
  default     = true
}

variable "terraform_lock_table" {
  description = "DynamoDB table name for state locking"
  type        = string
  default     = "terraform-locks"
}

variable "terraform_state_bucket" {
  description = "S3 bucket name for Terraform state"
  type        = string
}

variable "enable_versioning" {
  description = "Enable S3 versioning for state backup"
  type        = bool
  default     = true
}
