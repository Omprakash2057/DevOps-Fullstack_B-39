# Networking Outputs
output "vpc_id" {
  description = "VPC ID"
  value       = module.networking.vpc_id
}

output "public_subnets" {
  description = "Public subnet IDs"
  value       = module.networking.public_subnet_ids
}

output "private_subnets" {
  description = "Private subnet IDs"
  value       = module.networking.private_subnet_ids
}

# Compute Outputs
output "launch_template_id" {
  description = "Launch template ID"
  value       = module.compute.launch_template_id
}

output "autoscaling_group_name" {
  description = "Auto Scaling Group name"
  value       = module.compute.asg_name
}

output "autoscaling_group_arn" {
  description = "Auto Scaling Group ARN"
  value       = module.compute.asg_arn
}

output "instance_ids" {
  description = "IDs of EC2 instances"
  value       = module.compute.instance_ids
}

output "current_instance_count" {
  description = "Current number of running instances"
  value       = module.compute.instance_count
}

# Load Balancer Outputs
output "load_balancer_dns" {
  description = "DNS name of the load balancer"
  value       = module.loadbalancer.alb_dns_name
}

output "load_balancer_arn" {
  description = "ARN of the load balancer"
  value       = module.loadbalancer.alb_arn
}

output "target_group_arn" {
  description = "ARN of the target group"
  value       = module.loadbalancer.target_group_arn
}

output "application_endpoint" {
  description = "Application endpoint URL"
  value       = "http://${module.loadbalancer.alb_dns_name}"
}

# Environment Outputs
output "environment_name" {
  description = "Deployment environment"
  value       = var.environment
}

output "aws_region" {
  description = "AWS region"
  value       = var.aws_region
}

output "project_name" {
  description = "Project name"
  value       = var.project_name
}

# Scaling Configuration Outputs
output "scaling_configuration" {
  description = "Current scaling configuration"
  value = {
    min_instances          = var.min_instances
    max_instances          = var.max_instances
    desired_instances      = var.desired_instances
    cpu_target_utilization = var.cpu_target_utilization
  }
}
