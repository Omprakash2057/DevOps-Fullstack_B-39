# Development Environment Terraform Variables

aws_region                = "us-east-1"
project_name              = "devops-app"
environment               = "dev"
instance_type             = "t3.micro"
instance_count            = 1
min_instances             = 1
max_instances             = 2
desired_instances         = 1
cpu_target_utilization    = 80
vpc_cidr                  = "10.0.0.0/16"
availability_zones        = ["us-east-1a"]
enable_stickiness         = false
health_check_interval     = 60
health_check_timeout      = 5
healthy_threshold         = 2
unhealthy_threshold       = 2
enable_state_locking      = true
terraform_lock_table      = "terraform-locks"
terraform_state_bucket    = "devops-app-terraform-state-dev"
enable_versioning         = true
sns_email                 = "dev-ops@mycompany.com"
