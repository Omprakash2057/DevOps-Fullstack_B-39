# Development Environment Configuration

terraform {
  required_version = ">= 1.0"
}

locals {
  environment = "dev"
}

# Development environment variables
variable "aws_region" {
  default = "us-east-1"
}

variable "terraform_state_bucket" {
  description = "S3 bucket for Terraform state"
  type        = string
}

variable "terraform_lock_table" {
  default = "terraform-locks"
}

# Module inputs for development (cost-optimized)
module "dev_infrastructure" {
  source = "../"

  # Core configuration
  aws_region           = var.aws_region
  environment          = local.environment
  project_name         = "devops-app"

  # Development-specific settings
  instance_type        = "t3.micro"          # Cost-effective for dev
  instance_count       = 1                    # Single instance in dev
  min_instances        = 1
  max_instances        = 2                    # Limited scaling
  desired_instances    = 1
  cpu_target_utilization = 80                 # Higher threshold for dev

  # Network configuration
  vpc_cidr             = "10.0.0.0/16"
  availability_zones   = ["us-east-1a"]     # Single AZ for dev

  # Load balancer configuration
  enable_stickiness    = false
  health_check_interval = 60                  # Less frequent checks in dev
  health_check_timeout  = 5
  healthy_threshold    = 2
  unhealthy_threshold  = 2

  # State management
  enable_state_locking = true
  terraform_state_bucket = var.terraform_state_bucket
  terraform_lock_table = var.terraform_lock_table
}

output "dev_infrastructure" {
  value = module.dev_infrastructure
}
