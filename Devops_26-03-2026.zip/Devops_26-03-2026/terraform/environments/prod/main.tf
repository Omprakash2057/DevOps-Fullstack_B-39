# Production Environment Configuration

terraform {
  required_version = ">= 1.0"
}

locals {
  environment = "prod"
}

# Production environment variables
variable "aws_region" {
  default = "us-east-1"
}

variable "terraform_state_bucket" {
  description = "S3 bucket for Terraform state"
  type        = string
}

variable "terraform_lock_table" {
  default = "terraform-locks"
}

# Module inputs for production (high availability)
module "prod_infrastructure" {
  source = "../"

  # Core configuration
  aws_region           = var.aws_region
  environment          = local.environment
  project_name         = "devops-app"

  # Production settings
  instance_type        = "t3.small"           # Better performance for prod
  instance_count       = 3                    # Multiple instances for HA
  min_instances        = 2                    # Maintain minimum capacity
  max_instances        = 5                    # Allow scaling
  desired_instances    = 3
  cpu_target_utilization = 70                 # More aggressive scaling

  # Network configuration
  vpc_cidr             = "10.1.0.0/16"
  availability_zones   = ["us-east-1a", "us-east-1b", "us-east-1c"]  # Multi-AZ

  # Load balancer configuration
  enable_stickiness    = true                 # Session affinity for stateful apps
  health_check_interval = 30                  # Frequent health checks
  health_check_timeout  = 5
  healthy_threshold    = 2
  unhealthy_threshold  = 3                    # More forgiving failure detection

  # State management
  enable_state_locking = true
  terraform_state_bucket = var.terraform_state_bucket
  terraform_lock_table = var.terraform_lock_table
}

output "prod_infrastructure" {
  value = module.prod_infrastructure
}
