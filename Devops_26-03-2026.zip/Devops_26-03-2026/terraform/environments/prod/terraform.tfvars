# Production Environment Terraform Variables

aws_region                = "us-east-1"
project_name              = "devops-app"
environment               = "prod"
instance_type             = "t3.small"
instance_count            = 3
min_instances             = 2
max_instances             = 5
desired_instances         = 3
cpu_target_utilization    = 70
vpc_cidr                  = "10.1.0.0/16"
availability_zones        = ["us-east-1a", "us-east-1b", "us-east-1c"]
enable_stickiness         = true
health_check_interval     = 30
health_check_timeout      = 5
healthy_threshold         = 2
unhealthy_threshold       = 3
enable_state_locking      = true
terraform_lock_table      = "terraform-locks"
terraform_state_bucket    = "devops-app-terraform-state-prod"
enable_versioning         = true
sns_email                 = "prod-ops@mycompany.com"
