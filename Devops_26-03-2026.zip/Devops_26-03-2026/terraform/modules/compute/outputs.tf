# Compute Module - Outputs

output "launch_template_id" {
  value = aws_launch_template.app.id
}

output "launch_template_latest_version" {
  value = aws_launch_template.app.latest_version_number
}

output "asg_name" {
  value = aws_autoscaling_group.app.name
}

output "asg_arn" {
  value = aws_autoscaling_group.app.arn
}

output "instance_ids" {
  value = aws_autoscaling_group.app.id
}

output "instance_count" {
  value = aws_autoscaling_group.app.desired_capacity
}

output "min_instances" {
  value = aws_autoscaling_group.app.min_size
}

output "max_instances" {
  value = aws_autoscaling_group.app.max_size
}

output "iam_role_arn" {
  value = aws_iam_role.app.arn
}

output "iam_instance_profile_arn" {
  value = aws_iam_instance_profile.app.arn
}
