#!/bin/bash
set -e

# Log all output
exec > >(tee /var/log/user-data-init.log)
exec 2>&1

echo "Starting application server initialization for ${environment} environment"

# Update system packages
yum update -y

# Install required packages
yum install -y \
    httpd \
    curl \
    wget \
    net-tools \
    amazon-cloudwatch-agent \
    aws-cli

# Enable and start Apache
systemctl enable httpd
systemctl start httpd

# Create a simple health check endpoint
cat > /var/www/html/index.html << 'EOF'
<!DOCTYPE html>
<html>
<head>
    <title>Application Running</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 40px; }
        .status { color: green; }
    </style>
</head>
<body>
    <h1 class="status">✓ Application Server Active</h1>
    <p>Instance: <code>$(hostname -I)</code></p>
    <p>Environment: ${environment}</p>
    <p>Timestamp: <code>$(date)</code></p>
</body>
</html>
EOF

# Create health check endpoint
cat > /var/www/html/health << 'EOF'
OK
EOF

# Configure CloudWatch agent (basic config)
cat > /opt/aws/amazon-cloudwatch-agent/etc/config.json << 'EOF'
{
  "agent": {
    "metrics_collection_interval": 60,
    "run_as_user": "root"
  },
  "logs": {
    "logs_collected": {
      "files": {
        "collect_list": [
          {
            "file_path": "/var/log/httpd/access_log",
            "log_group_name": "/aws/ec2/app-logs",
            "log_stream_name": "{instance_id}"
          }
        ]
      }
    }
  }
}
EOF

echo "Application server initialization completed successfully"
