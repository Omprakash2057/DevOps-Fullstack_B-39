# Compute Module - Variables

variable "environment" {
  type = string
}

variable "project_name" {
  type = string
}

variable "instance_type" {
  type = string
}

variable "instance_count" {
  type = number
}

variable "min_instances" {
  type = number
}

variable "max_instances" {
  type = number
}

variable "desired_instances" {
  type = number
}

variable "cpu_target_utilization" {
  type = number
}

variable "vpc_id" {
  type = string
}

variable "private_subnet_ids" {
  type = list(string)
}

variable "security_group_id" {
  type = string
}

variable "target_group_arn" {
  type = string
}
