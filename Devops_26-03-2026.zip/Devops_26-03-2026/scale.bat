# Terraform Scaling Script - Scale Application Instances
# This script allows dynamic scaling of application instances

@echo off
REM Scale the number of running instances

if "%1"=="" (
    echo Usage: scale.bat [dev^|prod] [instance_count]
    echo Example: scale.bat dev 3
    echo Example: scale.bat prod 5
    exit /b 1
)

if "%2"=="" (
    echo ERROR: Instance count not provided
    echo Usage: scale.bat [dev^|prod] [instance_count]
    exit /b 1
)

set ENVIRONMENT=%1
set INSTANCE_COUNT=%2

echo ========================================
echo Terraform Scaling
echo ========================================
echo Environment: %ENVIRONMENT%
echo New Instance Count: %INSTANCE_COUNT%
echo.

cd terraform

REM Select workspace
terraform workspace select %ENVIRONMENT%

REM Apply with new instance count
echo Applying new configuration...
terraform apply ^
    -var-file=../environments/%ENVIRONMENT%/terraform.tfvars ^
    -var="desired_instances=%INSTANCE_COUNT%" ^
    -auto-approve

if errorlevel 1 (
    echo ERROR: Scaling operation failed
    cd ..
    exit /b 1
)

cd ..

echo.
echo ========================================
echo Scaling Completed Successfully!
echo ========================================
echo New instance count: %INSTANCE_COUNT%
echo Instances will be provisioned/terminated automatically
echo Check AWS Console for progress
echo.
