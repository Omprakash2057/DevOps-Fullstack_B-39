output "instance_id" {
  description = "ID of the EC2 instance"
  value       = aws_instance.web_server.id
}

output "instance_public_ip" {
  description = "Public IP address of the web server"
  value       = aws_instance.web_server.public_ip
  sensitive   = false
}

output "instance_private_ip" {
  description = "Private IP address of the web server"
  value       = aws_instance.web_server.private_ip
}

output "elastic_ip" {
  description = "Elastic IP address of the web server"
  value       = var.enable_public_ip ? aws_eip.web_server[0].public_ip : null
}

output "web_server_url" {
  description = "URL to access the web server"
  value       = "http://${aws_instance.web_server.public_ip}"
}

output "web_server_url_elastic_ip" {
  description = "URL to access the web server using Elastic IP"
  value       = var.enable_public_ip ? "http://${aws_eip.web_server[0].public_ip}" : null
}

output "security_group_id" {
  description = "ID of the security group"
  value       = aws_security_group.web_server.id
}

output "vpc_id" {
  description = "ID of the VPC"
  value       = aws_vpc.main.id
}

output "subnet_id" {
  description = "ID of the public subnet"
  value       = aws_subnet.public.id
}

output "instance_state" {
  description = "Current state of the EC2 instance"
  value       = aws_instance.web_server.instance_state
}

output "ssh_command" {
  description = "SSH command to connect to the instance"
  value       = "ssh -i /path/to/your/key.pem ec2-user@${aws_instance.web_server.public_ip}"
}

output "health_check_url" {
  description = "Health check endpoint URL"
  value       = "http://${aws_instance.web_server.public_ip}/health.html"
}

output "aws_region" {
  description = "AWS region where resources are deployed"
  value       = var.aws_region
}

output "instance_type" {
  description = "Instance type of the EC2 instance"
  value       = var.instance_type
}

output "deployment_summary" {
  description = "Summary of the deployed infrastructure"
  value = {
    web_server_url  = "http://${aws_instance.web_server.public_ip}"
    instance_type   = var.instance_type
    region          = var.aws_region
    environment     = var.environment
    instance_id     = aws_instance.web_server.id
  }
}
