# Terraform Web Server Infrastructure

A complete Infrastructure as Code (IaC) solution for deploying a secure web server on AWS using Terraform.

## 📋 Project Overview

This Terraform project provides a production-ready configuration to deploy a web server infrastructure on AWS. It includes:

- **VPC and Networking**: Custom VPC with public subnet and internet gateway
- **Security Group**: Configured to allow HTTP (80), HTTPS (443), and SSH (22)
- **EC2 Instance**: Runs Amazon Linux 2 with Apache web server pre-installed
- **Elastic IP**: Static public IP address for consistent access
- **Monitoring**: CloudWatch detailed monitoring enabled
- **Automation**: User data script for automatic web server setup

## 📁 Project Structure

```
terraform-web-server/
├── provider.tf           # AWS provider configuration
├── main.tf              # Main infrastructure resources (VPC, EC2, Security Group)
├── variables.tf         # Variable definitions and locals
├── outputs.tf           # Output values
├── terraform.tfvars     # Variable values (customize this file)
├── .gitignore           # Git ignore file
├── README.md            # This file
├── DEPLOYMENT_GUIDE.md  # Step-by-step deployment instructions
└── TROUBLESHOOTING.md   # Common issues and solutions
```

## 🔐 Security Features

- **Security Group**: Restrictive ingress rules for HTTP and SSH
  - HTTP: Port 80 (configurable CIDR)
  - SSH: Port 22 (configurable CIDR)
  - All outbound traffic allowed
- **Encryption**: EBS volume encryption enabled
- **Network Isolation**: Resources deployed in private VPC
- **Access Control**: SSH restricted to specified CIDR blocks

## 🚀 Quick Start

### Prerequisites

1. **AWS Account**: Active AWS account with billing enabled
2. **Terraform**: Version 1.0 or later
3. **AWS CLI**: Configured with credentials
4. **SSH Key Pair**: Created in your chosen AWS region

### Installation

1. **Install Terraform**:
   ```bash
   # Windows (using Chocolatey)
   choco install terraform
   
   # Or download from: https://www.terraform.io/downloads
   ```

2. **Configure AWS Credentials**:
   ```bash
   # Option 1: Using AWS CLI
   aws configure
   
   # Option 2: Using environment variables
   $env:AWS_ACCESS_KEY_ID = "your-access-key"
   $env:AWS_SECRET_ACCESS_KEY = "your-secret-key"
   $env:AWS_REGION = "us-east-1"
   ```

3. **Clone/Download Project**:
   ```bash
   cd terraform-web-server
   ```

## 📝 Configuration

### Customize Variables

Edit `terraform.tfvars` to customize your deployment:

```hcl
aws_region       = "us-east-1"        # AWS region
instance_type    = "t3.micro"         # EC2 instance type
environment      = "development"      # Environment name
instance_name    = "web-server"       # Resource name prefix
enable_public_ip = true               # Enable public IP
allowed_http_cidr = ["0.0.0.0/0"]    # HTTP access (0.0.0.0/0 = open)
allowed_ssh_cidr  = ["0.0.0.0/0"]    # SSH access (restrict to your IP)
```

**Security Tip**: Replace `0.0.0.0/0` with your actual IP address:
```hcl
allowed_ssh_cidr = ["203.0.113.45/32"]  # Your IP/32
```

## 🎯 Deployment Steps

### 1. Initialize Terraform

```bash
terraform init
```

This downloads the AWS provider and initializes the working directory.

### 2. Validate Configuration

```bash
terraform validate
```

Checks for syntax errors and configuration consistency.

### 3. Plan Deployment

```bash
terraform plan
# Or save plan to file
terraform plan -out=tfplan
```

This shows what resources will be created. Review carefully!

### 4. Apply Configuration

```bash
terraform apply
# Or apply saved plan
terraform apply tfplan
```

When prompted, type `yes` to confirm deployment.

### 5. Verify Deployment

Once deployment completes:

```bash
# Get outputs
terraform output

# Test web server
$webUrl = terraform output -raw web_server_url
Start-Process $webUrl
```

## 🔄 Managing Infrastructure

### View Deployed Resources

```bash
terraform state list
terraform state show aws_instance.web_server
```

### Update Configuration

Edit variables in `terraform.tfvars`, then:

```bash
terraform plan
terraform apply
```

### Modify Security Group Rules

Edit security group rules in `main.tf`:

```hcl
ingress {
  from_port   = 8080  # New port
  to_port     = 8080
  protocol    = "tcp"
  cidr_blocks = ["0.0.0.0/0"]
}
```

Then apply:
```bash
terraform apply
```

### Scale: Add Additional Machines

Create `web_servers.tf`:

```hcl
resource "aws_instance" "web_server_2" {
  # Copy from main.tf and modify as needed
}
```

## 📊 Accessing the Web Server

### Via Public IP

```bash
# Get the URL
terraform output web_server_url

# Open in browser
# Or use curl
curl $(terraform output -raw web_server_url)
```

### Via SSH

```bash
# Get SSH command
terraform output ssh_command

# Adjust key path and run
ssh -i /path/to/your/key.pem ec2-user@<public-ip>
```

### Health Check

```bash
terraform output health_check_url
curl $(terraform output -raw health_check_url) | ConvertFrom-Json
```

## 🧹 Cleanup and Destruction

### Destroy All Resources

```bash
terraform destroy
```

This will delete all resources created by this Terraform project.

**Warning**: This is irreversible. Ensure you have backups of any important data.

### Selective Destruction

```bash
# Destroy specific resource
terraform destroy -target=aws_instance.web_server

# Plan destruction
terraform plan -destroy
```

## 📤 Outputs

After deployment, Terraform outputs useful information:

| Output | Description |
|--------|-------------|
| `instance_id` | EC2 instance ID |
| `instance_public_ip` | Public IP address |
| `web_server_url` | HTTP URL to access web server |
| `web_server_url_elastic_ip` | URL using Elastic IP |
| `ssh_command` | SSH command to connect |
| `security_group_id` | Security group ID |
| `vpc_id` | VPC ID |

```bash
# View all outputs
terraform output

# View specific output
terraform output web_server_url
```

## 🔧 Advanced Features

### Enable Monitoring

CloudWatch monitoring is enabled by default:

```hcl
enable_monitoring = true
```

### Customize Web Server Content

Edit the `user_data` script in `main.tf` to customize the web server setup.

### Add Additional Security

Implement a bastion host or VPN for SSH access instead of using `0.0.0.0/0`.

### Remote State Management

For team collaboration, use S3 state backend:

```hcl
terraform {
  backend "s3" {
    bucket         = "my-terraform-state"
    key            = "web-server/terraform.tfstate"
    region         = "us-east-1"
    encrypt        = true
    dynamodb_table = "terraform-locks"
  }
}
```

## 📚 Best Practices

1. **Version Control**: Keep Terraform files in Git
2. **State Management**: Use remote state for team projects
3. **Variable Management**: Use `.tfvars` for environment-specific values
4. **Testing**: Use `terraform plan` before `apply`
5. **Tagging**: Use consistent tags for resource organization
6. **Documentation**: Maintain this documentation as infrastructure evolves
7. **Backups**: Backup Terraform state files
8. **Security**: Restrict SSH access to specific IPs in production

## 🐛 Troubleshooting

See [TROUBLESHOOTING.md](TROUBLESHOOTING.md) for common issues and solutions.

## 📖 Learning Resources

- **Terraform Docs**: https://www.terraform.io/docs
- **AWS Provider**: https://registry.terraform.io/providers/hashicorp/aws/latest/docs
- **Terraform Best Practices**: https://www.terraform.io/cloud-docs/recommended-practices
- **AWS Well-Architected Framework**: https://wa.aws.amazon.com/

## 📄 License

This project is provided as-is for educational and infrastructure automation purposes.

## 🤝 Contributing

Feel free to enhance this project with:
- Multi-region support
- Load balancing
- Auto-scaling groups
- Database integration
- CDN configuration
- CI/CD pipeline integration

## 📞 Support

For issues or questions:
1. Check [TROUBLESHOOTING.md](TROUBLESHOOTING.md)
2. Review Terraform and AWS documentation
3. Check AWS CloudFormation/CloudTrail for deployment errors

---

**Last Updated**: March 2026
**Terraform Version**: >= 1.0
**AWS Provider Version**: >= 5.0
