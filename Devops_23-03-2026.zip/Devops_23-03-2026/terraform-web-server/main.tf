# VPC (Virtual Private Cloud)
resource "aws_vpc" "main" {
  cidr_block           = "10.0.0.0/16"
  enable_dns_hostnames = true
  enable_dns_support   = true

  tags = merge(
    local.common_tags,
    {
      Name = "${var.instance_name}-vpc"
    }
  )
}

# Internet Gateway
resource "aws_internet_gateway" "main" {
  vpc_id = aws_vpc.main.id

  tags = merge(
    local.common_tags,
    {
      Name = "${var.instance_name}-igw"
    }
  )
}

# Public Subnet
resource "aws_subnet" "public" {
  vpc_id                  = aws_vpc.main.id
  cidr_block              = "10.0.1.0/24"
  availability_zone       = data.aws_availability_zones.available.names[0]
  map_public_ip_on_launch = true

  tags = merge(
    local.common_tags,
    {
      Name = "${var.instance_name}-public-subnet"
    }
  )
}

# Route Table
resource "aws_route_table" "public" {
  vpc_id = aws_vpc.main.id

  route {
    cidr_block      = "0.0.0.0/0"
    gateway_id      = aws_internet_gateway.main.id
  }

  tags = merge(
    local.common_tags,
    {
      Name = "${var.instance_name}-public-rt"
    }
  )
}

# Route Table Association
resource "aws_route_table_association" "public" {
  subnet_id      = aws_subnet.public.id
  route_table_id = aws_route_table.public.id
}

# Security Group
resource "aws_security_group" "web_server" {
  name        = "${var.instance_name}-sg"
  description = "Security group for web server allowing HTTP and SSH"
  vpc_id      = aws_vpc.main.id

  # HTTP access
  ingress {
    from_port   = 80
    to_port     = 80
    protocol    = "tcp"
    cidr_blocks = var.allowed_http_cidr
    description = "Allow HTTP traffic"
  }

  # HTTPS access (optional, but good to have)
  ingress {
    from_port   = 443
    to_port     = 443
    protocol    = "tcp"
    cidr_blocks = var.allowed_http_cidr
    description = "Allow HTTPS traffic"
  }

  # SSH access
  ingress {
    from_port   = 22
    to_port     = 22
    protocol    = "tcp"
    cidr_blocks = var.allowed_ssh_cidr
    description = "Allow SSH access"
  }

  # Outbound traffic - Allow all
  egress {
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
    description = "Allow all outbound traffic"
  }

  tags = merge(
    local.common_tags,
    {
      Name = "${var.instance_name}-sg"
    }
  )

  lifecycle {
    create_before_destroy = true
  }
}

# Data source to get latest Amazon Linux 2 AMI
data "aws_ami" "amazon_linux_2" {
  most_recent = true
  owners      = ["amazon"]

  filter {
    name   = "name"
    values = ["amzn2-ami-hvm-*-x86_64-gp2"]
  }

  filter {
    name   = "virtualization-type"
    values = ["hvm"]
  }

  filter {
    name   = "root-device-type"
    values = ["ebs"]
  }
}

# Availability Zones data source
data "aws_availability_zones" "available" {
  state = "available"
}

# EC2 Instance
resource "aws_instance" "web_server" {
  ami                    = data.aws_ami.amazon_linux_2.id
  instance_type          = var.instance_type
  subnet_id              = aws_subnet.public.id
  vpc_security_group_ids = [aws_security_group.web_server.id]
  associate_public_ip_address = var.enable_public_ip
  monitoring             = var.enable_monitoring

  root_block_device {
    volume_type           = "gp3"
    volume_size           = var.root_volume_size
    delete_on_termination = true
    encrypted             = true

    tags = {
      Name = "${var.instance_name}-root-volume"
    }
  }

  # User data script to install and start a web server
  user_data = base64encode(<<-EOF
              #!/bin/bash
              set -e
              
              # Update system packages
              yum update -y
              
              # Install Apache web server
              yum install -y httpd
              
              # Start Apache service
              systemctl start httpd
              systemctl enable httpd
              
              # Create a simple health check page
              cat > /var/www/html/index.html <<'HTMLEOF'
              <!DOCTYPE html>
              <html>
              <head>
                <title>Web Server Infrastructure</title>
                <style>
                  body { font-family: Arial, sans-serif; margin: 40px; background-color: #f0f0f0; }
                  .container { background-color: white; padding: 40px; border-radius: 10px; box-shadow: 0 0 10px rgba(0,0,0,0.1); }
                  h1 { color: #333; }
                  .info { background-color: #e3f2fd; padding: 15px; border-radius: 5px; margin: 20px 0; }
                  .status { color: green; font-weight: bold; }
                </style>
              </head>
              <body>
                <div class="container">
                  <h1>🚀 Web Server Deployed Successfully!</h1>
                  <p>This web server was provisioned using Terraform Infrastructure as Code.</p>
                  <div class="info">
                    <h2>Server Information:</h2>
                    <p><strong>Instance Type:</strong> ${var.instance_type}</p>
                    <p><strong>Region:</strong> ${var.aws_region}</p>
                    <p><strong>Environment:</strong> ${var.environment}</p>
                    <p><strong>Status:</strong> <span class="status">✓ Running</span></p>
                  </div>
                  <p><small>Last updated: $(date)</small></p>
                </div>
              </body>
              </html>
              HTMLEOF
              
              # Create a health check endpoint
              cat > /var/www/html/health.html <<'HEALTHEOF'
              {
                "status": "healthy",
                "timestamp": "$(date -Iseconds)",
                "instance_type": "${var.instance_type}"
              }
              HEALTHEOF
              
              # Log completion
              echo "Web server setup completed at $(date)" >> /var/log/user-data.log
              EOF
  )

  tags = merge(
    local.common_tags,
    {
      Name = var.instance_name
    }
  )

  depends_on = [aws_internet_gateway.main]

  lifecycle {
    create_before_destroy = true
    ignore_changes       = [ami, user_data] # Ignore changes to keep infrastructure stable
  }
}

# Elastic IP for stable public IP
resource "aws_eip" "web_server" {
  count    = var.enable_public_ip ? 1 : 0
  instance = aws_instance.web_server.id
  domain   = "vpc"

  tags = merge(
    local.common_tags,
    {
      Name = "${var.instance_name}-eip"
    }
  )

  depends_on = [aws_internet_gateway.main]
}
