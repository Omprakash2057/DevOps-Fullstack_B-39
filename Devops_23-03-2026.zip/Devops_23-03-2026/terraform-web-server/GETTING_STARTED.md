# 🎯 Getting Started - First Time Setup

Complete this guide to deploy your web server infrastructure in under 10 minutes.

## ✅ Prerequisites Verification

Before you start, verify you have these installed:

```powershell
# Check Terraform
terraform --version
# Should show: Terraform v1.x.x

# Check AWS CLI
aws --version
# Should show: aws-cli/2.x.x

# Check credentials
aws sts get-caller-identity
# Should show your AWS account info
```

If any are missing, install them first:
- **Terraform**: https://www.terraform.io/downloads
- **AWS CLI**: https://aws.amazon.com/cli/

---

## 🔑 Step 1: Configure AWS Credentials (2 minutes)

### Option A: Using AWS CLI (Recommended)

```powershell
# Run configuration
aws configure

# Enter:
# AWS Access Key ID: [paste your access key]
# AWS Secret Access Key: [paste your secret key]
# Default region name: us-east-1
# Default output format: json

# Verify it worked
aws sts get-caller-identity
```

### Option B: Using Environment Variables

```powershell
$env:AWS_ACCESS_KEY_ID = "your-access-key-ID"
$env:AWS_SECRET_ACCESS_KEY = "your-secret-access-key"
$env:AWS_REGION = "us-east-1"

# Verify
aws sts get-caller-identity
```

**New to AWS?** Get credentials from: https://console.aws.amazon.com/iam → Users → Your User → Security Credentials

---

## 📁 Step 2: Navigate to Project (1 minute)

```powershell
# Open PowerShell and navigate to the project
cd "C:\Users\malle\OneDrive\Desktop\Devops2026\Devops_23-03-2026\terraform-web-server"

# Verify you're in the right place
Get-ChildItem | Select-Object Name

# Should show:
# .gitignore
# ADVANCED_EXAMPLES.md
# DEPLOYMENT_GUIDE.md
# main.tf
# outputs.tf
# PROJECT_SUMMARY.md
# provider.tf
# QUICK_REFERENCE.md
# README.md
# terraform.tfvars
# TROUBLESHOOTING.md
# variables.tf
```

---

## 🔧 Step 3: Customize Configuration (2 minutes)

Edit the configuration file to match your preferences:

```powershell
# Open configuration file
notepad terraform.tfvars
```

**Key settings to review/customize:**

```hcl
# Region where infrastructure will be deployed
aws_region = "us-east-1"

# Instance size (t3.micro is free tier eligible!)
instance_type = "t3.micro"

# Your environment name
environment = "development"

# Restrict SSH to YOUR IP (important!)
# Replace "0.0.0.0/0" with your IP address
allowed_ssh_cidr = ["0.0.0.0/0"]

# Find your IP:
# Visit https://checkip.amazonaws.com in a browser
# Or run: curl ifconfig.me
```

**For security**: Replace `allowed_ssh_cidr = ["0.0.0.0/0"]` with your IP:
```hcl
allowed_ssh_cidr = ["203.0.113.45/32"]  # Example - use YOUR IP/32
```

---

## 🚀 Step 4: Initialize Terraform (1 minute)

```powershell
# Initialize Terraform (downloads AWS provider)
terraform init

# You should see:
# - Provider plugins downloading
# - ".terraform" directory created
# - "Terraform has been successfully configured!"
```

---

## ✅ Step 5: Validate & Preview (2 minutes)

```powershell
# Validate configuration syntax
terraform validate
# Should show: "Success! The configuration is valid."

# Preview what will be created
terraform plan

# Read through the output carefully:
# - Shows 7 resources to be created
# - Verifies your AWS region and instance type
# - Confirms security group rules
```

---

## 🌐 Step 6: Deploy Infrastructure (3-5 minutes)

```powershell
# Deploy to AWS
terraform apply

# When prompted, review the resources one more time
# Type "yes" to confirm deployment

# You should see:
# - Resources being created
# - "Apply complete! Resources: 7 added"
```

---

## 📊 Step 7: Get Your Results (1 minute)

```powershell
# Display all deployment results
terraform output

# Copy the web_server_url - you'll use this!

# Or get just the URL:
terraform output -raw web_server_url
```

---

## 🌍 Step 8: Test Web Server (2 minutes)

### Option A: Open in Browser

```powershell
# Get the URL
$url = terraform output -raw web_server_url
Write-Host "Opening: $url"

# Open in browser
Start-Process $url

# You should see:
# "🚀 Web Server Deployed Successfully!"
# With instance information
```

### Option B: Test from PowerShell

```powershell
# Test with curl
curl $(terraform output -raw web_server_url)

# Should return HTML with "Web Server Deployed Successfully!"
```

---

## 🎉 Success! Your Infrastructure is Live

Congratulations! You now have:
- ✅ VPC network with security
- ✅ Public subnet for web traffic
- ✅ EC2 instance running Apache
- ✅ Security group with HTTP/SSH/HTTPS access
- ✅ Static Elastic IP address
- ✅ Encrypted storage
- ✅ CloudWatch monitoring

---

## 📋 Common Next Steps

### 1. Access via SSH (if needed)

```powershell
# First, ensure you have your SSH key file
# Then run the command from terraform output
$sshCmd = terraform output -raw ssh_command
Write-Host $sshCmd

# Adjust path to your key file and run
# ssh -i C:\path\to\your\key.pem ec2-user@<ip-address>
```

### 2. Modify Infrastructure

To make changes:

```powershell
# Edit configuration file
notepad terraform.tfvars

# Or edit Terraform files directly
notepad main.tf

# Preview changes
terraform plan

# Apply changes
terraform apply
```

### 3. Update Security Rules

To allow SSH from specific IP only:

```powershell
# Edit terraform.tfvars
# Change: allowed_ssh_cidr = ["0.0.0.0/0"]
# To:     allowed_ssh_cidr = ["YOUR_IP/32"]

terraform plan
terraform apply
```

### 4. Add More Features

See ADVANCED_EXAMPLES.md for:
- Load balancing across multiple instances
- Database integration
- HTTPS/SSL certificates
- Auto-scaling
- Advanced monitoring

---

## 🧹 When Done: Clean Up

To remove all infrastructure and stop paying (if applicable):

```powershell
# Preview what will be destroyed
terraform plan -destroy

# Delete all resources
terraform destroy

# When prompted, type "yes" to confirm

# You should see:
# "Destroy complete! Resources: 7 destroyed."
```

---

## 🆘 Troubleshooting

### Terraform Init Fails
```powershell
# Check internet connection
Test-NetConnection registry.terraform.io -Port 443

# Try again
terraform init
```

### Credentials Not Found
```powershell
# Configure AWS credentials
aws configure

# Verify
aws sts get-caller-identity
```

### Instance Not Accessible
- Check security group allows your IP
- Wait 2-3 minutes for instance to fully boot
- Check instance is in "running" state in AWS console

See **TROUBLESHOOTING.md** for detailed solutions.

---

## 📚 Documentation Files

| File | Use When |
|------|----------|
| **README.md** | Want complete project overview |
| **DEPLOYMENT_GUIDE.md** | Need detailed step-by-step instructions |
| **TROUBLESHOOTING.md** | Encounter errors or issues |
| **QUICK_REFERENCE.md** | Need command shortcuts |
| **PROJECT_SUMMARY.md** | Want architecture overview |
| **ADVANCED_EXAMPLES.md** | Want to add advanced features |

---

## ✨ What's Now Available

After deployment, you have access to:

```powershell
# Web server URL for HTTP access
terraform output web_server_url
# Example: http://54.123.45.67

# Instance information
terraform output instance_id              # i-0123456789abcdef0
terraform output instance_public_ip       # 54.123.45.67
terraform output instance_type            # t3.micro

# Network resources
terraform output vpc_id                   # vpc-0123456789abcdef0
terraform output security_group_id        # sg-0123456789abcdef0

# Administrative access
terraform output ssh_command              # ssh -i key.pem ec2-user@...

# Health check
terraform output health_check_url         # http://54.123.45.67/health.html
```

---

## 🎓 Key Concepts Learned

✅ **Infrastructure as Code (IaC)**: Define infrastructure in code files  
✅ **Terraform**: Automation tool for cloud infrastructure  
✅ **AWS VPC**: Virtual network for your resources  
✅ **Security Groups**: Firewall rules for access control  
✅ **EC2 Instances**: Virtual machines in the cloud  
✅ **State Management**: Terraform tracks what you deployed  
✅ **Idempotency**: Running same commands produces same result  

---

## 🔒 Security Reminders

1. **Secure your credentials**
   - Never commit AWS keys to Git
   - Use IAM users instead of root account

2. **Restrict SSH access**
   - Don't use `0.0.0.0/0` in production
   - Restrict to your IP address only

3. **Manage SSH keys**
   - Keep private key safe
   - Don't share with others
   - Rotate keys periodically

4. **Clean up unused resources**
   - Destroy infrastructure when not needed
   - Prevents unexpected AWS charges

---

## 💡 Pro Tips

**Tip 1**: Save plan files for review
```powershell
terraform plan -out=tfplan
terraform show tfplan   # Review before applying
terraform apply tfplan  # No confirmation needed
```

**Tip 2**: Use meaningful resource names
```hcl
instance_name = "my-web-app-prod"  # Better than "server"
```

**Tip 3**: Always backup state
```powershell
Copy-Item terraform.tfstate terraform.tfstate.backup
```

**Tip 4**: Version control your Terraform files
```powershell
git init
git add *.tf *.tfvars
git commit -m "Initial infrastructure"
```

---

## 🎯 Success Criteria

Your deployment is successful when:

- ✅ `terraform init` completes without errors
- ✅ `terraform validate` shows "Success!"
- ✅ `terraform apply` completes with "Resources: 7 added"
- ✅ Web server URL opens in browser
- ✅ Health check endpoint returns JSON
- ✅ Security group shows correct rules
- ✅ Instance is in "running" state

---

## 📞 Need More Help?

1. **Check the docs**: See all documentation files above
2. **Run terraform show**: View current infrastructure state
3. **Check AWS Console**: Verify resources in EC2 dashboard
4. **Review terraform state**: `terraform state list`

---

## 🚀 Ready to Deploy?

You have everything you need! Follow the **8 Steps** above to:
1. Verify prerequisites
2. Customize settings
3. Deploy infrastructure
4. Test web server

**Estimated time**: 10-15 minutes total

**Let's go!** 🎉 Run `terraform init` in PowerShell to start!

---

**Next**: Read [DEPLOYMENT_GUIDE.md](DEPLOYMENT_GUIDE.md) for detailed step-by-step instructions

**Questions?**: Check [TROUBLESHOOTING.md](TROUBLESHOOTING.md)

**Advanced features?**: See [ADVANCED_EXAMPLES.md](ADVANCED_EXAMPLES.md)

---

**Happy Infrastructure Coding!** 🚀
