# AWS Region for deployment
aws_region = "us-east-1"

# EC2 Instance Type (using t3.micro for free tier eligibility)
instance_type = "t3.micro"

# Environment identifier
environment = "development"

# EC2 Instance name
instance_name = "web-server"

# Enable public IP assignment
enable_public_ip = true

# CIDR blocks allowed for HTTP access (0.0.0.0/0 = open to internet)
# For production, restrict this to specific IPs/ranges
allowed_http_cidr = ["0.0.0.0/0"]

# CIDR blocks allowed for SSH access
# Replace with your actual IP for better security: ["YOUR_IP/32"]
allowed_ssh_cidr = ["0.0.0.0/0"]

# Root volume size in GB
root_volume_size = 20

# Enable detailed CloudWatch monitoring
enable_monitoring = true
