# Quick Reference Guide

Fast lookup for common Terraform commands and tasks.

## 🚀 Quick Start Commands

```bash
# Setup (first time)
terraform init
terraform validate
terraform plan

# Deploy
terraform apply

# View results
terraform output

# Cleanup (when done)
terraform destroy
```

## 📋 Essential Commands

| Command | Purpose |
|---------|---------|
| `terraform init` | Initialize working directory |
| `terraform validate` | Check configuration syntax |
| `terraform plan` | Preview changes |
| `terraform apply` | Apply changes (deploy) |
| `terraform destroy` | Delete all resources |
| `terraform refresh` | Update state from AWS |
| `terraform output` | View output values |

## 📊 State Management

```bash
# View all resources
terraform state list

# Show specific resource
terraform state show aws_instance.web_server

# Remove resource from state (dangerous!)
terraform state rm aws_instance.web_server

# Import existing resource
terraform import aws_instance.web_server i-0123456789abcdef0

# Backup state
cp terraform.tfstate terraform.tfstate.backup
```

## 🔍 Planning & Previewing

```bash
# Detailed plan
terraform plan

# Save plan
terraform plan -out=tfplan

# Show saved plan
terraform show tfplan

# Destroy plan
terraform plan -destroy
```

## 🎯 Applying Changes

```bash
# Standard apply
terraform apply

# Apply saved plan (no confirmation)
terraform apply tfplan

# Apply specific resource only
terraform apply -target=aws_instance.web_server

# Auto-approve (use with caution)
terraform apply -auto-approve

# Parallelism (speed up)
terraform apply -parallelism=10
```

## 📤 Getting Information

```bash
# All outputs
terraform output

# Specific output (raw value)
terraform output -raw web_server_url

# JSON format
terraform output -json

# Get value in PowerShell
$instanceId = terraform output -raw instance_id
```

## 🔐 Security Commands

```bash
# View security group rules
terraform state show aws_security_group.web_server

# View instance details
terraform state show aws_instance.web_server

# Show VPC configuration
terraform state show aws_vpc.main
```

## 🗂️ Useful PowerShell Scripts

### Get All Key Information

```powershell
# Store outputs
$outputs = terraform output -json | ConvertFrom-Json

# Web server URL
$webUrl = $outputs.web_server_url.value
Write-Host "Web Server: $webUrl"

# Instance ID
$instanceId = $outputs.instance_id.value
Write-Host "Instance ID: $instanceId"

# Public IP
$publicIp = $outputs.instance_public_ip.value
Write-Host "Public IP: $publicIp"

# SSH command
$sshCmd = $outputs.ssh_command.value
Write-Host "SSH: $sshCmd"
```

### Test Web Server

```powershell
# Get URL and test
$url = terraform output -raw web_server_url
curl $url

# Health check
curl "$(terraform output -raw health_check_url)"
```

### Destroy and Verify

```powershell
# Destroy with confirmation
terraform destroy

# Verify nothing left
terraform state list
# Should be empty

# AWS verification
aws ec2 describe-instances --query 'Reservations[0].Instances[0].State'
```

## 🔄 Common Workflows

### Update Security Group

```bash
# Edit main.tf (add new rule)
# Or edit terraform.tfvars

terraform plan
terraform apply
```

### Add New Instance

```bash
# Duplicate resource in main.tf (rename)
terraform plan
terraform apply
```

### Change Region

```bash
# Edit terraform.tfvars: aws_region = "eu-west-1"
terraform plan
terraform apply -parallelism=1
```

### Change Instance Type

```bash
# Edit terraform.tfvars: instance_type = "t3.small"
terraform plan
terraform apply
```

### Enable SSH from Your IP Only

```bash
# Edit terraform.tfvars:
allowed_ssh_cidr = ["YOUR_PUBLIC_IP/32"]

terraform plan
terraform apply
```

## 🐛 Debugging

```bash
# Verbose output
$env:TF_LOG = "DEBUG"
terraform plan

# Save debug logs
$env:TF_LOG = "DEBUG"
terraform apply > terraform.log 2>&1

# Graph visualization
terraform graph | dot -Tsvg > graph.svg

# Validate configuration
terraform validate

# Format code
terraform fmt -recursive

# Show resource dependencies
terraform graph | grep "\-\>"
```

## 🔓 AWS CLI Equivalents

```bash
# List instances
aws ec2 describe-instances --filter "Name=tag:Name,Values=web-server"

# Get instance public IP
aws ec2 describe-instances --query 'Reservations[*].Instances[*].PublicIpAddress' --filter "Name=tag:Name,Values=web-server"

# Get security group
aws ec2 describe-security-groups --filters "Name=group-name,Values=web-server-sg"

# Start instance
aws ec2 start-instances --instance-ids i-0123456789abcdef0

# Stop instance (without terminating)
aws ec2 stop-instances --instance-ids i-0123456789abcdef0

# Terminate instance
aws ec2 terminate-instances --instance-ids i-0123456789abcdef0
```

## 📊 Useful Outputs

```bash
# Web server URL (for browser)
terraform output -raw web_server_url

# Instance ID (for AWS console)
terraform output -raw instance_id

# SSH command (copy-paste ready)
terraform output -raw ssh_command

# All in JSON
terraform output -json
```

## ⚠️ Dangerous Commands

```bash
# Force unlock (only if stuck)
terraform force-unlock LOCK_ID

# Force destroy (no confirmation)
terraform destroy -auto-approve

# Remove resource from state (risky!)
terraform state rm aws_instance.web_server

# Replace running instance (destroys existing)
terraform apply -replace=aws_instance.web_server
```

## ✅ Pre-Deploy Checklist

```bash
terraform init        # ✓ Initialize
terraform validate    # ✓ Check syntax  
terraform plan        # ✓ Review changes
# REVIEW PLAN CAREFULLY
terraform apply       # ✓ Deploy
terraform output      # ✓ View results
```

## 📖 Help Commands

```bash
# General help
terraform help

# Specific command help
terraform apply --help
terraform plan --help
terraform state --help

# AWS provider documentation
# https://registry.terraform.io/providers/hashicorp/aws/latest/docs
```

## 🎯 Common Parameters

### terraform plan
- `-out=FILE`: Save plan to file
- `-refresh=false`: Skip refresh (faster)
- `-destroy`: Plan destruction
- `-json`: JSON output

### terraform apply
- `-auto-approve`: Skip confirmation
- `-parallelism=N`: Parallel operations (default 10)
- `-target=RESOURCE`: Apply single resource
- `-refresh-only`: Only update state

### terraform state
- `list`: Show resources
- `show RESOURCE`: Resource details
- `rm RESOURCE`: Remove resource
- `mv OLD NEW`: Rename resource

## 🌐 AWS Console Shortcuts

```
# EC2 Dashboard
https://console.aws.amazon.com/ec2

# VPC Dashboard
https://console.aws.amazon.com/vpc

# Security Groups
https://console.aws.amazon.com/ec2/#SecurityGroups

# Instances
https://console.aws.amazon.com/ec2/#Instances

# Elastic IPs
https://console.aws.amazon.com/ec2/#Addresses
```

## 💾 Backup Strategy

```bash
# Backup state before major changes
Copy-Item terraform.tfstate terraform.tfstate.$(Get-Date -Format "yyyy-MM-dd_HHmmss").backup

# Keep backups organized
New-Item -ItemType Directory -Name backups -Force
Copy-Item terraform.tfstate backups/

# Version control (add to Git)
git add terraform.tfstate.backup
git commit -m "State backup before major change"
```

---

**More Info**: See [README.md](README.md), [DEPLOYMENT_GUIDE.md](DEPLOYMENT_GUIDE.md), or [TROUBLESHOOTING.md](TROUBLESHOOTING.md)
