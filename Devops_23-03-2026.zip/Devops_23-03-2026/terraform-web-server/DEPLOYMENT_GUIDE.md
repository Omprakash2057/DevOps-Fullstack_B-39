# Terraform Deployment Guide

Complete step-by-step guide to deploy the web server infrastructure using Terraform.

## 📋 Prerequisites Checklist

Before starting, ensure you have:

- [ ] AWS Account created and active
- [ ] Billing enabled on AWS Account
- [ ] AWS Access Key ID and Secret Access Key
- [ ] Terraform installed (version 1.0+)
- [ ] AWS CLI installed and configured
- [ ] SSH key pair created in target AWS region
- [ ] Text editor or IDE for editing configuration files

## 🔑 Step 1: AWS Credentials Setup

### Option 1: Configure AWS CLI

```powershell
# Open PowerShell and run
aws configure

# Enter when prompted:
# AWS Access Key ID: [your-access-key]
# AWS Secret Access Key: [your-secret-key]
# Default region name: [us-east-1]
# Default output format: [json]
```

### Option 2: Use Environment Variables (Windows PowerShell)

```powershell
# Set AWS credentials as environment variables
$env:AWS_ACCESS_KEY_ID = "AKIAIOSFODNN7EXAMPLE"
$env:AWS_SECRET_ACCESS_KEY = "wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY"
$env:AWS_REGION = "us-east-1"

# Verify credentials
aws sts get-caller-identity
```

### Option 3: Create AWS Profile

```powershell
# Create a named profile
aws configure --profile terraform-profile

# Use profile in Terraform
$env:AWS_PROFILE = "terraform-profile"
```

**Verify Your Credentials:**

```powershell
aws sts get-caller-identity

# Should return your account info:
# {
#     "UserId": "AIDAI...",
#     "Account": "123456789012",
#     "Arn": "arn:aws:iam::123456789012:user/your-user"
# }
```

## 🔨 Step 2: Install Terraform

### Windows with Chocolatey

```powershell
# Install Terraform using Chocolatey
choco install terraform

# Verify installation
terraform --version
```

### Windows Manual Installation

1. Download from: https://www.terraform.io/downloads
2. Extract to a directory (e.g., `C:\terraform`)
3. Add to PATH:
   ```powershell
   $env:PATH += ";C:\terraform"
   terraform --version
   ```

### Windows Subsystem for Linux (WSL)

```bash
# Inside WSL Ubuntu terminal
curl https://apt.releases.hashicorp.com/gpg | sudo apt-key add -
sudo apt-add-repository "deb [arch=amd64] https://apt.releases.hashicorp.com $(lsb_release -cs) main"
sudo apt-get update && sudo apt-get install terraform
terraform --version
```

## 📁 Step 3: Prepare Project Directory

```powershell
# Navigate to project directory
cd "C:\Users\YourUser\OneDrive\Desktop\Devops2026\Devops_23-03-2026\terraform-web-server"

# Verify structure
Get-ChildItem -Recurse

# Should show:
# .gitignore
# main.tf
# outputs.tf
# provider.tf
# terraform.tfvars
# variables.tf
# README.md
# DEPLOYMENT_GUIDE.md
# TROUBLESHOOTING.md
```

## 🔌 Step 4: Initialize Terraform

```powershell
# Initialize Terraform working directory
terraform init

# Output should show:
# Initializing the backend...
# Initializing provider plugins...
# Terraform has been successfully configured!
```

**What this does:**
- Downloads AWS provider plugin
- Creates `.terraform` directory
- Initializes state management

## ✅ Step 5: Validate Configuration

```powershell
# Validate Terraform configuration
terraform validate

# Should return:
# Success! The configuration is valid.
```

## 🔍 Step 6: Review and Customize Variables

### Edit terraform.tfvars

```powershell
# Open in text editor
notepad terraform.tfvars
```

**Key Variables to Review:**

```hcl
# AWS Region (choose nearest to you)
aws_region = "us-east-1"  # Options: us-west-1, eu-west-1, ap-southeast-1, etc.

# Instance Type (free tier eligible)
instance_type = "t3.micro"  # Free for first 12 months

# Instance Name (for identification)
instance_name = "web-server"

# Security - IMPORTANT: Restrict SSH access
allowed_ssh_cidr = ["YOUR_IP/32"]  # Replace with your IP

# For home/office testing, use:
allowed_ssh_cidr = ["203.0.113.45/32"]  # Example IP
```

**How to find your IP:**

```powershell
# Find your public IP
curl ifconfig.me
# Or visit: https://checkip.amazonaws.com
```

## 📊 Step 7: Plan Deployment

```powershell
# Review what will be created
terraform plan

# Save plan to file (recommended)
terraform plan -out=tfplan

# Output shows:
# - 7 resources to add
# - Security groups, VPC, EC2, etc.
```

**Important**: Review the plan carefully. Look for:
- Correct region and instance type
- Security group rules (HTTP port 80, SSH port 22)
- Number of resources

## 🚀 Step 8: Apply Configuration

### Option 1: Direct Apply (Not Recommended)

```powershell
# Apply immediately
terraform apply

# When prompted, review and type:
# yes
```

### Option 2: Apply Saved Plan (Recommended)

```powershell
# Apply the saved plan
terraform apply tfplan

# No confirmation needed - directly applies
```

**What happens during apply:**
1. VPC is created
2. Subnet and Internet Gateway configured
3. Security Group rules applied
4. EC2 instance launched
5. Web server installed via user data script
6. Elastic IP assigned
7. Resources tagged

**Typical duration**: 2-4 minutes

## ✨ Step 9: Retrieve Outputs

### Get All Outputs

```powershell
# Display all output values
terraform output

# Output shows:
# deployment_summary = {
#   "environment" = "development"
#   "instance_id" = "i-0123456789abcdef0"
#   "instance_type" = "t3.micro"
#   "region" = "us-east-1"
#   "web_server_url" = "http://54.123.45.67"
# }
```

### Get Specific Outputs

```powershell
# Web server URL
$webUrl = terraform output -raw web_server_url
Write-Host "Web Server URL: $webUrl"

# SSH command
$sshCmd = terraform output -raw ssh_command
Write-Host $sshCmd

# Instance ID
$instanceId = terraform output -raw instance_id
Write-Host "Instance ID: $instanceId"

# Public IP
$publicIp = terraform output -raw instance_public_ip
Write-Host "Public IP: $publicIp"
```

## 🌐 Step 10: Verify Web Server

### 1. Open in Browser

```powershell
# Option 1: Open URL directly
$webUrl = terraform output -raw web_server_url
Start-Process $webUrl

# Option 2: Copy URL to browser manually
terraform output web_server_url
# Then paste in browser address bar
```

**Expected Result:**
- Page loads successfully
- Shows "Web Server Deployed Successfully!" message
- Displays instance information

### 2. Test with curl

```powershell
# Test from PowerShell
$webUrl = terraform output -raw web_server_url
curl $webUrl

# Or get specific page
curl "$(terraform output -raw web_server_url)/health.html"
```

### 3. Check Health Endpoint

```powershell
# Get health status
$healthUrl = terraform output -raw health_check_url
curl $healthUrl | ConvertFrom-Json | Format-Table
```

## 🔐 Step 11: SSH Access (Optional)

### Prerequisites
- SSH key pair from AWS console
- SSH private key file locally

### Connect to Instance

```powershell
# Get SSH command
$sshCmd = terraform output -raw ssh_command
Write-Host $sshCmd

# Example: ssh -i C:\keys\my-key.pem ec2-user@54.123.45.67
```

### Test SSH

```powershell
# List files
ssh -i C:\keys\my-key.pem ec2-user@54.123.45.67 "ls -la"

# Check web server status
ssh -i C:\keys\my-key.pem ec2-user@54.123.45.67 "sudo systemctl status httpd"

# View logs
ssh -i C:\keys\my-key.pem ec2-user@54.123.45.67 "tail /var/log/user-data.log"
```

## 🔄 Step 12: Update Infrastructure

### Modify Configuration

1. Edit `terraform.tfvars` or `.tf` files
2. Save changes
3. Run plan to review changes
4. Apply if satisfied

**Example: Add HTTPS Support**

```hcl
# In main.tf, add to security group:
ingress {
  from_port   = 443
  to_port     = 443
  protocol    = "tcp"
  cidr_blocks = var.allowed_http_cidr
  description = "Allow HTTPS traffic"
}
```

Then apply:

```powershell
terraform plan
terraform apply
```

### Update Security Group Rules

```powershell
# Example: Change allowed SSH CIDR
# In terraform.tfvars:
allowed_ssh_cidr = ["203.0.113.45/32"]  # Your specific IP

# Apply changes:
terraform plan
terraform apply
```

## 📊 Step 13: Monitor Infrastructure

### View Current State

```powershell
# Show all managed resources
terraform state list

# Show specific resource details
terraform state show aws_instance.web_server

# Show security group rules
terraform state show aws_security_group.web_server
```

### AWS Console Access

1. Go to: https://console.aws.amazon.com
2. Navigate to EC2 Dashboard
3. Find instance with name "web-server"
4. View:
   - Instance details
   - Security groups
   - Network configuration
   - Monitoring metrics

## 🧹 Step 14: Clean Up (Destroy)

### Preview Destruction

```powershell
# Show what will be destroyed
terraform plan -destroy

# Save destruction plan
terraform plan -destroy -out=tfplan-destroy
```

### Destroy All Resources

```powershell
# Destroy resources
terraform destroy

# When prompted, type:
# yes

# Or destroy saved plan:
terraform destroy tfplan-destroy
```

**Warning**: This will:
- Terminate EC2 instance
- Delete VPC and subnets
- Remove security groups
- Release Elastic IP
- Delete all associated resources

**Verify Destruction:**

```powershell
# Check state shows no resources
terraform state list
# Should be empty

# Check terraform.tfstate file
Get-Content terraform.tfstate | ConvertFrom-Json | Select-Object -ExpandProperty resources
```

## 📋 Troubleshooting Common Issues

### Terraform Init Fails

```powershell
# Ensure you're in correct directory
Get-Location

# Check internet connection
Test-NetConnection -ComputerName registry.terraform.io -Port 443

# Try again with verbose output
terraform init -no-color 2>&1 | Tee-Object init.log
```

### Plan Shows Unexpected Changes

```powershell
# Refresh state from AWS
terraform refresh

# View differences
terraform plan
```

### Instance Not Accessible

See [TROUBLESHOOTING.md](TROUBLESHOOTING.md) for detailed solutions.

### Need to Revert to Previous State

```powershell
# Revert recent apply (if state backup exists)
# Restore terraform.tfstate from backup
# Then run:
terraform apply
```

## ✅ Deployment Summary Checklist

- [ ] AWS credentials configured
- [ ] Terraform installed
- [ ] Project directory created
- [ ] `terraform init` completed successfully
- [ ] `terraform validate` passed
- [ ] Variables customized in `terraform.tfvars`
- [ ] `terraform plan` reviewed
- [ ] `terraform apply` executed
- [ ] Web server URL obtained and tested
- [ ] Browser confirms web server running
- [ ] SSH access tested (if needed)
- [ ] Outputs documented
- [ ] Infrastructure changes version controlled

## 🎓 Next Steps

1. **Add Monitoring**: Configure CloudWatch alarms
2. **Enable Logging**: Set up S3 bucket for access logs
3. **Implement Auto-Scaling**: Add ASG for multiple instances
4. **Add Database**: Integrate RDS for data persistence
5. **Setup CI/CD**: Automate Terraform deployments
6. **Remote State**: Move to S3 backend for team collaboration

---

**Need Help?** See [TROUBLESHOOTING.md](TROUBLESHOOTING.md) or review the [README.md](README.md).
