# Troubleshooting Guide

Common issues and their solutions when working with this Terraform infrastructure.

## 🔴 Critical Issues

### 1. Terraform Init Fails

**Error Messages:**
```
Error: Failed to download provider resources
Error: registry.terraform.io: tls: failed to verify certificate
```

**Solutions:**

```powershell
# Check internet connectivity
Test-NetConnection -ComputerName registry.terraform.io -Port 443

# Clear Terraform cache
Remove-Item -Recurse -Force .terraform
Remove-Item .terraform.lock.hcl

# Retry init with verbose output
terraform init -no-color 2>&1 | Out-File init.log

# Try with offline mode (if Terraform already cached)
terraform init -offline

# Check if behind corporate proxy
# Configure proxy environment:
$env:HTTPS_PROXY = "http://proxy.company.com:8080"
terraform init
```

### 2. AWS Credentials Not Found

**Error Messages:**
```
Error: Unable to locate AWS credentials
Error: no valid credential sources found
```

**Solutions:**

```powershell
# Verify credentials are configured
aws sts get-caller-identity

# If not configured, run:
aws configure

# Or set environment variables:
$env:AWS_ACCESS_KEY_ID = "YOUR_ACCESS_KEY"
$env:AWS_SECRET_ACCESS_KEY = "YOUR_SECRET_KEY"
$env:AWS_REGION = "us-east-1"

# Verify environment variables are set
Get-ChildItem Env:AWS_*

# Check AWS credentials file exists
Test-Path "$env:USERPROFILE\.aws\credentials"
Test-Path "$env:USERPROFILE\.aws\config"

# Validate credentials
aws sts get-caller-identity --profile terraform-profile
```

### 3. Invalid AWS Region Error

**Error Messages:**
```
Error: Invalid or unsupported AWS region: "xx-xx-1"
```

**Solutions:**

```hcl
# Valid AWS regions (update terraform.tfvars):
# US:    us-east-1, us-east-2, us-west-1, us-west-2
# EU:    eu-west-1, eu-central-1, eu-north-1
# ASIA:  ap-northeast-1, ap-southeast-1, ap-southeast-2
# OTHER: ca-central-1, sa-east-1

# Verify region spelling in terraform.tfvars:
aws_region = "us-east-1"  # Correct
aws_region = "us-eat-1"   # Wrong!

# List available regions:
aws ec2 describe-regions --query 'Regions[*].[RegionName]' --output text
```

### 4. Permission Denied Error

**Error Messages:**
```
Error: AccessDenied: User is not authorized to perform: ec2:RunInstances
```

**Solutions:**

```powershell
# Verify IAM permissions
$identity = aws sts get-caller-identity | ConvertFrom-Json
$identity

# Check if using correct AWS account
# Add IAM policy for Terraform. Required permissions:

# EC2: ec2:*
# VPC: ec2:*
# SecurityGroup: ec2:*
# IAM: iam:GetUser (for validation)

# Add these permissions to your IAM user:
# - AmazonEC2FullAccess
# - AmazonVPCFullAccess

# Or use policy JSON:
# {
#   "Version": "2012-10-17",
#   "Statement": [{
#     "Effect": "Allow",
#     "Action": ["ec2:*", "vpc:*"],
#     "Resource": "*"
#   }]
# }
```

## ⚠️ Deployment Issues

### 5. Terraform Plan Shows Unexpected Resources

**Problem:**
```
Terraform will perform the following actions:
  # aws_instance.web_server will be destroyed
  + create
  - destroy
  ~ update in-place
```

**Solutions:**

```powershell
# Refresh state from AWS
terraform refresh

# Plan again
terraform plan

# Show current state
terraform state list
terraform state show aws_instance.web_server

# Force re-import if state is corrupted
# (Caution: may cause resource recreation)
terraform state rm aws_instance.web_server
terraform import aws_instance.web_server i-0123456789abcdef0
```

### 6. Instance Not Launching (Status Terminated)

**Error Messages:**
```
Instance State: terminated
Status Checks: Not running
```

**Solutions:**

```powershell
# Check AWS console in EC2 dashboard
# Note the instance ID and check termination reason:
aws ec2 describe-instances --query 'Reservations[*].Instances[*].[InstanceId,State.Name,StateTransitionReason]' --output table

# Common causes:
# 1. User data script failed
# 2. Insufficient capacity in AZ
# 3. Spot instance limitations

# Check user data logs:
bash
ssh -i /path/to/key.pem ec2-user@<public-ip>
sudo tail -f /var/log/user-data.log
exit
```

**Fixes:**

```powershell
# Try different availability zone
# Edit main.tf:
# availability_zone = data.aws_availability_zones.available.names[1]

terraform plan
terraform apply

# Try different instance type
# Edit terraform.tfvars:
instance_type = "t3.small"

terraform plan
terraform apply
```

### 7. Cannot Connect to Instance (Timeout)

**Error Messages:**
```
Connection timed out
Host unreachable
SSH: Connection refused
```

**Solutions:**

```powershell
# Check security group rules
aws ec2 describe-security-groups --query 'SecurityGroups[*].IpPermissions[]'

# Verify inbound rules allow your IP:
# Port 80 (HTTP): 0.0.0.0/0 ✓
# Port 22 (SSH): YOUR_IP/32 ✓
# Port 443 (HTTPS): 0.0.0.0/0 (optional)

# Check instance is running
aws ec2 describe-instances --query 'Reservations[*].Instances[*].[InstanceId,State.Name,PublicIpAddress]'

# Check status checks
aws ec2 describe-instance-status --query 'InstanceStatuses[*].[InstanceId,InstanceStatus.Status,SystemStatus.Status]'

# Wait for instance to fully initialize (2-3 minutes)
Start-Sleep -Seconds 120

# Test connectivity
Test-NetConnection -ComputerName <public-ip> -Port 22
Test-NetConnection -ComputerName <public-ip> -Port 80

# Check with curl if firewall blocks SSH
curl http://<public-ip>

# If curl works but SSH doesn't:
# 1. Verify SSH key permissions (600)
# 2. Check key pair in AWS console
# 3. Ensure using correct username (ec2-user for Amazon Linux)
```

### 8. Web Page Not Loading

**Symptoms:**
```
Connection refused
ERR_CONNECTION_REFUSED
Cannot GET /
```

**Solutions:**

```powershell
# Check instance is running
terraform output instance_state

# Check security group allows HTTP
terraform state show aws_security_group.web_server

# Access EC2 instance and check web server
ssh -i /path/to/key.pem ec2-user@<public-ip> "sudo systemctl status httpd"

# Check if Apache is running
ssh -i /path/to/key.pem ec2-user@<public-ip> "sudo systemctl start httpd"

# Check web server logs
ssh -i /path/to/key.pem ec2-user@<public-ip> "sudo tail -50 /var/log/httpd/access_log"
ssh -i /path/to/key.pem ec2-user@<public-ip> "sudo tail -50 /var/log/httpd/error_log"

# Check if port 80 is listening
ssh -i /path/to/key.pem ec2-user@<public-ip> "sudo netstat -tlnp | grep :80"

# Test from inside instance
ssh -i /path/to/key.pem ec2-user@<public-ip> "curl http://localhost"

# Rebuild security group (nuclear option)
terraform destroy -target aws_security_group.web_server
terraform apply
```

## 🔐 Security Issues

### 9. SSH Key Problems

**Error Messages:**
```
Permission denied (publickey)
Unprotected private key file
Too open permissions on private key file
```

**Solutions:**

```powershell
# Fix key permissions (Windows)
# Right-click key file → Properties → Security → Advanced
# Remove all users except yourself
# Set permissions to: Read & Execute for owner only

# Fix permissions via PowerShell:
icacls "C:\path\to\key.pem" /inheritance:r
icacls "C:\path\to\key.pem" /grant:r "$env:USERNAME`:(F)"

# Verify key file exists
Test-Path "C:\path\to\key.pem"

# Check key format
Get-Content "C:\path\to\key.pem" | Select-Object -First 1
# Should show: -----BEGIN RSA PRIVATE KEY-----

# Regenerate key pair if lost
# 1. In AWS EC2 console:
#    - Select instance
#    - Create Image (AMI)
#    - Launch new instance from AMI
#    - Create new key pair during launch

# Test SSH with verbose output:
ssh -vvv -i C:\path\to\key.pem ec2-user@<public-ip>
```

### 10. Security Group Rules Not Applied

**Problem:**
```
Changed security group rules but traffic still blocked
```

**Solutions:**

```powershell
# Verify rule was added
terraform output security_group_id
aws ec2 describe-security-groups --group-ids <group-id> --query 'SecurityGroups[0].IpPermissions'

# Refresh from AWS
terraform refresh

# Force update
terraform plan -refresh=true
terraform apply -refresh-only
terraform apply

# Re-apply security group rules (if needed)
terraform destroy -target aws_security_group.web_server
terraform apply

# Wait for propagation (30-60 seconds)
Start-Sleep -Seconds 60
```

## 🗄️ State Management Issues

### 11. Terraform State Corrupted

**Error Messages:**
```
Error: Inconsistent JSON format
Error: Unable to parse state file
```

**Solutions:**

```powershell
# Backup current state
Copy-Item terraform.tfstate terraform.tfstate.backup

# Show state
terraform state list

# Check specific resource
terraform state show aws_instance.web_server

# If state is severely corrupted, rebuild from scratch:
Remove-Item terraform.tfstate
Remove-Item terraform.tfstate.backup
terraform init
terraform plan
# Review carefully
terraform apply
```

### 12. State Locking Issues

**Error Messages:**
```
Error: resource already exists in state
Error: Error acquiring the lock: AccessDenied
```

**Solutions:**

```powershell
# Check if lock exists
Test-Path ".terraform/.terraform.lock.hcl"

# Remove lock (if safe)
Remove-Item ".terraform/.terraform.lock.hcl" -Force

# Force unlock (if using remote state):
terraform force-unlock <LOCK_ID>

# Clear local locks and reinit
Remove-Item -Recurse -Force .terraform
terraform init
```

## 🎯 Performance Issues

### 13. Terraform Commands Run Slowly

**Solutions:**

```powershell
# Disable refresh (faster but less accurate):
terraform plan -refresh=false

# Parallelize operations (up to 10):
terraform apply -parallelism=10

# Use saved plan (skip planning):
terraform plan -out=tfplan
terraform apply tfplan

# Check system resources
Get-Process terraform

# Increase verbosity to debug
$env:TF_LOG = "DEBUG"
terraform plan > terraform-debug.log 2>&1
```

### 14. AWS API Rate Limiting

**Error Messages:**
```
RequestLimitExceeded
Rate exceeded
ThrottlingException
```

**Solutions:**

```powershell
# Retry with exponential backoff
terraform apply -parallelism=1

# Add delays in user_data
# (Already included in our configuration)

# Wait between operations
Start-Sleep -Seconds 30
terraform apply
```

## 📊 Monitoring and Validation

### 15. CloudWatch Monitoring Not Working

**Problem:**
```
No metrics visible in CloudWatch
```

**Solutions:**

```hcl
# Ensure monitoring enabled in terraform.tfvars:
enable_monitoring = true

# Check instance has IAM role for CloudWatch
# May require additional IAM setup

# Verify in AWS console:
# 1. EC2 Dashboard → Instances
# 2. Select instance → Monitoring tab
# 3. Should show CPU, Network metrics
```

## 🆘 Getting Help

### Debug Information to Collect

When seeking help, provide:

```powershell
# Terraform version
terraform --version

# AWS account info (safe to share)
aws sts get-caller-identity

# Terraform plan output
terraform plan > plan.txt
Get-Content plan.txt

# Error logs
$env:TF_LOG = "DEBUG"
terraform apply 2>&1 | Tee-Object terraform.log

# Resource state
terraform state show <resource-name>

# AWS CLI info
aws ec2 describe-instances --query 'Reservations[*].Instances[*].{ID:InstanceId,State:State.Name,IP:PublicIpAddress,Type:InstanceType}'
```

### Useful Commands for Debugging

```powershell
# View all resources created
terraform state list

# Show detailed resource info
terraform state show aws_instance.web_server

# Plan with detailed output
terraform plan -out=plan.tfplan
terraform show plan.tfplan

# Destroy and recreate specific resource
terraform destroy -target=aws_instance.web_server
terraform apply -target=aws_instance.web_server

# Show resource graph
terraform graph | dot -Tsvg > graph.svg

# Validate syntax
terraform validate

# Format code
terraform fmt -recursive

# Check for potential issues
terraform plan -json | ConvertFrom-Json
```

### Resources

- **Terraform Docs**: https://www.terraform.io/docs
- **AWS Provider Docs**: https://registry.terraform.io/providers/hashicorp/aws/latest/docs
- **Terraform Community**: https://discuss.hashicorp.com/c/terraform
- **AWS Support**: https://console.aws.amazon.com/support

## ✅ Pre-Deployment Checklist

Before deploying, verify:

- [ ] AWS credentials working (`aws sts get-caller-identity`)
- [ ] Terraform installed (`terraform --version`)
- [ ] Project directory correct (`pwd`)
- [ ] `terraform validate` passes
- [ ] `terraform plan` reviewed
- [ ] terraform.tfvars customized (especially `allowed_ssh_cidr`)
- [ ] AWS region correct
- [ ] Instance type available in region
- [ ] Budget and cost implications understood
- [ ] VPC doesn't conflict with existing infrastructure
- [ ] Security groups reviewed

---

**Still stuck?** See [README.md](README.md) or [DEPLOYMENT_GUIDE.md](DEPLOYMENT_GUIDE.md).

**Report Issues:** Provide debug logs and AWS CLI output for better support.

**Last Updated**: March 2026
