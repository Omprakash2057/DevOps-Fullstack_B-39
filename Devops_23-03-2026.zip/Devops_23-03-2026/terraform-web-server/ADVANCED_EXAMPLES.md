# Advanced Examples & Extensions

Extend your Terraform infrastructure with these advanced configurations.

## 🔄 Multi-Instance Setup

Create multiple web servers with a load balancer.

### Create `multi-instances.tf`

```hcl
# Create multiple instances
resource "aws_instance" "web_servers" {
  count                       = 3
  ami                         = data.aws_ami.amazon_linux_2.id
  instance_type              = var.instance_type
  subnet_id                  = aws_subnet.public[count.index % length(aws_subnet.public)].id
  vpc_security_group_ids     = [aws_security_group.web_server.id]
  associate_public_ip_address = true

  user_data = base64encode(<<-EOF
    #!/bin/bash
    yum update -y
    yum install -y httpd
    systemctl start httpd
    systemctl enable httpd
    
    # Add instance ID to page
    INSTANCE_ID=$(ec2-metadata --instance-id | cut -d " " -f 2)
    echo "<h1>Instance: $INSTANCE_ID</h1>" > /var/www/html/instance.html
  EOF
  )

  tags = {
    Name = "web-server-${count.index + 1}"
  }
}

# Application Load Balancer
resource "aws_lb" "web" {
  name               = "web-server-alb"
  internal           = false
  load_balancer_type = "application"
  security_groups    = [aws_security_group.alb.id]
  subnets            = aws_subnet.public[*].id

  tags = {
    Name = "web-server-alb"
  }
}

# Target Group
resource "aws_lb_target_group" "web" {
  name        = "web-server-tg"
  port        = 80
  protocol    = "HTTP"
  vpc_id      = aws_vpc.main.id
  
  health_check {
    healthy_threshold   = 2
    unhealthy_threshold = 2
    timeout             = 3
    interval            = 30
    path                = "/"
    matcher             = "200"
  }
}

# Register targets
resource "aws_lb_target_group_attachment" "web" {
  count            = 3
  target_group_arn = aws_lb_target_group.web.arn
  target_id        = aws_instance.web_servers[count.index].id
  port             = 80
}

# Load Balancer Listener
resource "aws_lb_listener" "web" {
  load_balancer_arn = aws_lb.web.arn
  port              = "80"
  protocol          = "HTTP"

  default_action {
    type             = "forward"
    target_group_arn = aws_lb_target_group.web.arn
  }
}

# Security group for ALB
resource "aws_security_group" "alb" {
  name   = "web-server-alb-sg"
  vpc_id = aws_vpc.main.id

  ingress {
    from_port   = 80
    to_port     = 80
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }

  egress {
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }
}
```

### Usage

```bash
terraform plan
terraform apply

# Get load balancer DNS
terraform output alb_dns_name
```

## 🗄️ Database Integration

Add RDS database to store data.

### Create `database.tf`

```hcl
# DB Subnet Group
resource "aws_db_subnet_group" "main" {
  name       = "web-server-db-subnet"
  subnet_ids = aws_subnet.private[*].id

  tags = {
    Name = "web-server-db-subnet"
  }
}

# RDS Security Group
resource "aws_security_group" "rds" {
  name   = "web-server-rds-sg"
  vpc_id = aws_vpc.main.id

  ingress {
    from_port       = 3306
    to_port         = 3306
    protocol        = "tcp"
    security_groups = [aws_security_group.web_server.id]
  }

  egress {
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }
}

# RDS Instance
resource "aws_db_instance" "main" {
  identifier     = "web-server-db"
  engine         = "mysql"
  engine_version = "8.0"
  instance_class = "db.t3.micro"
  
  allocated_storage = 20
  storage_type      = "gp2"
  storage_encrypted = true

  db_name  = "webserverdb"
  username = "admin"
  password = random_password.db_password.result

  db_subnet_group_name   = aws_db_subnet_group.main.name
  vpc_security_group_ids = [aws_security_group.rds.id]

  publicly_accessible    = false
  multi_az              = false
  backup_retention_period = 7
  
  skip_final_snapshot = true

  tags = {
    Name = "web-server-db"
  }
}

# Generate random DB password
resource "random_password" "db_password" {
  length  = 16
  special = true
}
```

### Add to outputs

```hcl
output "rds_endpoint" {
  value = aws_db_instance.main.endpoint
}

output "database_password" {
  value     = random_password.db_password.result
  sensitive = true
}
```

## 🔐 SSL/HTTPS Configuration

Add HTTPS support with ACM certificate.

### Create `https.tf`

```hcl
# Request certificate from ACM
resource "aws_acm_certificate" "web" {
  domain_name       = var.domain_name
  validation_method = "DNS"

  lifecycle {
    create_before_destroy = true
  }

  tags = {
    Name = "web-server-cert"
  }
}

# Update ALB listener for HTTPS
resource "aws_lb_listener" "https" {
  load_balancer_arn = aws_lb.web.arn
  port              = "443"
  protocol          = "HTTPS"
  ssl_policy        = "ELBSecurityPolicy-TLS-1-2-2017-01"
  certificate_arn   = aws_acm_certificate.web.arn

  default_action {
    type             = "forward"
    target_group_arn = aws_lb_target_group.web.arn
  }
}

# Redirect HTTP to HTTPS
resource "aws_lb_listener" "http_redirect" {
  load_balancer_arn = aws_lb.web.arn
  port              = "80"
  protocol          = "HTTP"

  default_action {
    type = "redirect"
    redirect {
      port        = "443"
      protocol    = "HTTPS"
      status_code = "HTTP_301"
    }
  }
}
```

### Add variables

```hcl
variable "domain_name" {
  description = "Domain name for SSL certificate"
  type        = string
  default     = "example.com"
}
```

## 📈 Auto Scaling Group

Automatically scale instances based on demand.

### Create `autoscaling.tf`

```hcl
# Launch Template
resource "aws_launch_template" "web" {
  name_prefix   = "web-server-"
  image_id      = data.aws_ami.amazon_linux_2.id
  instance_type = var.instance_type

  user_data = base64encode(<<-EOF
    #!/bin/bash
    yum update -y
    yum install -y httpd
    systemctl start httpd
    systemctl enable httpd
  EOF
  )

  security_groups = [aws_security_group.web_server.id]

  lifecycle {
    create_before_destroy = true
  }
}

# Auto Scaling Group
resource "aws_autoscaling_group" "web" {
  name                = "web-server-asg"
  vpc_zone_identifier = aws_subnet.public[*].id
  target_group_arns   = [aws_lb_target_group.web.arn]

  min_size         = 2
  max_size         = 6
  desired_capacity = 2

  launch_template {
    id      = aws_launch_template.web.id
    version = "$Latest"
  }

  health_check_type         = "ELB"
  health_check_grace_period = 300

  tag {
    key                 = "Name"
    value               = "web-server-asg"
    propagate_launch_template = true
  }
}

# CPU Scaling Policy
resource "aws_autoscaling_policy" "scale_up" {
  name                   = "web-server-scale-up"
  scaling_adjustment      = 1
  adjustment_type        = "ChangeInCapacity"
  autoscaling_group_name = aws_autoscaling_group.web.name
  cooldown               = 300
}

resource "aws_autoscaling_policy" "scale_down" {
  name                   = "web-server-scale-down"
  scaling_adjustment      = -1
  adjustment_type        = "ChangeInCapacity"
  autoscaling_group_name = aws_autoscaling_group.web.name
  cooldown               = 300
}

# CloudWatch Alarms
resource "aws_cloudwatch_metric_alarm" "cpu_high" {
  alarm_name          = "web-server-cpu-high"
  comparison_operator = "GreaterThanThreshold"
  evaluation_periods  = "2"
  metric_name         = "CPUUtilization"
  namespace           = "AWS/EC2"
  period              = "120"
  statistic           = "Average"
  threshold           = "70"

  alarm_actions = [aws_autoscaling_policy.scale_up.arn]

  dimensions = {
    AutoScalingGroupName = aws_autoscaling_group.web.name
  }
}

resource "aws_cloudwatch_metric_alarm" "cpu_low" {
  alarm_name          = "web-server-cpu-low"
  comparison_operator = "LessThanThreshold"
  evaluation_periods  = "2"
  metric_name         = "CPUUtilization"
  namespace           = "AWS/EC2"
  period              = "120"
  statistic           = "Average"
  threshold           = "30"

  alarm_actions = [aws_autoscaling_policy.scale_down.arn]

  dimensions = {
    AutoScalingGroupName = aws_autoscaling_group.web.name
  }
}
```

## 📊 Monitoring & Logging

Advanced CloudWatch setup.

### Create `monitoring.tf`

```hcl
# CloudWatch Log Group
resource "aws_cloudwatch_log_group" "web_server" {
  name              = "/aws/ec2/web-server"
  retention_in_days = 7

  tags = {
    Name = "web-server-logs"
  }
}

# Custom Metric for Application
resource "aws_cloudwatch_metric_alarm" "instance_health" {
  alarm_name          = "web-server-health"
  comparison_operator = "LessThanThreshold"
  evaluation_periods  = "3"
  metric_name         = "StatusCheckFailed"
  namespace           = "AWS/EC2"
  period              = "60"
  statistic           = "Sum"
  threshold           = "1"
  alarm_actions       = [aws_sns_topic.alerts.arn]

  dimensions = {
    InstanceId = aws_instance.web_server.id
  }
}

# SNS Topic for Alerts
resource "aws_sns_topic" "alerts" {
  name = "web-server-alerts"
}

resource "aws_sns_topic_subscription" "alerts_email" {
  topic_arn = aws_sns_topic.alerts.arn
  protocol  = "email"
  endpoint  = var.alert_email
}

# Dashboard
resource "aws_cloudwatch_dashboard" "web_server" {
  dashboard_name = "web-server-dashboard"

  dashboard_body = jsonencode({
    widgets = [
      {
        type = "metric"
        properties = {
          metrics = [
            ["AWS/EC2", "CPUUtilization", { stat = "Average" }],
            [".", "NetworkIn", { stat = "Sum" }],
            [".", "NetworkOut", { stat = "Sum" }]
          ]
          period = 300
          stat   = "Average"
          region = var.aws_region
          title  = "EC2 Instance Metrics"
        }
      }
    ]
  })
}
```

## 🔗 Remote State Management

Store Terraform state in S3 for team collaboration.

### Create `backend.tf`

```hcl
terraform {
  backend "s3" {
    bucket         = "my-terraform-state-bucket"
    key            = "web-server/terraform.tfstate"
    region         = "us-east-1"
    encrypt        = true
    dynamodb_table = "terraform-locks"
  }
}

# Create bucket and DynamoDB table first:
# aws s3api create-bucket --bucket my-terraform-state-bucket
# aws dynamodb create-table --table-name terraform-locks \
#   --attribute-definitions AttributeName=LockID,AttributeType=S \
#   --key-schema AttributeName=LockID,KeyType=HASH \
#   --provisioned-throughput ReadCapacityUnits=5,WriteCapacityUnits=5
```

## 🏷️ Tagging Strategy

Implement comprehensive resource tagging.

### Create `tags.tf`

```hcl
variable "tags_common" {
  description = "Common tags for all resources"
  type        = map(string)
  default = {
    Project     = "WebServer"
    Environment = "Development"
    ManagedBy   = "Terraform"
    CreatedAt   = "2026-03-26"
    Owner       = "DevOps"
  }
}

variable "tags_cost_center" {
  description = "Cost allocation tags"
  type        = map(string)
  default = {
    CostCenter = "Engineering"
    Billable   = "true"
  }
}

locals {
  tags_all = merge(var.tags_common, var.tags_cost_center)
}

# Use in resources:
# tags = merge(local.tags_all, { Name = "my-resource" })
```

## 📜 CI/CD Integration

GitHub Actions for automated Terraform deployment.

### Create `.github/workflows/terraform.yml`

```yaml
name: 'Terraform'

on:
  push:
    paths:
      - 'terraform/**'
      - '.github/workflows/terraform.yml'

jobs:
  terraform:
    runs-on: ubuntu-latest
    
    steps:
      - uses: actions/checkout@v3
      
      - name: Setup Terraform
        uses: hashicorp/setup-terraform@v2
        with:
          terraform_version: 1.5.0
      
      - name: Terraform Init
        run: terraform init
        working-directory: ./terraform-web-server
      
      - name: Terraform Validate
        run: terraform validate
        working-directory: ./terraform-web-server
      
      - name: Terraform Plan
        env:
          AWS_ACCESS_KEY_ID: ${{ secrets.AWS_ACCESS_KEY_ID }}
          AWS_SECRET_ACCESS_KEY: ${{ secrets.AWS_SECRET_ACCESS_KEY }}
        run: terraform plan -out=tfplan
        working-directory: ./terraform-web-server
      
      - name: Terraform Apply
        if: github.ref == 'refs/heads/main'
        env:
          AWS_ACCESS_KEY_ID: ${{ secrets.AWS_ACCESS_KEY_ID }}
          AWS_SECRET_ACCESS_KEY: ${{ secrets.AWS_SECRET_ACCESS_KEY }}
        run: terraform apply -auto-approve tfplan
        working-directory: ./terraform-web-server
```

---

**Tip**: Test extensions on a development environment first before applying to production!
