export const products = [
  // Mobiles (10 products)
  {
    id: 1,
    name: "iPhone 15 Pro Max",
    price: 159900,
    image: "https://images.unsplash.com/photo-1695048133142-1a20484d2569?w=800&q=80",
    description: "Titanium design with A17 Pro chip, 256GB storage, and Pro camera system with 5x optical zoom.",
    category: "Mobiles",
    rating: 4.9,
    features: ["A17 Pro Chip", "256GB Storage", "48MP Camera", "Titanium Design"]
  },
  {
    id: 2,
    name: "iPhone 15 Pro",
    price: 134900,
    image: "https://images.unsplash.com/photo-1592286927505-4b100fe7eaa6?w=800&q=80",
    description: "Latest iPhone with A17 Pro chip, titanium design, and advanced camera system.",
    category: "Mobiles",
    rating: 4.8,
    features: ["A17 Pro Chip", "128GB Storage", "48MP Camera", "Action Button"]
  },
  {
    id: 3,
    name: "Samsung Galaxy S24 Ultra",
    price: 129999,
    image: "https://images.unsplash.com/photo-1610945415295-d9bbf067e59c?w=800&q=80",
    description: "Flagship Android phone with S Pen, 200MP camera, and AI-powered features.",
    category: "Mobiles",
    rating: 4.7,
    features: ["Snapdragon 8 Gen 3", "12GB RAM", "200MP Camera", "S Pen Included"]
  },
  {
    id: 4,
    name: "Google Pixel 8 Pro",
    price: 106999,
    image: "https://images.unsplash.com/photo-1598327105666-5b89351aff97?w=800&q=80",
    description: "Google's flagship with Tensor G3 chip and exceptional AI photography.",
    category: "Mobiles",
    rating: 4.6,
    features: ["Tensor G3", "12GB RAM", "50MP Camera", "7 Years Updates"]
  },
  {
    id: 5,
    name: "OnePlus 12",
    price: 64999,
    image: "https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?w=800&q=80",
    description: "Flagship killer with Snapdragon 8 Gen 3 and 100W fast charging.",
    category: "Mobiles",
    rating: 4.5,
    features: ["Snapdragon 8 Gen 3", "16GB RAM", "50MP Camera", "100W Charging"]
  },
  {
    id: 6,
    name: "iPhone 14 Pro",
    price: 119900,
    image: "https://images.unsplash.com/photo-1678685888857-58767e8d42dd?w=800&q=80",
    description: "Previous generation Pro with A16 Bionic and Dynamic Island.",
    category: "Mobiles",
    rating: 4.7,
    features: ["A16 Bionic", "128GB Storage", "48MP Camera", "Dynamic Island"]
  },
  {
    id: 7,
    name: "Xiaomi 14 Pro",
    price: 79999,
    image: "https://images.unsplash.com/photo-1567581935884-3349723552ca?w=800&q=80",
    description: "Premium flagship with Leica camera and Snapdragon 8 Gen 3.",
    category: "Mobiles",
    rating: 4.4,
    features: ["Snapdragon 8 Gen 3", "12GB RAM", "50MP Leica Camera", "120W Charging"]
  },
  {
    id: 8,
    name: "Vivo X100 Pro",
    price: 89999,
    image: "https://images.unsplash.com/photo-1556656793-08538906a9f8?w=800&q=80",
    description: "Camera-focused flagship with Zeiss optics.",
    category: "Mobiles",
    rating: 4.5,
    features: ["Dimensity 9300", "16GB RAM", "50MP Zeiss Camera", "120W Charging"]
  },
  {
    id: 9,
    name: "Nothing Phone 2",
    price: 44999,
    image: "https://images.unsplash.com/photo-1585060544812-6b45742d762f?w=800&q=80",
    description: "Unique design with Glyph interface and powerful performance.",
    category: "Mobiles",
    rating: 4.3,
    features: ["Snapdragon 8+ Gen 1", "12GB RAM", "50MP Camera", "Glyph Interface"]
  },
  {
    id: 10,
    name: "Realme GT 5 Pro",
    price: 54999,
    image: "https://images.unsplash.com/photo-1574944985070-8f3ebc6b79d2?w=800&q=80",
    description: "Performance-focused phone with excellent value.",
    category: "Mobiles",
    rating: 4.2,
    features: ["Snapdragon 8 Gen 3", "12GB RAM", "50MP Camera", "100W Charging"]
  },

  // Laptops (10 products)
  {
    id: 11,
    name: "MacBook Pro 16\" M3 Max",
    price: 399900,
    image: "https://images.unsplash.com/photo-1517336714731-489689fd1ca8?w=800&q=80",
    description: "Ultimate performance laptop with M3 Max chip for professionals.",
    category: "Laptops",
    rating: 4.9,
    features: ["M3 Max Chip", "36GB RAM", "1TB SSD", "Liquid Retina XDR"]
  },
  {
    id: 12,
    name: "MacBook Air M2",
    price: 119900,
    image: "https://images.unsplash.com/photo-1611186871348-b1ce696e52c9?w=800&q=80",
    description: "Thin, light, and powerful laptop for everyday use.",
    category: "Laptops",
    rating: 4.8,
    features: ["M2 Chip", "16GB RAM", "512GB SSD", "13.6\" Display"]
  },
  {
    id: 13,
    name: "Dell XPS 15",
    price: 189999,
    image: "https://images.unsplash.com/photo-1593642632823-8f785ba67e45?w=800&q=80",
    description: "Premium Windows laptop with stunning OLED display.",
    category: "Laptops",
    rating: 4.7,
    features: ["Intel i9-13900H", "32GB RAM", "1TB SSD", "OLED Display"]
  },
  {
    id: 14,
    name: "HP Spectre x360",
    price: 154999,
    image: "https://images.unsplash.com/photo-1496181133206-80ce9b88a853?w=800&q=80",
    description: "Versatile 2-in-1 laptop with touchscreen.",
    category: "Laptops",
    rating: 4.6,
    features: ["Intel i7-13700H", "16GB RAM", "1TB SSD", "360° Hinge"]
  },
  {
    id: 15,
    name: "Lenovo ThinkPad X1 Carbon",
    price: 169999,
    image: "https://images.unsplash.com/photo-1588872657578-7efd1f1555ed?w=800&q=80",
    description: "Business laptop with legendary keyboard and durability.",
    category: "Laptops",
    rating: 4.7,
    features: ["Intel i7-13800H", "32GB RAM", "1TB SSD", "Carbon Fiber"]
  },
  {
    id: 16,
    name: "ASUS ROG Zephyrus G14",
    price: 179999,
    image: "https://images.unsplash.com/photo-1603302576837-37561b2e2302?w=800&q=80",
    description: "Compact gaming laptop with RTX 4070.",
    category: "Laptops",
    rating: 4.8,
    features: ["AMD Ryzen 9", "32GB RAM", "RTX 4070", "14\" QHD"]
  },
  {
    id: 17,
    name: "Microsoft Surface Laptop 5",
    price: 134999,
    image: "https://images.unsplash.com/photo-1587614382346-4ec70e388b28?w=800&q=80",
    description: "Sleek Windows laptop with premium build quality.",
    category: "Laptops",
    rating: 4.5,
    features: ["Intel i7-1255U", "16GB RAM", "512GB SSD", "PixelSense Display"]
  },
  {
    id: 18,
    name: "Acer Swift X",
    price: 84999,
    image: "https://images.unsplash.com/photo-1525547719571-a2d4ac8945e2?w=800&q=80",
    description: "Affordable creator laptop with dedicated GPU.",
    category: "Laptops",
    rating: 4.4,
    features: ["AMD Ryzen 7", "16GB RAM", "RTX 3050", "512GB SSD"]
  },
  {
    id: 19,
    name: "LG Gram 17",
    price: 149999,
    image: "https://images.unsplash.com/photo-1484788984921-03950022c9ef?w=800&q=80",
    description: "Incredibly lightweight 17-inch laptop.",
    category: "Laptops",
    rating: 4.6,
    features: ["Intel i7-13700H", "16GB RAM", "1TB SSD", "1.35kg Weight"]
  },
  {
    id: 20,
    name: "MSI Prestige 14",
    price: 109999,
    image: "https://images.unsplash.com/photo-1541807084-5c52b6b3adef?w=800&q=80",
    description: "Creator laptop with excellent color accuracy.",
    category: "Laptops",
    rating: 4.5,
    features: ["Intel i7-13700H", "32GB RAM", "1TB SSD", "GTX 1650"]
  },

  // Headphones (10 products)
  {
    id: 21,
    name: "Sony WH-1000XM5",
    price: 29990,
    image: "https://images.unsplash.com/photo-1546435770-a3e426bf472b?w=800&q=80",
    description: "Industry-leading noise cancellation and audio quality.",
    category: "Headphones",
    rating: 4.9,
    features: ["Active NC", "30hrs Battery", "Hi-Res Audio", "Multipoint"]
  },
  {
    id: 22,
    name: "AirPods Max",
    price: 59900,
    image: "https://images.unsplash.com/photo-1606841837239-c5a1a4a07af7?w=800&q=80",
    description: "Premium over-ear headphones with Apple ecosystem integration.",
    category: "Headphones",
    rating: 4.7,
    features: ["Spatial Audio", "20hrs Battery", "Premium Build", "Active NC"]
  },
  {
    id: 23,
    name: "Bose QuietComfort Ultra",
    price: 34990,
    image: "https://images.unsplash.com/photo-1484704849700-f032a568e944?w=800&q=80",
    description: "Legendary comfort with immersive audio.",
    category: "Headphones",
    rating: 4.8,
    features: ["CustomTune", "24hrs Battery", "Spatial Audio", "Active NC"]
  },
  {
    id: 24,
    name: "Sennheiser Momentum 4",
    price: 29990,
    image: "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=800&q=80",
    description: "Audiophile-grade wireless headphones.",
    category: "Headphones",
    rating: 4.7,
    features: ["60hrs Battery", "Adaptive NC", "Hi-Fi Audio", "Premium Design"]
  },
  {
    id: 25,
    name: "JBL Live 660NC",
    price: 9999,
    image: "https://images.unsplash.com/photo-1590658268037-6bf12165a8df?w=800&q=80",
    description: "Affordable wireless headphones with great sound.",
    category: "Headphones",
    rating: 4.4,
    features: ["Active NC", "50hrs Battery", "JBL Signature Sound", "Voice Assistant"]
  },
  {
    id: 26,
    name: "Beats Studio Pro",
    price: 34990,
    image: "https://images.unsplash.com/photo-1577174881658-0f30157f5611?w=800&q=80",
    description: "Stylish headphones with powerful bass.",
    category: "Headphones",
    rating: 4.5,
    features: ["Active NC", "40hrs Battery", "Spatial Audio", "Fast Fuel"]
  },
  {
    id: 27,
    name: "Audio-Technica ATH-M50xBT2",
    price: 19990,
    image: "https://images.unsplash.com/photo-1558756520-22cfe5d382ca?w=800&q=80",
    description: "Studio monitor headphones with Bluetooth.",
    category: "Headphones",
    rating: 4.6,
    features: ["50hrs Battery", "Studio Sound", "Multipoint", "Low Latency"]
  },
  {
    id: 28,
    name: "Anker Soundcore Q45",
    price: 7999,
    image: "https://images.unsplash.com/photo-1545127398-14699f92334b?w=800&q=80",
    description: "Budget headphones with premium features.",
    category: "Headphones",
    rating: 4.3,
    features: ["Active NC", "50hrs Battery", "LDAC Support", "App Control"]
  },
  {
    id: 29,
    name: "Shure AONIC 50",
    price: 29990,
    image: "https://images.unsplash.com/photo-1487215078519-e21cc028cb29?w=800&q=80",
    description: "Professional audio quality headphones.",
    category: "Headphones",
    rating: 4.7,
    features: ["Active NC", "20hrs Battery", "Studio Quality", "Adjustable EQ"]
  },
  {
    id: 30,
    name: "Jabra Elite 85h",
    price: 19990,
    image: "https://images.unsplash.com/photo-1599669454699-248893623440?w=800&q=80",
    description: "Smart headphones with AI sound adaptation.",
    category: "Headphones",
    rating: 4.5,
    features: ["SmartSound", "36hrs Battery", "Rain Resistant", "8 Mics"]
  },

  // Smart Watches (10 products)
  {
    id: 31,
    name: "Apple Watch Series 9",
    price: 44900,
    image: "https://images.unsplash.com/photo-1579586337278-3befd40fd17a?w=800&q=80",
    description: "Most advanced Apple Watch with double tap gesture.",
    category: "Smart Watches",
    rating: 4.8,
    features: ["S9 Chip", "Always-On Display", "ECG", "Blood Oxygen"]
  },
  {
    id: 32,
    name: "Samsung Galaxy Watch 6",
    price: 31999,
    image: "https://images.unsplash.com/photo-1557438159-51eec7a6c9e8?w=800&q=80",
    description: "Android's best smartwatch with comprehensive health tracking.",
    category: "Smart Watches",
    rating: 4.7,
    features: ["Exynos W930", "AMOLED Display", "Body Composition", "40hrs Battery"]
  },
  {
    id: 33,
    name: "Garmin Fenix 7",
    price: 79990,
    image: "https://images.unsplash.com/photo-1508685096489-7aacd43bd3b1?w=800&q=80",
    description: "Premium multisport GPS watch.",
    category: "Smart Watches",
    rating: 4.9,
    features: ["Solar Charging", "Topo Maps", "Multi-GNSS", "18 Days Battery"]
  },
  {
    id: 34,
    name: "Fitbit Sense 2",
    price: 24990,
    image: "https://images.unsplash.com/photo-1551808525-51a94da548ce?w=800&q=80",
    description: "Health-focused smartwatch with stress management.",
    category: "Smart Watches",
    rating: 4.5,
    features: ["cEDA Sensor", "6 Days Battery", "Google Services", "Sleep Tracking"]
  },
  {
    id: 35,
    name: "Amazfit GTR 4",
    price: 14999,
    image: "https://images.unsplash.com/photo-1617625802912-cde586faf331?w=800&q=80",
    description: "Affordable smartwatch with excellent battery life.",
    category: "Smart Watches",
    rating: 4.4,
    features: ["14 Days Battery", "GPS", "150+ Sports Modes", "Alexa Built-in"]
  },
  {
    id: 36,
    name: "OnePlus Watch 2",
    price: 24999,
    image: "https://images.unsplash.com/photo-1544117519-31a4b719223d?w=800&q=80",
    description: "Dual-engine architecture for long battery life.",
    category: "Smart Watches",
    rating: 4.3,
    features: ["100hrs Battery", "Wear OS", "AMOLED", "Fast Charging"]
  },
  {
    id: 37,
    name: "Fossil Gen 6",
    price: 22995,
    image: "https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=800&q=80",
    description: "Stylish Wear OS smartwatch.",
    category: "Smart Watches",
    rating: 4.2,
    features: ["Snapdragon 4100+", "Wear OS", "SpO2", "Fast Charging"]
  },
  {
    id: 38,
    name: "Noise ColorFit Pro 5",
    price: 3999,
    image: "https://images.unsplash.com/photo-1524805444758-089113d48a6d?w=800&q=80",
    description: "Budget smartwatch with premium features.",
    category: "Smart Watches",
    rating: 4.1,
    features: ["7 Days Battery", "1.85\" Display", "100+ Sports", "BT Calling"]
  },
  {
    id: 39,
    name: "Huawei Watch GT 4",
    price: 22999,
    image: "https://images.unsplash.com/photo-1434494878577-86c23bcb06b9?w=800&q=80",
    description: "Premium design with long battery life.",
    category: "Smart Watches",
    rating: 4.5,
    features: ["14 Days Battery", "AMOLED", "TruSeen 5.5", "100+ Workouts"]
  },
  {
    id: 40,
    name: "Withings ScanWatch",
    price: 27990,
    image: "https://images.unsplash.com/photo-1526045478516-99145907023c?w=800&q=80",
    description: "Hybrid smartwatch with medical-grade sensors.",
    category: "Smart Watches",
    rating: 4.6,
    features: ["30 Days Battery", "ECG", "SpO2", "Sleep Apnea"]
  },

  // Accessories (10 products)
  {
    id: 41,
    name: "Apple AirPods Pro 2",
    price: 26900,
    image: "https://images.unsplash.com/photo-1606841837239-c5a1a4a07af7?w=800&q=80",
    description: "Premium true wireless earbuds with adaptive audio.",
    category: "Accessories",
    rating: 4.8,
    features: ["Adaptive Audio", "6hrs Battery", "MagSafe", "H2 Chip"]
  },
  {
    id: 42,
    name: "Samsung Galaxy Buds 2 Pro",
    price: 17990,
    image: "https://images.unsplash.com/photo-1590658268037-6bf12165a8df?w=800&q=80",
    description: "Premium TWS with 360 audio.",
    category: "Accessories",
    rating: 4.6,
    features: ["Active NC", "8hrs Battery", "360 Audio", "IPX7"]
  },
  {
    id: 43,
    name: "Anker PowerCore 20000mAh",
    price: 3999,
    image: "https://images.unsplash.com/photo-1609091839311-d5365f9ff1c5?w=800&q=80",
    description: "High-capacity power bank with fast charging.",
    category: "Accessories",
    rating: 4.5,
    features: ["20000mAh", "18W Fast Charge", "Dual USB", "MultiProtect"]
  },
  {
    id: 44,
    name: "Logitech MX Master 3S",
    price: 9995,
    image: "https://images.unsplash.com/photo-1527814050087-3793815479db?w=800&q=80",
    description: "Premium wireless mouse for productivity.",
    category: "Accessories",
    rating: 4.7,
    features: ["8K DPI", "Multi-Device", "70 Days Battery", "Silent Clicks"]
  },
  {
    id: 45,
    name: "Apple Magic Keyboard",
    price: 14900,
    image: "https://images.unsplash.com/photo-1587829741301-dc798b83add3?w=800&q=80",
    description: "Wireless keyboard with numeric keypad.",
    category: "Accessories",
    rating: 4.6,
    features: ["Rechargeable", "Scissor Mechanism", "Numeric Keypad", "Multi-Device"]
  },
  {
    id: 46,
    name: "SanDisk Extreme Pro 1TB",
    price: 14999,
    image: "https://images.unsplash.com/photo-1597872200969-2b65d56bd16b?w=800&q=80",
    description: "Ultra-fast portable SSD.",
    category: "Accessories",
    rating: 4.8,
    features: ["1TB Storage", "1050MB/s", "Rugged Design", "USB-C"]
  },
  {
    id: 47,
    name: "Belkin 3-in-1 Wireless Charger",
    price: 11999,
    image: "https://images.unsplash.com/photo-1591290619762-85f6df3e01d4?w=800&q=80",
    description: "Charge phone, watch, and earbuds simultaneously.",
    category: "Accessories",
    rating: 4.5,
    features: ["15W Fast Charge", "MagSafe Compatible", "Premium Design", "LED Indicator"]
  },
  {
    id: 48,
    name: "Apple Pencil 2",
    price: 12900,
    image: "https://images.unsplash.com/photo-1611532736579-6b16e2b50449?w=800&q=80",
    description: "Precision stylus for iPad.",
    category: "Accessories",
    rating: 4.7,
    features: ["Pressure Sensitive", "Tilt Support", "Wireless Charging", "Double Tap"]
  },
  {
    id: 49,
    name: "Rode Wireless GO II",
    price: 24900,
    image: "https://images.unsplash.com/photo-1590602847861-f357a9332bbc?w=800&q=80",
    description: "Dual-channel wireless microphone system.",
    category: "Accessories",
    rating: 4.8,
    features: ["Dual Channel", "7hrs Battery", "200m Range", "On-Board Recording"]
  },
  {
    id: 50,
    name: "Elgato Stream Deck",
    price: 14999,
    image: "https://images.unsplash.com/photo-1625948515291-69613efd103f?w=800&q=80",
    description: "Studio controller for content creators.",
    category: "Accessories",
    rating: 4.6,
    features: ["15 LCD Keys", "Customizable", "Multi-Action", "Plugin Support"]
  }
];
