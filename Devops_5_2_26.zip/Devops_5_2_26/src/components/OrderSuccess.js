import React, { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';

function OrderSuccess() {
  const navigate = useNavigate();
  const orderId = localStorage.getItem('lastOrderId') || 'ORD123456789';

  useEffect(() => {
    // Scroll to top
    window.scrollTo(0, 0);
  }, []);

  return (
    <div className="order-success-page">
      <div className="success-container">
        <div className="success-animation">
          <div className="success-checkmark">
            <div className="check-icon">
              <span className="icon-line line-tip"></span>
              <span className="icon-line line-long"></span>
              <div className="icon-circle"></div>
              <div className="icon-fix"></div>
            </div>
          </div>
        </div>

        <h1 className="success-title">Order Placed Successfully!</h1>
        <p className="success-message">
          Thank you for your purchase. Your order has been confirmed and will be delivered soon.
        </p>

        <div className="order-details-card">
          <h3>Order Details</h3>
          <div className="order-info">
            <div className="order-info-row">
              <span className="label">Order ID:</span>
              <span className="value">{orderId}</span>
            </div>
            <div className="order-info-row">
              <span className="label">Order Date:</span>
              <span className="value">{new Date().toLocaleDateString('en-IN', { 
                day: 'numeric', 
                month: 'long', 
                year: 'numeric' 
              })}</span>
            </div>
            <div className="order-info-row">
              <span className="label">Estimated Delivery:</span>
              <span className="value">{new Date(Date.now() + 5 * 24 * 60 * 60 * 1000).toLocaleDateString('en-IN', { 
                day: 'numeric', 
                month: 'long', 
                year: 'numeric' 
              })}</span>
            </div>
          </div>
        </div>

        <div className="success-features">
          <div className="feature-item">
            <div className="feature-icon">📧</div>
            <p>Order confirmation sent to your email</p>
          </div>
          <div className="feature-item">
            <div className="feature-icon">📦</div>
            <p>Track your order anytime</p>
          </div>
          <div className="feature-item">
            <div className="feature-icon">🔄</div>
            <p>Easy returns within 7 days</p>
          </div>
        </div>

        <div className="success-actions">
          <button className="primary-action-btn" onClick={() => navigate('/products')}>
            Continue Shopping
          </button>
          <button className="secondary-action-btn" onClick={() => navigate('/')}>
            Back to Home
          </button>
        </div>
      </div>
    </div>
  );
}

export default OrderSuccess;
