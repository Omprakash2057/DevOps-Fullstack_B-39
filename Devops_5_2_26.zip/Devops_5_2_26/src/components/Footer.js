import React from 'react';
import { Link } from 'react-router-dom';

function Footer() {
  return (
    <footer className="footer">
      <div className="footer-content">
        <div className="footer-section">
          <h3>ShopEase</h3>
          <p>Your one-stop destination for premium electronics and gadgets.</p>
          <div className="social-links">
            <a href="#" aria-label="Facebook">📘</a>
            <a href="#" aria-label="Twitter">🐦</a>
            <a href="#" aria-label="Instagram">📷</a>
            <a href="#" aria-label="LinkedIn">💼</a>
          </div>
        </div>

        <div className="footer-section">
          <h4>Quick Links</h4>
          <ul>
            <li><Link to="/">Home</Link></li>
            <li><Link to="/products">Products</Link></li>
            <li><Link to="/cart">Cart</Link></li>
            <li><Link to="/checkout">Checkout</Link></li>
          </ul>
        </div>

        <div className="footer-section">
          <h4>Customer Service</h4>
          <ul>
            <li><a href="#">Contact Us</a></li>
            <li><a href="#">Shipping Policy</a></li>
            <li><a href="#">Return Policy</a></li>
            <li><a href="#">FAQs</a></li>
          </ul>
        </div>

        <div className="footer-section">
          <h4>Contact Info</h4>
          <ul>
            <li>📧 support@shopease.com</li>
            <li>📱 +91 1800-123-4567</li>
            <li>📍 Mumbai, Maharashtra, India</li>
            <li>🕐 24/7 Customer Support</li>
          </ul>
        </div>
      </div>

      <div className="footer-bottom">
        <p>&copy; 2026 ShopEase. All rights reserved.</p>
        <div className="payment-methods">
          <span>We Accept:</span>
          <span>💳 Visa</span>
          <span>💳 Mastercard</span>
          <span>📱 UPI</span>
          <span>💵 COD</span>
        </div>
      </div>
    </footer>
  );
}

export default Footer;
