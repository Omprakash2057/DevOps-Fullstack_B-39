import React from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useCart } from '../context/CartContext';
import { products } from '../data/productsData';

function ProductDetail() {
  const { id } = useParams();
  const { addToCart } = useCart();
  const navigate = useNavigate();

  // Find product by ID
  const product = products.find(p => p.id === parseInt(id));

  const handleAddToCart = () => {
    addToCart(product);
    alert(`${product.name} added to cart!`);
  };

  if (!product) {
    return (
      <div className="product-detail-page">
        <div className="not-found-product">
          <h2>Product Not Found</h2>
          <p>The product you're looking for doesn't exist.</p>
          <button onClick={() => navigate('/products')} className="back-to-products-btn">
            Back to Products
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="product-detail-page">
      <button onClick={() => navigate('/products')} className="back-button">
        ← Back to Products
      </button>
      
      <div className="product-detail-container">
        <div className="product-detail-image">
          <img src={product.image} alt={product.name} />
          <div className="product-category-badge">{product.category}</div>
        </div>
        
        <div className="product-detail-info">
          <h1 className="product-detail-title">{product.name}</h1>
          <div className="product-detail-price">{product.price}</div>
          
          <div className="product-description">
            <h3>Description</h3>
            <p>{product.description}</p>
          </div>
          
          <div className="product-features-list">
            <h3>Key Features</h3>
            <ul>
              {product.features.map((feature, index) => (
                <li key={index}>
                  <span className="feature-bullet">✓</span>
                  {feature}
                </li>
              ))}
            </ul>
          </div>
          
          <div className="product-actions">
            <button className="add-to-cart-btn-large" onClick={handleAddToCart}>
              Add to Cart
            </button>
            <button className="buy-now-btn" onClick={() => alert('Buy Now functionality')}>
              Buy Now
            </button>
          </div>
          
          <div className="product-meta">
            <p>📦 Free Delivery Available</p>
            <p>🔄 7 Days Return Policy</p>
            <p>✅ 1 Year Warranty</p>
          </div>
        </div>
      </div>
    </div>
  );
}

export default ProductDetail;
