import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useCart } from '../context/CartContext';

function Payment() {
  const navigate = useNavigate();
  const { getTotalPrice, clearCart } = useCart();
  const [selectedPayment, setSelectedPayment] = useState('');
  const [cardDetails, setCardDetails] = useState({
    cardNumber: '',
    expiry: '',
    cvv: '',
    cardName: ''
  });
  const [upiId, setUpiId] = useState('');
  const [selectedBank, setSelectedBank] = useState('');
  const [processing, setProcessing] = useState(false);

  const totalAmount = (getTotalPrice() * 1.18).toFixed(0);

  const handlePlaceOrder = () => {
    if (!selectedPayment) {
      alert('Please select a payment method');
      return;
    }

    // Validate payment details based on selected method
    if (selectedPayment === 'card') {
      if (!cardDetails.cardNumber || !cardDetails.expiry || !cardDetails.cvv || !cardDetails.cardName) {
        alert('Please fill all card details');
        return;
      }
    } else if (selectedPayment === 'upi') {
      if (!upiId) {
        alert('Please enter UPI ID');
        return;
      }
    } else if (selectedPayment === 'netbanking') {
      if (!selectedBank) {
        alert('Please select a bank');
        return;
      }
    }

    setProcessing(true);
    
    // Simulate payment processing
    setTimeout(() => {
      const orderId = 'ORD' + Math.random().toString(36).substr(2, 9).toUpperCase();
      localStorage.setItem('lastOrderId', orderId);
      clearCart();
      setProcessing(false);
      navigate('/success');
    }, 2000);
  };

  return (
    <div className="payment-page">
      <div className="payment-container">
        <div className="payment-methods-section">
          <h1>Select Payment Method</h1>
          <p className="secure-message">🔒 Your payment information is secure and encrypted</p>

          <div className="payment-options">
            {/* Cash on Delivery */}
            <div 
              className={`payment-option ${selectedPayment === 'cod' ? 'selected' : ''}`}
              onClick={() => setSelectedPayment('cod')}
            >
              <input
                type="radio"
                name="payment"
                checked={selectedPayment === 'cod'}
                onChange={() => setSelectedPayment('cod')}
              />
              <div className="payment-option-content">
                <div className="payment-icon">💵</div>
                <div className="payment-info">
                  <h3>Cash on Delivery</h3>
                  <p>Pay when you receive your order</p>
                </div>
              </div>
            </div>

            {/* Credit/Debit Card */}
            <div 
              className={`payment-option ${selectedPayment === 'card' ? 'selected' : ''}`}
              onClick={() => setSelectedPayment('card')}
            >
              <input
                type="radio"
                name="payment"
                checked={selectedPayment === 'card'}
                onChange={() => setSelectedPayment('card')}
              />
              <div className="payment-option-content">
                <div className="payment-icon">💳</div>
                <div className="payment-info">
                  <h3>Credit / Debit Card</h3>
                  <p>Visa, Mastercard, Rupay accepted</p>
                </div>
              </div>
            </div>

            {selectedPayment === 'card' && (
              <div className="payment-details card-details">
                <div className="form-group">
                  <label>Card Number</label>
                  <input
                    type="text"
                    placeholder="1234 5678 9012 3456"
                    maxLength="19"
                    value={cardDetails.cardNumber}
                    onChange={(e) => setCardDetails({...cardDetails, cardNumber: e.target.value})}
                  />
                </div>
                <div className="form-group">
                  <label>Cardholder Name</label>
                  <input
                    type="text"
                    placeholder="Name on card"
                    value={cardDetails.cardName}
                    onChange={(e) => setCardDetails({...cardDetails, cardName: e.target.value})}
                  />
                </div>
                <div className="form-row">
                  <div className="form-group">
                    <label>Expiry Date</label>
                    <input
                      type="text"
                      placeholder="MM/YY"
                      maxLength="5"
                      value={cardDetails.expiry}
                      onChange={(e) => setCardDetails({...cardDetails, expiry: e.target.value})}
                    />
                  </div>
                  <div className="form-group">
                    <label>CVV</label>
                    <input
                      type="password"
                      placeholder="123"
                      maxLength="3"
                      value={cardDetails.cvv}
                      onChange={(e) => setCardDetails({...cardDetails, cvv: e.target.value})}
                    />
                  </div>
                </div>
              </div>
            )}

            {/* UPI */}
            <div 
              className={`payment-option ${selectedPayment === 'upi' ? 'selected' : ''}`}
              onClick={() => setSelectedPayment('upi')}
            >
              <input
                type="radio"
                name="payment"
                checked={selectedPayment === 'upi'}
                onChange={() => setSelectedPayment('upi')}
              />
              <div className="payment-option-content">
                <div className="payment-icon">📱</div>
                <div className="payment-info">
                  <h3>UPI Payment</h3>
                  <p>Google Pay, PhonePe, Paytm, BHIM</p>
                </div>
              </div>
            </div>

            {selectedPayment === 'upi' && (
              <div className="payment-details">
                <div className="form-group">
                  <label>Enter UPI ID</label>
                  <input
                    type="text"
                    placeholder="yourname@upi"
                    value={upiId}
                    onChange={(e) => setUpiId(e.target.value)}
                  />
                </div>
                <div className="upi-apps">
                  <button className="upi-app-btn">
                    <span className="upi-icon">G</span>
                    Google Pay
                  </button>
                  <button className="upi-app-btn">
                    <span className="upi-icon">P</span>
                    PhonePe
                  </button>
                  <button className="upi-app-btn">
                    <span className="upi-icon">₹</span>
                    Paytm
                  </button>
                </div>
              </div>
            )}

            {/* Net Banking */}
            <div 
              className={`payment-option ${selectedPayment === 'netbanking' ? 'selected' : ''}`}
              onClick={() => setSelectedPayment('netbanking')}
            >
              <input
                type="radio"
                name="payment"
                checked={selectedPayment === 'netbanking'}
                onChange={() => setSelectedPayment('netbanking')}
              />
              <div className="payment-option-content">
                <div className="payment-icon">🏦</div>
                <div className="payment-info">
                  <h3>Net Banking</h3>
                  <p>All major banks supported</p>
                </div>
              </div>
            </div>

            {selectedPayment === 'netbanking' && (
              <div className="payment-details">
                <div className="banks-grid">
                  <button 
                    className={`bank-btn ${selectedBank === 'sbi' ? 'selected' : ''}`}
                    onClick={() => setSelectedBank('sbi')}
                  >
                    SBI
                  </button>
                  <button 
                    className={`bank-btn ${selectedBank === 'hdfc' ? 'selected' : ''}`}
                    onClick={() => setSelectedBank('hdfc')}
                  >
                    HDFC
                  </button>
                  <button 
                    className={`bank-btn ${selectedBank === 'icici' ? 'selected' : ''}`}
                    onClick={() => setSelectedBank('icici')}
                  >
                    ICICI
                  </button>
                  <button 
                    className={`bank-btn ${selectedBank === 'axis' ? 'selected' : ''}`}
                    onClick={() => setSelectedBank('axis')}
                  >
                    Axis Bank
                  </button>
                </div>
              </div>
            )}

            {/* Pay Later */}
            <div 
              className={`payment-option ${selectedPayment === 'paylater' ? 'selected' : ''}`}
              onClick={() => setSelectedPayment('paylater')}
            >
              <input
                type="radio"
                name="payment"
                checked={selectedPayment === 'paylater'}
                onChange={() => setSelectedPayment('paylater')}
              />
              <div className="payment-option-content">
                <div className="payment-icon">⏰</div>
                <div className="payment-info">
                  <h3>Pay Later</h3>
                  <p>Buy now, pay later options</p>
                </div>
              </div>
            </div>

            {selectedPayment === 'paylater' && (
              <div className="payment-details">
                <div className="paylater-options">
                  <button className="paylater-btn">
                    <span className="paylater-icon">A</span>
                    Amazon Pay Later
                  </button>
                  <button className="paylater-btn">
                    <span className="paylater-icon">F</span>
                    Flipkart Pay Later
                  </button>
                  <button className="paylater-btn">
                    <span className="paylater-icon">L</span>
                    LazyPay
                  </button>
                  <button className="paylater-btn">
                    <span className="paylater-icon">S</span>
                    Simpl
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>

        <div className="payment-summary-section">
          <div className="payment-summary-card">
            <h2>Payment Summary</h2>
            <div className="summary-details">
              <div className="summary-row">
                <span>Subtotal</span>
                <span>₹{getTotalPrice().toLocaleString('en-IN')}</span>
              </div>
              <div className="summary-row">
                <span>Tax (GST 18%)</span>
                <span>₹{(getTotalPrice() * 0.18).toLocaleString('en-IN', {maximumFractionDigits: 0})}</span>
              </div>
              <div className="summary-row">
                <span>Delivery</span>
                <span className="free-text">FREE</span>
              </div>
              <div className="summary-divider"></div>
              <div className="summary-row summary-total">
                <span>Total Amount</span>
                <span>₹{Number(totalAmount).toLocaleString('en-IN')}</span>
              </div>
            </div>

            <button 
              className="place-order-btn" 
              onClick={handlePlaceOrder}
              disabled={processing}
            >
              {processing ? 'Processing...' : 'Place Order'}
            </button>

            <div className="payment-security-badges">
              <span>🔒 Secure Payment</span>
              <span>✓ 100% Safe</span>
              <span>🛡️ Encrypted</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Payment;
