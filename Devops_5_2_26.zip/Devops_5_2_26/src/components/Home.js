import React from 'react';
import { useNavigate } from 'react-router-dom';

function Home() {
  const navigate = useNavigate();

  return (
    <div className="home">
      {/* Hero Section */}
      <section className="hero-section">
        <div className="hero-content">
          <h1 className="hero-title">Welcome to ShopEase</h1>
          <p className="hero-subtitle">
            Discover the latest tech products at unbeatable prices
          </p>
          <p className="hero-description">
            Premium electronics, gadgets, and accessories for your digital lifestyle
          </p>
          <button className="shop-now-btn" onClick={() => navigate('/products')}>
            Shop Now
            <span className="btn-arrow">→</span>
          </button>
        </div>
        <div className="hero-image">
          <img 
            src="https://images.unsplash.com/photo-1607082348824-0a96f2a4b9da?w=1200&q=80" 
            alt="Hero Banner"
          />
        </div>
      </section>

      {/* Features Section */}
      <section className="features-section">
        <h2 className="section-title">Why Choose Us?</h2>
        <div className="features-grid">
          <div className="feature-card">
            <div className="feature-icon">🚚</div>
            <h3>Fast Delivery</h3>
            <p>Get your products delivered within 24-48 hours</p>
          </div>
          <div className="feature-card">
            <div className="feature-icon">💳</div>
            <h3>Secure Payment</h3>
            <p>100% secure payment gateway with encryption</p>
          </div>
          <div className="feature-card">
            <div className="feature-icon">🎁</div>
            <h3>Best Deals</h3>
            <p>Amazing offers and discounts on premium products</p>
          </div>
          <div className="feature-card">
            <div className="feature-icon">🔧</div>
            <h3>Quality Products</h3>
            <p>Authentic products with warranty and support</p>
          </div>
        </div>
      </section>

      {/* Categories Section */}
      <section className="categories-section">
        <h2 className="section-title">Browse Categories</h2>
        <div className="categories-grid">
          <div className="category-card" onClick={() => navigate('/products')}>
            <img src="https://images.unsplash.com/photo-1517336714731-489689fd1ca8?w=400&q=80" alt="Laptops" />
            <div className="category-overlay">
              <h3>Laptops</h3>
            </div>
          </div>
          <div className="category-card" onClick={() => navigate('/products')}>
            <img src="https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?w=400&q=80" alt="Phones" />
            <div className="category-overlay">
              <h3>Smartphones</h3>
            </div>
          </div>
          <div className="category-card" onClick={() => navigate('/products')}>
            <img src="https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=400&q=80" alt="Audio" />
            <div className="category-overlay">
              <h3>Audio</h3>
            </div>
          </div>
          <div className="category-card" onClick={() => navigate('/products')}>
            <img src="https://images.unsplash.com/photo-1579586337278-3befd40fd17a?w=400&q=80" alt="Watches" />
            <div className="category-overlay">
              <h3>Smart Watches</h3>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}

export default Home;
