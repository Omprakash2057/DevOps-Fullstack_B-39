import React, { useState } from 'react';
import { Link, Outlet, useLocation } from 'react-router-dom';
import { products } from '../data/productsData';
import { useCart } from '../context/CartContext';

function Products() {
  const location = useLocation();
  const { addToCart } = useCart();
  const isProductDetailPage = location.pathname !== '/products';

  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [priceRange, setPriceRange] = useState('all');

  // Get unique categories
  const categories = ['All', ...new Set(products.map(p => p.category))];

  // Filter products
  const filteredProducts = products.filter(product => {
    // Search filter
    const matchesSearch = product.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         product.description.toLowerCase().includes(searchTerm.toLowerCase());
    
    // Category filter
    const matchesCategory = selectedCategory === 'All' || product.category === selectedCategory;
    
    // Price range filter
    let matchesPrice = true;
    if (priceRange === 'under10k') matchesPrice = product.price < 10000;
    else if (priceRange === '10k-50k') matchesPrice = product.price >= 10000 && product.price < 50000;
    else if (priceRange === '50k-100k') matchesPrice = product.price >= 50000 && product.price < 100000;
    else if (priceRange === 'above100k') matchesPrice = product.price >= 100000;

    return matchesSearch && matchesCategory && matchesPrice;
  });

  const handleAddToCart = (product) => {
    addToCart(product);
    alert(`${product.name} added to cart!`);
  };

  return (
    <div className="products-page">
      {!isProductDetailPage ? (
        <>
          <div className="products-header">
            <h1>Our Products</h1>
            <p>Discover our collection of {products.length} premium tech products</p>
          </div>

          {/* Search and Filters */}
          <div className="products-filters">
            <div className="search-bar">
              <input
                type="text"
                placeholder="🔍 Search products..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>

            <div className="filter-group">
              <label>Category:</label>
              <select value={selectedCategory} onChange={(e) => setSelectedCategory(e.target.value)}>
                {categories.map(cat => (
                  <option key={cat} value={cat}>{cat}</option>
                ))}
              </select>
            </div>

            <div className="filter-group">
              <label>Price Range:</label>
              <select value={priceRange} onChange={(e) => setPriceRange(e.target.value)}>
                <option value="all">All Prices</option>
                <option value="under10k">Under ₹10,000</option>
                <option value="10k-50k">₹10,000 - ₹50,000</option>
                <option value="50k-100k">₹50,000 - ₹1,00,000</option>
                <option value="above100k">Above ₹1,00,000</option>
              </select>
            </div>

            <button className="clear-filters-btn" onClick={() => {
              setSearchTerm('');
              setSelectedCategory('All');
              setPriceRange('all');
            }}>
              Clear Filters
            </button>
          </div>

          <div className="products-count">
            Showing {filteredProducts.length} of {products.length} products
          </div>
          
          <div className="products-grid">
            {filteredProducts.map((product) => (
              <div key={product.id} className="product-card">
                <div className="product-image-container">
                  <img src={product.image} alt={product.name} />
                  <div className="product-badge">{product.category}</div>
                  <div className="product-rating">⭐ {product.rating}</div>
                </div>
                <div className="product-info">
                  <h3 className="product-name">{product.name}</h3>
                  <p className="product-price">₹{product.price.toLocaleString('en-IN')}</p>
                  <div className="product-features">
                    {product.features.slice(0, 2).map((feature, index) => (
                      <span key={index} className="feature-tag">{feature}</span>
                    ))}
                  </div>
                  <div className="product-actions">
                    <Link to={`/products/${product.id}`} className="view-details-btn">
                      View Details
                    </Link>
                    <button 
                      className="add-to-cart-quick-btn"
                      onClick={() => handleAddToCart(product)}
                    >
                      Add to Cart
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {filteredProducts.length === 0 && (
            <div className="no-products">
              <h3>No products found</h3>
              <p>Try adjusting your filters or search term</p>
            </div>
          )}
        </>
      ) : (
        <Outlet />
      )}
    </div>
  );
}

export default Products;
