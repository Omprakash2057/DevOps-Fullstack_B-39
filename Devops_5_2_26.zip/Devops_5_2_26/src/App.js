import React from 'react';
import { BrowserRouter, Routes, Route, NavLink } from 'react-router-dom';
import { CartProvider, useCart } from './context/CartContext';
import Home from './components/Home';
import Products from './components/Products';
import ProductDetail from './components/ProductDetail';
import Cart from './components/Cart';
import Checkout from './components/Checkout';
import Payment from './components/Payment';
import OrderSuccess from './components/OrderSuccess';
import NotFound from './components/NotFound';
import Footer from './components/Footer';
import './App.css';

function NavBar() {
  const { getTotalItems } = useCart();

  return (
    <nav className="navbar">
      <div className="nav-container">
        <div className="brand">
          <h1 className="logo">ShopEase</h1>
          <span className="logo-tagline">Premium Tech Store</span>
        </div>
        <ul className="nav-links">
          <li>
            <NavLink to="/" className={({ isActive }) => isActive ? 'active' : ''}>
              Home
            </NavLink>
          </li>
          <li>
            <NavLink to="/products" className={({ isActive }) => isActive ? 'active' : ''}>
              Products
            </NavLink>
          </li>
          <li>
            <NavLink to="/cart" className={({ isActive }) => isActive ? 'active' : ''}>
              <span className="cart-link">
                <span>Cart</span>
                {getTotalItems() > 0 && <span className="cart-badge">{getTotalItems()}</span>}
              </span>
            </NavLink>
          </li>
          <li>
            <NavLink to="/checkout" className={({ isActive }) => isActive ? 'active' : ''}>
              Checkout
            </NavLink>
          </li>
        </ul>
      </div>
    </nav>
  );
}

function App() {
  return (
    <CartProvider>
      <BrowserRouter>
        <div className="App">
          <NavBar />

          <div className="content">
            <Routes>
              <Route path="/" element={<Home />} />
              <Route path="/products" element={<Products />}>
                <Route path=":id" element={<ProductDetail />} />
              </Route>
              <Route path="/cart" element={<Cart />} />
              <Route path="/checkout" element={<Checkout />} />
              <Route path="/payment" element={<Payment />} />
              <Route path="/success" element={<OrderSuccess />} />
              <Route path="*" element={<NotFound />} />
            </Routes>
          </div>

          <Footer />
        </div>
      </BrowserRouter>
    </CartProvider>
  );
}

export default App;
