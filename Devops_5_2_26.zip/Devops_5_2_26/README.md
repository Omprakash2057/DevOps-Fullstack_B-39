# React SPA with Routing and Nested Routes

A Single Page Application built with React and React Router demonstrating routing and nested routes.

## Features

- ✅ React 18 with functional components
- ✅ React Router v6 with BrowserRouter
- ✅ Nested routing for product details
- ✅ Dynamic routing using URL parameters (useParams)
- ✅ SPA navigation without page reload
- ✅ Clean and responsive design

## Project Structure

```
src/
├── components/
│   ├── Home.js          # Welcome page
│   ├── Products.js      # Products list with nested routing
│   ├── ProductDetail.js # Dynamic product details using useParams
│   └── Cart.js          # Shopping cart page
├── App.js               # Main app with routing configuration
├── App.css              # Styling
├── index.js             # Entry point
└── index.css            # Global styles
```

## Routing Configuration

### Main Routes
- `/` → Home component
- `/products` → Products component (with nested routes)
- `/cart` → Cart component

### Nested Routes
- `/products/:id` → ProductDetail component (nested inside Products)

## Components

### 1. Home Component
Displays a welcome message and feature cards.

### 2. Products Component
- Lists products (Laptop, Mobile, Headphones)
- Uses `<Link>` for navigation to product details
- Uses `<Outlet />` to render nested ProductDetail component

### 3. ProductDetail Component
- Uses `useParams()` to extract product ID from URL
- Displays dynamic product information based on ID
- Shows product name, price, and description

### 4. Cart Component
Displays a simple shopping cart message.

## Installation

1. Install dependencies:
```bash
npm install
```

2. Start the development server:
```bash
npm start
```

3. Open your browser and navigate to:
```
http://localhost:3000
```

## Usage

1. Navigate to different pages using the navigation menu
2. Click on products to view their details (demonstrates nested routing)
3. Notice the URL changes without page reload (SPA behavior)
4. Product details appear in the nested route area

## Key React Router Concepts Demonstrated

1. **BrowserRouter**: Wraps the entire app for routing
2. **Routes & Route**: Define route configurations
3. **Link**: Navigate without page reload
4. **useParams**: Access URL parameters
5. **Outlet**: Render nested routes
6. **Nested Routes**: Products component contains ProductDetail as a nested route

## Technologies Used

- React 18.2.0
- React Router DOM 6.20.0
- React Scripts 5.0.1
