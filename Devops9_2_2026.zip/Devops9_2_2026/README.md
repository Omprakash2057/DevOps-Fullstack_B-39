# Personal Finance Tracker - Expenses Component

A complete, production-ready React component for tracking personal expenses with a Node.js + Express backend.

## 🚀 Features

### Core Functionality
- ✅ Fetch and display all expenses from backend API
- ✅ Add new expenses via form submission
- ✅ Real-time expense list updates (no page reload)
- ✅ Full form validation
- ✅ Loading states for better UX
- ✅ Error handling with user-friendly messages

### User Experience
- ✅ INR currency formatting using `Intl.NumberFormat`
- ✅ Success/error alert messages with auto-dismiss
- ✅ Submit button disabled during API calls
- ✅ Loading spinner animations
- ✅ Empty state when no expenses exist
- ✅ Total expenses calculation and display

### Design & Responsiveness
- ✅ Modern, gradient-based UI design
- ✅ Fully responsive layout (desktop, tablet, mobile)
- ✅ Mobile-optimized table view
- ✅ Smooth animations and transitions
- ✅ Professional color scheme

### Code Quality
- ✅ Clean, modular, production-ready code
- ✅ Reusable `apiFetch` utility function
- ✅ Proper React hooks usage (`useState`, `useEffect`)
- ✅ Async/await for API calls
- ✅ Well-structured component architecture

---

## 📋 Requirements

### Backend
- Node.js + Express server running at `http://localhost:5000`
- Required endpoints:
  - `GET /api/expenses` - Returns array of expense objects
  - `POST /api/expenses` - Creates a new expense

### Expense Object Structure
```javascript
{
  _id: string,       // Unique identifier
  title: string,     // Expense title
  amount: number,    // Expense amount
  category: string,  // Expense category
  date: string       // Date (ISO string or date format)
}
```

---

## 🛠️ Installation & Setup

### 1. Install Dependencies
```bash
npm install react react-dom
```

### 2. Add Component to Your Project
Copy both files to your React project:
- `Expenses.jsx` - Main component
- `Expenses.css` - Styling

### 3. Import and Use
```javascript
import Expenses from './Expenses';

function App() {
  return (
    <div className="App">
      <Expenses />
    </div>
  );
}

export default App;
```

### 4. Start Your Backend Server
Ensure your Express server is running on port 5000:
```bash
node server.js
```

---

## 📊 Component Structure

### State Variables
```javascript
expenses        // Array of expense objects
formData        // Form inputs {title, amount, category, date}
loading         // Boolean for data fetching state
submitting      // Boolean for form submission state
error           // String for error messages
successMessage  // String for success messages
```

### Key Functions
- `fetchExpenses()` - Fetches all expenses from API
- `handleSubmit()` - Validates and submits new expense
- `validateForm()` - Validates form inputs
- `apiFetch()` - Reusable fetch utility
- `formatCurrency()` - Formats amount in INR
- `formatDate()` - Formats date for display

---

## 🎨 Features Breakdown

### Form Validation
- Title: Required, non-empty
- Amount: Required, must be > 0
- Category: Required, dropdown selection
- Date: Required, date picker (max: today)

### Category Options
- Food & Dining
- Transportation
- Shopping
- Entertainment
- Bills & Utilities
- Healthcare
- Education
- Travel
- Others

### Currency Formatting
```javascript
₹1,234.56  // Indian Rupee format with proper locale
```

### Responsive Breakpoints
- Desktop: > 968px (2-column grid)
- Tablet: 640px - 968px (1-column)
- Mobile: < 640px (optimized cards/table)

---

## 🔧 API Integration

### GET Request
```javascript
// Fetch all expenses
const data = await apiFetch('/api/expenses');
// Expected response: [{ _id, title, amount, category, date }, ...]
```

### POST Request
```javascript
// Add new expense
await apiFetch('/api/expenses', {
  method: 'POST',
  body: JSON.stringify({
    title: 'Grocery Shopping',
    amount: 1500.00,
    category: 'Food & Dining',
    date: '2026-02-09'
  })
});
```

---

## 🎯 Usage Example

1. **Loading**: Component displays "Loading expenses..." on mount
2. **Display**: Shows expenses in a table with title, category, date, and amount
3. **Add Expense**: Fill form → Submit → Success message → List refreshes automatically
4. **Error Handling**: Invalid input or API failures show error alerts
5. **Total**: Running total displayed at top of expense list

---

## 🎨 Customization

### Change API URL
```javascript
const API_BASE_URL = 'http://your-api-url:port';
```

### Modify Categories
Edit the category dropdown in the form section.

### Adjust Colors
Modify CSS variables or gradient values in `Expenses.css`.

### Currency Format
Change locale and currency in `formatCurrency()`:
```javascript
new Intl.NumberFormat('en-US', {
  style: 'currency',
  currency: 'USD'
})
```

---

## 🐛 Error Handling

The component handles:
- Network errors
- API failures
- Invalid form inputs
- Empty responses
- Server errors

All errors display user-friendly messages that auto-dismiss after 3 seconds.

---

## 📱 Mobile Optimization

- Stack layout on small screens
- Touch-friendly form inputs
- Responsive table converts to cards
- Larger touch targets for buttons
- Optimized spacing and typography

---

## 🚀 Production Ready

This component includes:
- ✅ Production-grade error handling
- ✅ Loading states for all async operations
- ✅ Input validation and sanitization
- ✅ Accessible HTML structure
- ✅ Optimized performance
- ✅ Clean, maintainable code
- ✅ Professional UI/UX design

---

## 📝 License

Free to use for personal and commercial projects.

---

## 🤝 Support

For issues or questions, please check:
1. Backend server is running on port 5000
2. CORS is properly configured on backend
3. API endpoints match expected structure
4. Browser console for detailed error messages

---

**Happy Expense Tracking! 💰📊**
