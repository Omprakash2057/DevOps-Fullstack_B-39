import React, { useState, useEffect } from 'react';
import './Expenses.css';

const API_BASE_URL = 'http://localhost:5000';

// Reusable fetch utility function
const apiFetch = async (endpoint, options = {}) => {
  const response = await fetch(`${API_BASE_URL}${endpoint}`, {
    headers: {
      'Content-Type': 'application/json',
      ...options.headers,
    },
    ...options,
  });

  if (!response.ok) {
    const errorData = await response.json().catch(() => ({}));
    throw new Error(errorData.message || `HTTP Error: ${response.status}`);
  }

  return response.json();
};

// Currency formatter for INR
const formatCurrency = (amount) => {
  return new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
    minimumFractionDigits: 2,
  }).format(amount);
};

// Format date for display
const formatDate = (dateString) => {
  return new Date(dateString).toLocaleDateString('en-IN', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
  });
};

const Expenses = () => {
  // State management
  const [expenses, setExpenses] = useState([]);
  const [formData, setFormData] = useState({
    title: '',
    amount: '',
    category: '',
    date: '',
  });
  const [loading, setLoading] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState('');
  const [successMessage, setSuccessMessage] = useState('');

  // Fetch expenses on component mount
  useEffect(() => {
    fetchExpenses();
  }, []);

  // Auto-clear success/error messages after 3 seconds
  useEffect(() => {
    if (successMessage || error) {
      const timer = setTimeout(() => {
        setSuccessMessage('');
        setError('');
      }, 3000);
      return () => clearTimeout(timer);
    }
  }, [successMessage, error]);

  // Fetch all expenses from API
  const fetchExpenses = async () => {
    setLoading(true);
    setError('');
    try {
      const data = await apiFetch('/api/expenses');
      setExpenses(data);
    } catch (err) {
      setError(`Failed to fetch expenses: ${err.message}`);
      setExpenses([]);
    } finally {
      setLoading(false);
    }
  };

  // Handle form input changes
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  // Validate form data
  const validateForm = () => {
    const { title, amount, category, date } = formData;

    if (!title.trim()) {
      setError('Title is required');
      return false;
    }

    if (!amount || parseFloat(amount) <= 0) {
      setError('Amount must be greater than 0');
      return false;
    }

    if (!category.trim()) {
      setError('Category is required');
      return false;
    }

    if (!date) {
      setError('Date is required');
      return false;
    }

    return true;
  };

  // Handle form submission
  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setSuccessMessage('');

    // Validate form
    if (!validateForm()) {
      return;
    }

    setSubmitting(true);

    try {
      // Create expense object
      const newExpense = {
        title: formData.title.trim(),
        amount: parseFloat(formData.amount),
        category: formData.category.trim(),
        date: formData.date,
      };

      // Send POST request
      await apiFetch('/api/expenses', {
        method: 'POST',
        body: JSON.stringify(newExpense),
      });

      // Clear form
      setFormData({
        title: '',
        amount: '',
        category: '',
        date: '',
      });

      // Show success message
      setSuccessMessage('Expense added successfully!');

      // Refresh expense list
      await fetchExpenses();
    } catch (err) {
      setError(`Failed to add expense: ${err.message}`);
    } finally {
      setSubmitting(false);
    }
  };

  // Calculate total expenses
  const totalExpenses = expenses.reduce((sum, expense) => sum + expense.amount, 0);

  return (
    <div className="expenses-container">
      <div className="expenses-wrapper">
        <header className="expenses-header">
          <h1>Personal Finance Tracker</h1>
          <p>Manage your expenses efficiently</p>
        </header>

        {/* Alert Messages */}
        {successMessage && (
          <div className="alert alert-success" role="alert">
            <span className="alert-icon">✓</span>
            {successMessage}
          </div>
        )}

        {error && (
          <div className="alert alert-error" role="alert">
            <span className="alert-icon">✕</span>
            {error}
          </div>
        )}

        <div className="content-grid">
          {/* Add Expense Form */}
          <section className="form-section">
            <h2>Add New Expense</h2>
            <form onSubmit={handleSubmit} className="expense-form">
              <div className="form-group">
                <label htmlFor="title">Title *</label>
                <input
                  type="text"
                  id="title"
                  name="title"
                  value={formData.title}
                  onChange={handleInputChange}
                  placeholder="e.g., Grocery Shopping"
                  disabled={submitting}
                  required
                />
              </div>

              <div className="form-group">
                <label htmlFor="amount">Amount (₹) *</label>
                <input
                  type="number"
                  id="amount"
                  name="amount"
                  value={formData.amount}
                  onChange={handleInputChange}
                  placeholder="0.00"
                  step="0.01"
                  min="0.01"
                  disabled={submitting}
                  required
                />
              </div>

              <div className="form-group">
                <label htmlFor="category">Category *</label>
                <select
                  id="category"
                  name="category"
                  value={formData.category}
                  onChange={handleInputChange}
                  disabled={submitting}
                  required
                >
                  <option value="">Select a category</option>
                  <option value="Food & Dining">Food & Dining</option>
                  <option value="Transportation">Transportation</option>
                  <option value="Shopping">Shopping</option>
                  <option value="Entertainment">Entertainment</option>
                  <option value="Bills & Utilities">Bills & Utilities</option>
                  <option value="Healthcare">Healthcare</option>
                  <option value="Education">Education</option>
                  <option value="Travel">Travel</option>
                  <option value="Others">Others</option>
                </select>
              </div>

              <div className="form-group">
                <label htmlFor="date">Date *</label>
                <input
                  type="date"
                  id="date"
                  name="date"
                  value={formData.date}
                  onChange={handleInputChange}
                  disabled={submitting}
                  max={new Date().toISOString().split('T')[0]}
                  required
                />
              </div>

              <button
                type="submit"
                className="btn btn-primary"
                disabled={submitting}
              >
                {submitting ? (
                  <>
                    <span className="spinner"></span>
                    Adding...
                  </>
                ) : (
                  'Add Expense'
                )}
              </button>
            </form>
          </section>

          {/* Expenses List */}
          <section className="list-section">
            <div className="list-header">
              <h2>Expense History</h2>
              {expenses.length > 0 && (
                <div className="total-badge">
                  Total: {formatCurrency(totalExpenses)}
                </div>
              )}
            </div>

            {loading ? (
              <div className="loading-state">
                <div className="spinner large"></div>
                <p>Loading expenses...</p>
              </div>
            ) : expenses.length === 0 ? (
              <div className="empty-state">
                <div className="empty-icon">💰</div>
                <h3>No expenses yet</h3>
                <p>Start tracking your expenses by adding one above.</p>
              </div>
            ) : (
              <div className="expenses-table-wrapper">
                <table className="expenses-table">
                  <thead>
                    <tr>
                      <th>Title</th>
                      <th>Category</th>
                      <th>Date</th>
                      <th className="text-right">Amount</th>
                    </tr>
                  </thead>
                  <tbody>
                    {expenses.map((expense) => (
                      <tr key={expense._id}>
                        <td className="expense-title">{expense.title}</td>
                        <td>
                          <span className="category-badge">
                            {expense.category}
                          </span>
                        </td>
                        <td className="expense-date">
                          {formatDate(expense.date)}
                        </td>
                        <td className="expense-amount text-right">
                          {formatCurrency(expense.amount)}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </section>
        </div>
      </div>
    </div>
  );
};

export default Expenses;
