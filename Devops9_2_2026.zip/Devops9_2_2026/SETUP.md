# 🚀 Quick Setup Guide

## Backend Setup (5 minutes)

### 1. Install Backend Dependencies
```bash
npm install
```

### 2. Start the Backend Server
```bash
npm start
```

Or for development with auto-reload:
```bash
npm run dev
```

You should see:
```
✅ Server is running on http://localhost:5000
📊 API Endpoints:
   GET    /api/expenses     - Fetch all expenses
   POST   /api/expenses     - Create new expense
   ...
```

---

## Frontend Setup

### Option 1: Add to Existing React App

1. Copy `Expenses.jsx` and `Expenses.css` to your React project
2. Import and use:

```javascript
import Expenses from './Expenses';

function App() {
  return <Expenses />;
}
```

### Option 2: Create New React App

```bash
# Create new React app
npx create-react-app finance-tracker
cd finance-tracker

# Copy Expenses.jsx to src/
# Copy Expenses.css to src/

# Edit src/App.js
```

**src/App.js:**
```javascript
import React from 'react';
import Expenses from './Expenses';

function App() {
  return <Expenses />;
}

export default App;
```

```bash
# Start React app
npm start
```

---

## Testing the Application

1. ✅ Backend running on `http://localhost:5000`
2. ✅ Frontend running on `http://localhost:3000` (React default)
3. ✅ Open browser to `http://localhost:3000`

### Test Checklist
- [ ] See 3 sample expenses loaded
- [ ] Add a new expense via the form
- [ ] See success message appear
- [ ] New expense appears in the table
- [ ] Total amount updates automatically
- [ ] Try submitting empty form (should show error)
- [ ] Try entering negative amount (should show error)

---

## Sample Data

The server starts with 3 sample expenses:
1. Grocery Shopping - ₹2,500.50
2. Metro Card Recharge - ₹800.00
3. Netflix Subscription - ₹649.00

---

## API Testing (Optional)

### Using curl:

**Get all expenses:**
```bash
curl http://localhost:5000/api/expenses
```

**Add new expense:**
```bash
curl -X POST http://localhost:5000/api/expenses \
  -H "Content-Type: application/json" \
  -d '{
    "title": "Coffee",
    "amount": 150,
    "category": "Food & Dining",
    "date": "2026-02-09"
  }'
```

**Health check:**
```bash
curl http://localhost:5000/health
```

---

## Troubleshooting

### Backend Issues

**Problem:** Port 5000 already in use
```bash
# Windows - Find and kill process
netstat -ano | findstr :5000
taskkill /PID <process_id> /F

# Or change port in server.js
const PORT = 5001;  // Use different port
```

**Problem:** CORS errors
- Make sure `cors` package is installed
- Check if `app.use(cors())` is in server.js

### Frontend Issues

**Problem:** Cannot fetch expenses
- Verify backend is running on port 5000
- Check browser console for errors
- Ensure API_BASE_URL in Expenses.jsx matches your backend

**Problem:** Blank page
- Check browser console for errors
- Verify Expenses.jsx and Expenses.css are imported correctly

---

## Production Deployment

### Backend
- Replace in-memory array with MongoDB/PostgreSQL
- Add authentication middleware
- Implement proper error logging
- Add input sanitization
- Set up environment variables

### Frontend
- Build for production: `npm run build`
- Deploy to Vercel, Netlify, or similar
- Update API_BASE_URL to production URL

---

## Next Steps

### Enhancements to Add:
1. ✏️ Edit expense functionality
2. 🗑️ Delete expense functionality
3. 🔍 Search and filter expenses
4. 📊 Charts and analytics
5. 📅 Date range filtering
6. 💾 Export to CSV/PDF
7. 🔐 User authentication
8. 📱 Progressive Web App (PWA)

---

## Need Help?

1. Check README.md for detailed documentation
2. Verify all dependencies are installed
3. Check browser console for errors
4. Ensure backend is running before starting frontend

---

**Happy Tracking! 💰**
