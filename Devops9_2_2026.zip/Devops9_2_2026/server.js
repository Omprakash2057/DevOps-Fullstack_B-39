// Example Express Backend Server for Personal Finance Tracker
// This is a sample server to test the Expenses component

const express = require('express');
const cors = require('cors');
const app = express();
const PORT = 5000;

// Middleware
app.use(cors());
app.use(express.json());

// Serve static files (HTML, CSS, JS)
app.use(express.static(__dirname));

// In-memory database (replace with MongoDB/PostgreSQL in production)
let expenses = [
  {
    _id: '1',
    title: 'Grocery Shopping',
    amount: 2500.50,
    category: 'Food & Dining',
    date: '2026-02-01',
    notes: 'Weekly grocery shopping'
  },
  {
    _id: '2',
    title: 'Metro Card Recharge',
    amount: 800.00,
    category: 'Transportation',
    date: '2026-02-03',
    notes: 'Monthly metro pass'
  },
  {
    _id: '3',
    title: 'Netflix Subscription',
    amount: 649.00,
    category: 'Entertainment',
    date: '2026-02-05',
    notes: 'Premium plan'
  }
];

let budget = {
  monthly: 50000,
  enabled: true
};

let nextId = 4;

// Routes

// GET /api/expenses - Fetch all expenses
app.get('/api/expenses', (req, res) => {
  try {
    // Sort by date (newest first)
    const sortedExpenses = [...expenses].sort((a, b) => 
      new Date(b.date) - new Date(a.date)
    );
    res.json(sortedExpenses);
  } catch (error) {
    res.status(500).json({ message: 'Failed to fetch expenses', error: error.message });
  }
});

// POST /api/expenses - Create a new expense
app.post('/api/expenses', (req, res) => {
  try {
    const { title, amount, category, date, notes } = req.body;

    // Validation
    if (!title || !amount || !category || !date) {
      return res.status(400).json({ 
        message: 'All fields are required: title, amount, category, date' 
      });
    }

    if (amount <= 0) {
      return res.status(400).json({ 
        message: 'Amount must be greater than 0' 
      });
    }

    // Create new expense
    const newExpense = {
      _id: String(nextId++),
      title: title.trim(),
      amount: parseFloat(amount),
      category: category.trim(),
      date,
      notes: notes ? notes.trim() : ''
    };

    expenses.push(newExpense);

    res.status(201).json({
      message: 'Expense created successfully',
      expense: newExpense
    });
  } catch (error) {
    res.status(500).json({ 
      message: 'Failed to create expense', 
      error: error.message 
    });
  }
});

// GET /api/expenses/:id - Get single expense (bonus endpoint)
app.get('/api/expenses/:id', (req, res) => {
  try {
    const expense = expenses.find(exp => exp._id === req.params.id);
    if (!expense) {
      return res.status(404).json({ message: 'Expense not found' });
    }
    res.json(expense);
  } catch (error) {
    res.status(500).json({ message: 'Failed to fetch expense', error: error.message });
  }
});

// DELETE /api/expenses/:id - Delete expense (bonus endpoint)
app.delete('/api/expenses/:id', (req, res) => {
  try {
    const index = expenses.findIndex(exp => exp._id === req.params.id);
    if (index === -1) {
      return res.status(404).json({ message: 'Expense not found' });
    }
    
    const deletedExpense = expenses.splice(index, 1)[0];
    res.json({ 
      message: 'Expense deleted successfully', 
      expense: deletedExpense 
    });
  } catch (error) {
    res.status(500).json({ message: 'Failed to delete expense', error: error.message });
  }
});

// PUT /api/expenses/:id - Update expense
app.put('/api/expenses/:id', (req, res) => {
  try {
    const { title, amount, category, date, notes } = req.body;
    const index = expenses.findIndex(exp => exp._id === req.params.id);
    
    if (index === -1) {
      return res.status(404).json({ message: 'Expense not found' });
    }

    // Validation
    if (!title || !amount || !category || !date) {
      return res.status(400).json({ 
        message: 'All fields are required: title, amount, category, date' 
      });
    }

    if (amount <= 0) {
      return res.status(400).json({ 
        message: 'Amount must be greater than 0' 
      });
    }

    // Update expense
    expenses[index] = {
      ...expenses[index],
      title: title.trim(),
      amount: parseFloat(amount),
      category: category.trim(),
      date,
      notes: notes ? notes.trim() : ''
    };

    res.json({
      message: 'Expense updated successfully',
      expense: expenses[index]
    });
  } catch (error) {
    res.status(500).json({ 
      message: 'Failed to update expense', 
      error: error.message 
    });
  }
});

// GET /api/budget - Get budget
app.get('/api/budget', (req, res) => {
  try {
    res.json(budget);
  } catch (error) {
    res.status(500).json({ message: 'Failed to fetch budget', error: error.message });
  }
});

// PUT /api/budget - Update budget
app.put('/api/budget', (req, res) => {
  try {
    const { monthly, enabled } = req.body;
    
    if (monthly !== undefined) {
      budget.monthly = parseFloat(monthly);
    }
    if (enabled !== undefined) {
      budget.enabled = enabled;
    }
    
    res.json(budget);
  } catch (error) {
    res.status(500).json({ message: 'Failed to update budget', error: error.message });
  }
});

// Health check
app.get('/health', (req, res) => {
  res.json({ status: 'OK', message: 'Server is running' });
});

// Start server
app.listen(PORT, () => {
  console.log(`\n✅ Server is running on http://localhost:${PORT}`);
  console.log(`📊 API Endpoints:`);
  console.log(`   GET    /api/expenses     - Fetch all expenses`);
  console.log(`   POST   /api/expenses     - Create new expense`);
  console.log(`   GET    /api/expenses/:id - Get single expense`);
  console.log(`   DELETE /api/expenses/:id - Delete expense`);
  console.log(`   GET    /health           - Health check\n`);
});

module.exports = app;
