# Monitoring Stack - Quick Start Guide
# Copy and paste commands directly into your terminal

# ============================================================================
# SETUP & STARTUP
# ============================================================================

# Navigate to project
cd c:\Users\malle\OneDrive\Desktop\Devops2026\Devops_2-4-2026

# Build the application image
docker-compose build

# Start all services in background
docker-compose up -d

# Verify all services are running
docker-compose ps

# View startup logs
docker-compose logs -f


# ============================================================================
# VERIFICATION AND TESTING
# ============================================================================

# Test 1: Check application is responding
curl http://localhost:3000/

# Test 2: View application metrics
curl http://localhost:3000/metrics | head -20

# Test 3: Verify Prometheus can scrape targets
curl http://localhost:9090/api/v1/targets

# Test 4: Generate some traffic
for i in {1..50}; do curl -s http://localhost:3000/ > /dev/null & done

# Test 5: Trigger errors (will fire alert after 5 minutes)
for i in {1..50}; do curl -s "http://localhost:3000/error?error_rate=100" > /dev/null & done


# ============================================================================
# ACCESS SERVICES
# ============================================================================

# Open in browser (choose one):
# Grafana (main dashboard)    → http://localhost:3001   [admin/admin123]
# Prometheus (metrics UI)     → http://localhost:9090
# Alertmanager (alerts)       → http://localhost:9093
# Application                 → http://localhost:3000
# cAdvisor                     → http://localhost:8080


# ============================================================================
# MONITORING & DEBUGGING
# ============================================================================

# View logs for specific service
docker-compose logs -f monitoring-app
docker-compose logs -f monitoring-prometheus
docker-compose logs -f monitoring-alertmanager

# Check resource usage
docker stats

# Execute command in container
docker exec monitoring-app npm list
docker exec monitoring-prometheus prometheus --version

# Inspect container
docker inspect monitoring-app


# ============================================================================
# PROMETHEUS QUERIES (Copy to Prometheus > Graph tab)
# ============================================================================

# Show app requests per second
rate(http_requests_total[5m])

# Show error rate percentage
(sum(rate(http_requests_total{status_code=~"5.."}[5m]))/sum(rate(http_requests_total[5m]))) * 100

# Show application response time p95
histogram_quantile(0.95, sum(rate(http_request_duration_ms_bucket[5m])) by (le))

# Show container CPU usage (needs cAdvisor)
container_cpu_usage_seconds_total{name="monitoring-app"}

# Show which services are up
up

# Show Prometheus lag
prometheus_tsdb_compactions_total


# ============================================================================
# DOCKER TROUBLESHOOTING
# ============================================================================

# Clean rebuild
docker-compose down -v
docker-compose build --no-cache
docker-compose up -d

# Rebuild specific service
docker-compose up -d --build monitoring-app

# Remove all containers, networks, volumes
docker-compose down -v

# View specific error
docker-compose logs monitoring-app 2>&1 | grep -i error

# Check Docker daemon
docker ps
docker system info


# ============================================================================
# SIMULATION SCENARIOS
# ============================================================================

# Scenario 1: Kill container and watch restart
docker kill monitoring-app
# Docker auto-restarts it (unless-stopped policy)
# Alert: "ContainerRestartDetected" fires within 1-2 minutes

# Scenario 2: Generate sustained errors
bash -c 'while true; do curl -s "http://localhost:3000/error?error_rate=100" > /dev/null; done'
# Ctrl+C to stop
# Alert: "HighErrorRate" fires after 5 minutes

# Scenario 3: CPU stress (if stress-ng installed)
stress-ng --cpu 1 --timeout 300s
# Alert: "HighContainerCPUUsage" fires after 5 minutes

# Scenario 4: Check metric timestamps
curl -s http://localhost:3000/metrics | grep "^#" | tail -5
curl -s http://localhost:3000/health

# Scenario 5: View JSON formatted errors
curl -s "http://localhost:3000/error?error_rate=100&error_type=database" | jq .


# ============================================================================
# GRAFANA DASHBOARD QUICKSTART
# ============================================================================

# 1. Open Grafana: http://localhost:3001
# 2. Login with admin/admin123
# 3. Create new dashboard:
#    Click + → New Dashboard → New Panel
# 4. Add query:
#    Select "Prometheus" as data source
#    Enter: rate(http_requests_total[5m])
#    Click "Run Queries"
# 5. Save dashboard


# ============================================================================
# ALERT TESTING
# ============================================================================

# View firing alerts in Prometheus UI
# http://localhost:9090 → Alerts tab

# View alerts in Alertmanager
# http://localhost:9093

# Check alert status via API
curl -s http://localhost:9090/api/v1/alerts | jq .data.alerts

# Check Alertmanager alerts via API
curl -s http://localhost:9093/api/v1/alerts | jq '.[] | {groupLabels, alerts}'


# ============================================================================
# CLEANUP
# ============================================================================

# Stop services (keep data)
docker-compose stop

# Remove containers (keep data)
docker-compose down

# Remove everything including persistent data
docker-compose down -v

# Remove unused Docker resources
docker system prune -a --volumes
