# Complete Monitoring & Alerting System - Project Index

A production-ready monitoring stack built with Docker, Prometheus, cAdvisor, Grafana, and Alertmanager.

---

## 📁 Project Structure

```
Devops_2-4-2026/
├── 📄 README.md                          # MAIN DOCUMENTATION (start here!)
├── 📄 QUICK_START.md                     # Quick reference commands
├── 📄 WINDOWS_SETUP.md                   # Windows-specific guide
├── 📄 GRAFANA_SETUP.md                   # Grafana dashboard creation
├── 📄 TROUBLESHOOTING.md                 # Common issues & solutions
├── 📄 PROJECT_INDEX.md                   # This file
│
├── 🐳 docker-compose.yml                 # Docker services orchestration
├── 📦 Dockerfile                         # Application container image
│
├── 📂 app/                               # Node.js Web Application
│   ├── server.js                         # Main application (with metrics)
│   ├── package.json                      # Dependencies
│   └── .gitignore                        # Git ignore rules
│
├── 📂 prometheus/                        # Prometheus Configuration
│   ├── prometheus.yml                    # Prometheus config
│   └── alerts.yml                        # Alert rules (14 different alerts)
│
├── 📂 alertmanager/                      # Alertmanager Configuration
│   └── alertmanager.yml                  # Alert routing & channels
│
├── 📂 grafana/                           # Grafana Configuration
│   └── provisioning/
│       ├── datasources/
│       │   └── prometheus.yml            # Auto-provision Prometheus
│       └── dashboards/                   # (Create dashboards manually)
│
├── 🔧 start-stack-windows.bat            # Windows startup menu script
├── 🔧 test-monitoring-stack.sh           # Test suite script
│
└── .gitignore                            # Git ignore file
```

---

## 🚀 Quick Overview

| Component | Purpose | Port | Access |
|-----------|---------|------|--------|
| **Application** (Node.js) | Web app with metrics | 3000 | http://localhost:3000 |
| **Prometheus** | Metrics collection | 9090 | http://localhost:9090 |
| **Grafana** | Dashboards | 3001 | http://localhost:3001 |
| **Alertmanager** | Alert routing | 9093 | http://localhost:9093 |
| **cAdvisor** | Container metrics | 8080 | http://localhost:8080 |
| **Node Exporter** | Host metrics | 9100 | http://localhost:9100/metrics |

---

## 📖 Documentation Guide

### For Different User Groups

#### I'm New to Monitoring - Start Here
1. Read **README.md** → Architecture Overview
2. Follow **QUICK_START.md** → Run the stack
3. Open **Grafana** (http://localhost:3001)
4. Follow **GRAFANA_SETUP.md** → Create first dashboard

#### I'm on Windows
1. Read **WINDOWS_SETUP.md** → Complete setup guide
2. Run **start-stack-windows.bat** → Interactive menu
3. Follow rest of documentation

#### I Want to Configure/Customize
1. Read **README.md** → Configuration Details section
2. Edit `prometheus/prometheus.yml` → Scrape jobs
3. Edit `prometheus/alerts.yml` → Alert rules
4. Edit `alertmanager/alertmanager.yml` → Alert routing
5. Edit `app/server.js` → Application metrics

#### I'm Having Issues
1. Check **TROUBLESHOOTING.md** → Find your issue
2. Run diagnostics:
   ```bash
   docker-compose logs
   docker-compose ps
   ```
3. Follow solution steps

#### I Want to Test/Demo Features
1. Read **QUICK_START.md** → Testing section
2. Run **test-monitoring-stack.sh** → Automated tests
3. Trigger errors: `curl http://localhost:3000/error?error_rate=100`
4. Check alerts in Grafana/Prometheus/Alertmanager

---

## 🎯 Getting Started

### Step 1: Verify Prerequisites (2 minutes)
```bash
# Check Docker installed
docker --version
docker-compose --version

# Verify Docker daemon running
docker ps
```

### Step 2: Start the Stack (3 minutes)
```bash
# Navigate to project
cd Devops_2-4-2026

# Build and start
docker-compose build
docker-compose up -d

# Verify
docker-compose ps
```

### Step 3: Access Grafana Dashboard (2 minutes)
```
Open browser → http://localhost:3001
Login: admin / admin123
You're now monitoring!
```

### Step 4: Create Your First Dashboard (10 minutes)
- Follow **GRAFANA_SETUP.md** → Dashboard 1: Application Monitoring
- Add first panel with query: `rate(http_requests_total[5m])`
- Generate traffic: `curl http://localhost:3000/`
- Watch metrics appear in real-time

---

## 📚 File Descriptions

### Core System Files

| File | Purpose | Edit? | Key Content |
|------|---------|-------|-------------|
| docker-compose.yml | Service orchestration | ✏️ Maybe | Networks, volumes, service configs |
| Dockerfile | Container build spec | ✏️ Maybe | App installation, health checks |
| app/server.js | Application code | ✏️ Maybe | Endpoints, metrics, logging |

### Configuration Files

| File | Purpose | Edit? | Key Content |
|------|---------|-------|-------------|
| prometheus/prometheus.yml | Metrics collection | ✏️ Often | Scrape jobs, global settings |
| prometheus/alerts.yml | Alert definitions | ✏️ Often | Alert rules, thresholds |
| alertmanager/alertmanager.yml | Alert routing | ✏️ Often | Receivers, routing rules |
| grafana/provisioning/* | Grafana datasources | ✏️ Maybe | Prometheus connection |

### Documentation Files

| File | Purpose | Read? | Best For |
|------|---------|-------|----------|
| README.md | Complete guide | 📖 Essential | Understanding everything |
| QUICK_START.md | Command reference | 📖 Essential | Running commands |
| WINDOWS_SETUP.md | Windows guide | 📖 If on Windows | Windows-specific setup |
| GRAFANA_SETUP.md | Dashboard guide | 📖 When creating dashboards | Building visualizations |
| TROUBLESHOOTING.md | Issue resolution | 📖 When problems occur | Debugging |
| WINDOWS_SETUP.md | Full Windows guide | 📖 Essential for Windows | Complete Windows setup |

---

## 🔄 Common Workflows

### Workflow 1: First-Time Setup
```
1. Install Docker Desktop
   → WINDOWS_SETUP.md / Prerequisites

2. Clone/download project
   → Check all files exist

3. Build and start stack
   → docker-compose build && docker-compose up -d

4. Verify services
   → docker-compose ps
   → curl http://localhost:3000

5. Access Grafana
   → http://localhost:3001 (admin/admin123)

6. Create dashboard
   → GRAFANA_SETUP.md → Follow first dashboard
```

### Workflow 2: Monitor Your Application
```
1. Modify app/server.js
   → Add your application code
   → Expose metrics at /metrics
   → Add custom metrics with prom-client

2. Rebuild image
   → docker-compose build monitoring-app

3. Restart container
   → docker-compose restart monitoring-app

4. Update prometheus.yml
   → Add scrape job if service on different port
   → Reload: curl -X POST http://localhost:9090/-/reload

5. Create dashboard
   → Add panels for your metrics
   → Use PromQL queries (see GRAFANA_SETUP.md)
```

### Workflow 3: Configure Alerts
```
1. Define alert condition
   → Edit prometheus/alerts.yml
   → Write PromQL expression

2. Set threshold & duration
   → When should alert trigger?
   → How long must condition be true?

3. Add labels & descriptions
   → severity: critical/warning/info
   → Annotations: summary, description

4. Configure routing
   → Edit alertmanager/alertmanager.yml
   → Add receiver (email, Slack, webhook, etc.)
   → Set routing rules

5. Test alert
   → Trigger condition manually
   → Verify alert fires
   → Check Alertmanager routes correctly
   → Verify notification sent
```

### Workflow 4: Troubleshoot Issue
```
1. Check error
   → Identify symptom

2. Find in TROUBLESHOOTING.md
   → Search by keyword

3. Run suggested command
   → docker logs, docker exec, curl, etc.

4. Follow solution steps
   → Fix configuration/code

5. Verify fix
   → Restart service
   → Test functionality
```

---

## 🔑 Key Features

### Application
- ✅ REST API with multiple endpoints
- ✅ Prometheus metrics (HTTP requests, errors, latency)
- ✅ Structured JSON logging
- ✅ Error simulation for testing
- ✅ Health check endpoints

### Monitoring
- ✅ Prometheus for metrics collection
- ✅ cAdvisor for container metrics
- ✅ Node Exporter for host metrics
- ✅ 15-day data retention

### Alerting
- ✅ 14 pre-defined alert rules
- ✅ CPU usage alerts
- ✅ Memory usage alerts
- ✅ Application error rate alerts
- ✅ Container restart detection
- ✅ Service availability monitoring

### Visualization (Grafana)
- ✅ Automatic Prometheus data source
- ✅ Pre-configured dashboards (manual setup)
- ✅ Real-time metrics display
- ✅ Alert integration
- ✅ Custom query support

### Alert Routing
- ✅ Console logging (default)
- ✅ Email support (configurable)
- ✅ Slack webhook support (configurable)
- ✅ Alert grouping & deduplication
- ✅ Inhibition rules

---

## 📊 Metrics Collected

### Application Metrics
- `http_requests_total` - Total requests by status
- `http_request_duration_ms` - Request latency histogram
- `application_errors_total` - Errors by type

### Container Metrics (cAdvisor)
- `container_cpu_usage_seconds_total` - CPU time
- `container_memory_usage_bytes` - RAM usage
- `container_network_receive_bytes_total` - Network RX
- `container_network_transmit_bytes_total` - Network TX
- `container_fs_usage_bytes` - Filesystem usage
- `container_last_seen` - Container restart tracking

### Host Metrics (Node Exporter)
- `node_cpu_seconds_total` - CPU seconds
- `node_memory_MemTotal_bytes` - Total RAM
- `node_filesystem_avail_bytes` - Free disk
- `node_network_receive_bytes_total` - Network RX
- `node_load1`, `node_load5`, `node_load15` - Load average

---

## 🚨 Alert Rules

### Application Alerts (3 rules)
1. **HighErrorRate** - >5% errors for 5 minutes
2. **ApplicationDown** - No metrics for 2 minutes
3. **HighResponseTime** - P95 latency >500ms

### Container Alerts (4 rules)
1. **HighContainerCPUUsage** - >80% CPU for 5 minutes
2. **HighContainerMemoryUsage** - >75% memory for 5 minutes
3. **ContainerRestartDetected** - Restart count increased
4. **HighContainerDiskUsage** - >85% filesystem

### Host Alerts (3 rules)
1. **HighHostCPUUsage** - >85% CPU for 5 minutes
2. **HighHostMemoryUsage** - >85% memory for 5 minutes
3. **LowDiskSpace** - <10% remaining

### Infrastructure Alerts (3 rules)
1. **PrometheusDown** - Prometheus offline
2. **AlertmanagerDown** - Alertmanager offline
3. **CadvisorDown** - cAdvisor offline

---

## 🎓 Learning Resources

### Prometheus
- Documentation: https://prometheus.io/docs/
- PromQL Guide: https://prometheus.io/docs/prometheus/latest/querying/basics/
- Video Tutorials: https://prometheus.io/docs/tutorials/

### Grafana
- Official Docs: https://grafana.com/docs/
- Dashboard Library: https://grafana.com/grafana/dashboards/
- Tutorials: https://grafana.com/tutorials/

### Docker
- Documentation: https://docs.docker.com/
- Docker Compose: https://docs.docker.com/compose/
- Best Practices: https://docs.docker.com/develop/dev-best-practices/

### Alerting
- Prometheus Alerting: https://prometheus.io/docs/alerting/latest/
- Alertmanager: https://prometheus.io/docs/alerting/latest/alertmanager/
- Alert Management: https://cloud.google.com/monitoring/alerts

### Monitoring
- SRE Workbook: https://sre.google/workbook/
- Four Golden Signals: https://sre.google/sre-book/monitoring-distributed-systems/
- Prometheus Patterns: https://promlabs.com/blog/

---

## 💡 Tips & Best Practices

### Performance
- ⚡ Increase scrape interval for less critical metrics
- ⚡ Use recording rules for expensive queries
- ⚡ Reduce cardinality (fewer unique label combinations)
- ⚡ Increase Prometheus memory for high-volume metrics

### Security
- 🔒 Change default Grafana password: `admin123`
- 🔒 Use reverse proxy (nginx) for external access
- 🔒 Enable authentication for Prometheus API
- 🔒 Use TLS/HTTPS for all external connections
- 🔒 Restrict Alertmanager API access

### Reliability
- 📌 Regular backups of Prometheus data
- 📌 Multiple alert notification channels
- 📌 Dashboard templating for consistency
- 📌 Alert runbooks (document what to do)
- 📌 Test incident response procedures

### Scalability
- 📈 Use Prometheus federation for multi-instance
- 📈 Implement remote storage (S3, InfluxDB)
- 📈 Use load balancer for Grafana
- 📈 Horizontal scaling of application
- 📈 Separate metrics by service/environment

---

## 🆘 Help & Support

### Check These First
1. **TROUBLESHOOTING.md** - 12+ common issues with solutions
2. **README.md** → Troubleshooting section
3. **Log files** - `docker-compose logs <service>`
4. **Service health** - `docker-compose ps`

### Debug Commands
```bash
# View all logs
docker-compose logs --timestamps

# Check specific service
docker-compose logs monitoring-app

# Test connectivity
docker exec monitoring-prometheus ping app

# Query API
curl http://localhost:9090/api/v1/targets
curl http://localhost:9093/api/v1/alerts

# Execute in container
docker exec monitoring-app ps aux
```

### Common Issues
| Issue | Solution |
|-------|----------|
| Port already in use | Change port in docker-compose.yml |
| Services don't start | Run `docker-compose logs` to see errors |
| No metrics | Check Prometheus targets at http://localhost:9090/targets |
| Alerts not firing | Verify alert rule: http://localhost:9090/alerts |
| Grafana no data | Ensure time range is recent, check Prometheus connectivity |

---

## ✅ Project Checklist

### Initial Setup
- [ ] Docker Desktop installed and running
- [ ] Project files downloaded
- [ ] Prerequisites verified
- [ ] Run `docker-compose up -d`

### Verification
- [ ] All 6 services healthy: `docker-compose ps`
- [ ] Application responds: `curl http://localhost:3000`
- [ ] Prometheus targets active: http://localhost:9090/targets
- [ ] Grafana loads: http://localhost:3001

### First Dashboard
- [ ] Create dashboard in Grafana
- [ ] Add request rate panel
- [ ] Generate traffic: `curl http://localhost:3000`
- [ ] Watch metrics appear

### Testing Alerts
- [ ] Trigger error: `curl http://localhost:3000/error?error_rate=100`
- [ ] Wait 5 minutes for alert
- [ ] Verify alert in Alertmanager: http://localhost:9093

---

## 📝 Notes

### For Production Use
- Change Grafana default password
- Enable HTTPS/TLS
- Implement authentication
- Configure persistent backups
- Set up high availability
- Monitor the monitoring stack itself
- Document runbooks for each alert
- Test incident response procedures

### Customization Ideas
- Add custom application metrics
- Create service-specific dashboards
- Integrate with your incident management system
- Add custom alert channels (PagerDuty, Slack, etc.)
- Implement SLO/SLI tracking
- Create capacity planning dashboards

---

## 📞 Quick Reference

### Essential Commands
```bash
# Start
docker-compose up -d

# Stop
docker-compose stop

# View status
docker-compose ps

# See logs
docker-compose logs -f

# Rebuild
docker-compose build --no-cache

# Clean everything
docker-compose down -v
```

### Essential URLs
```
Grafana:      http://localhost:3001  (admin/admin123)
Prometheus:   http://localhost:9090
Alertmanager: http://localhost:9093
Application:  http://localhost:3000
```

### Important Files
- `docker-compose.yml` - Service config
- `prometheus/prometheus.yml` - Metric collection
- `prometheus/alerts.yml` - Alert definitions
- `alertmanager/alertmanager.yml` - Alert routing

---

## 📄 License

MIT License - Feel free to use, modify, and distribute.

---

**Version**: 1.0.0  
**Created**: 2026-04-08  
**Last Updated**: 2026-04-08  

**Start with**: README.md → QUICK_START.md → Your environment → Go!
