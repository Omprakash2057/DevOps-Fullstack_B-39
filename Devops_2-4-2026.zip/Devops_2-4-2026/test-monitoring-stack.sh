#!/bin/bash
# Monitoring Stack Testing & Demonstration Script
# This script helps test and demonstrate the monitoring stack

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Helper functions
log_info() { echo -e "${BLUE}[INFO]${NC} $1"; }
log_success() { echo -e "${GREEN}[SUCCESS]${NC} $1"; }
log_warning() { echo -e "${YELLOW}[WARNING]${NC} $1"; }
log_error() { echo -e "${RED}[ERROR]${NC} $1"; }

# Check if services are running
check_services() {
    log_info "Checking service health..."
    docker-compose ps
    echo
}

# Test 1: Verify metrics are being collected
test_metrics_collection() {
    log_info "TEST 1: Verifying metrics collection..."
    
    # Check Prometheus targets
    log_info "Checking Prometheus targets..."
    response=$(curl -s http://localhost:9090/api/v1/targets)
    active=$(echo "$response" | jq '.data.activeTargets | length')
    log_success "Active Prometheus targets: $active"
    
    # Check application metrics
    log_info "Checking application metrics..."
    app_metrics=$(curl -s http://localhost:3000/metrics | wc -l)
    log_success "Application metrics lines: $app_metrics"
    
    # Check cAdvisor metrics
    log_info "Checking cAdvisor metrics..."
    cadvisor_metrics=$(curl -s http://localhost:8080/metrics | grep -c "^container_")
    log_success "cAdvisor container metrics: $cadvisor_metrics"
    
    echo
}

# Test 2: Generate application traffic
test_normal_traffic() {
    log_info "TEST 2: Generating normal traffic..."
    log_info "Sending 100 requests to application..."
    
    for i in {1..100}; do
        curl -s http://localhost:3000/ > /dev/null &
        if [ $((i % 20)) -eq 0 ]; then
            log_info "Progress: $i/100 requests sent"
        fi
    done
    
    wait
    log_success "Normal traffic generation complete"
    log_info "Monitor at: http://localhost:3001/d/app-monitoring (refresh dashboard)"
    echo
}

# Test 3: Trigger application errors
test_error_rate() {
    log_info "TEST 3: Triggering application errors..."
    log_warning "This will generate errors for 30 seconds"
    log_info "Alert 'HighErrorRate' should fire after 5 minutes"
    
    for i in {1..100}; do
        curl -s "http://localhost:3000/error?error_rate=100&error_type=internal" > /dev/null &
    done
    
    wait
    log_success "Error simulation complete"
    log_info "Check Prometheus alerts at: http://localhost:9090/alerts"
    log_info "Check Alertmanager at: http://localhost:9093"
    echo
}

# Test 4: CPU stress test
test_cpu_stress() {
    log_info "TEST 4: CPU stress test..."
    log_warning "This will stress the system for 120 seconds"
    
    # Check if stress-ng is available
    if ! command -v stress-ng &> /dev/null; then
        log_warning "stress-ng not installed. Using Docker stress instead."
        
        docker run -d --name stress-cpu-test \
            --cpus 1 \
            --memory 256m \
            progrium/stress \
            --cpu 1 \
            --timeout 120s > /dev/null
        
        log_success "CPU stress test started in container"
        log_info "Waiting for alert trigger (5 minutes)..."
        sleep 120
        
        docker rm -f stress-cpu-test > /dev/null
        log_success "CPU stress test stopped"
    else
        stress-ng --cpu 1 --timeout 120s &
        wait
        log_success "CPU stress test completed"
    fi
    
    echo
}

# Test 5: Container restart simulation
test_container_restart() {
    log_info "TEST 5: Container restart simulation..."
    log_warning "Application will be stopped and restarted"
    
    log_info "Current application status:"
    docker inspect monitoring-app --format='{{.State.StartedAt}} | Restarts: {{.RestartCount}}'
    
    log_info "Killing container in 5 seconds..."
    sleep 5
    docker kill monitoring-app
    
    log_info "Container killed. Docker will restart it automatically..."
    log_warning "Alert 'ContainerRestartDetected' should fire within 1 minute"
    
    sleep 10
    log_info "Waiting for container to restart..."
    sleep 30
    
    log_success "Container restart status:"
    docker inspect monitoring-app --format='{{.State.StartedAt}} | Restarts: {{.RestartCount}}'
    
    echo
}

# Test 6: Check alert status
test_alert_status() {
    log_info "TEST 6: Checking alert status..."
    
    log_info "Alert status from Prometheus:"
    prometheus_alerts=$(curl -s http://localhost:9090/api/v1/alerts | jq '.data.alerts | length')
    log_success "Total alerts: $prometheus_alerts"
    
    log_info "Firing alerts:"
    curl -s http://localhost:9090/api/v1/alerts | jq '.data.alerts[] | select(.state=="firing") | {alertname, state, labels}' | head -50
    
    log_info "Alert summary from Alertmanager:"
    am_alerts=$(curl -s http://localhost:9093/api/v1/alerts | jq '.[0].groupLabels' | head -20)
    log_success "Alertmanager status: $am_alerts"
    
    echo
}

# Test 7: Memory usage test
test_memory_usage() {
    log_info "TEST 7: Memory usage test..."
    
    log_info "Current memory metrics:"
    curl -s http://localhost:9090/api/v1/query?query='container_memory_usage_bytes{name="monitoring-app"}' | \
        jq '.data.result[0].value[1]' | \
        awk '{printf "Application memory: %.2f MB\n", $1/(1024*1024)}'
    
    echo
}

# Display service URLs
display_urls() {
    echo
    log_info "Service URLs:"
    echo
    echo -e "  ${BLUE}Application${NC}      → http://localhost:3000"
    echo -e "  ${BLUE}Prometheus${NC}       → http://localhost:9090"
    echo -e "  ${BLUE}Alertmanager${NC}     → http://localhost:9093"
    echo -e "  ${BLUE}Grafana${NC}          → http://localhost:3001 (admin/admin123)"
    echo -e "  ${BLUE}cAdvisor${NC}         → http://localhost:8080"
    echo -e "  ${BLUE}Node Exporter${NC}    → http://localhost:9100/metrics"
    echo
}

# Main menu
show_menu() {
    echo
    echo -e "${BLUE}╔════════════════════════════════════════════════╗${NC}"
    echo -e "${BLUE}║    MONITORING STACK - TESTING SUITE           ║${NC}"
    echo -e "${BLUE}╚════════════════════════════════════════════════╝${NC}"
    echo
    echo "1) Check service health"
    echo "2) Test metrics collection"
    echo "3) Generate normal traffic"
    echo "4) Trigger application errors"
    echo "5) CPU stress test"
    echo "6) Container restart simulation"
    echo "7) Check alert status"
    echo "8) Memory usage test"
    echo "9) Display service URLs"
    echo "10) Run all tests (automated)"
    echo "11) Exit"
    echo
}

# Run all tests
run_all_tests() {
    log_info "Running all tests in sequence..."
    
    check_services
    test_metrics_collection
    test_normal_traffic
    test_error_rate
    
    log_info "Waiting 5 minutes for alerts to fire..."
    for i in {300..1..-1}; do
        echo -ne "\rTime remaining: $(printf "%02d:%02d" $((i/60)) $((i%60)))"
        sleep 1
    done
    echo
    
    test_alert_status
    log_success "All automated tests completed!"
}

# Main script
if [ "$#" -eq 0 ]; then
    # Interactive mode
    while true; do
        show_menu
        read -p "Select option (1-11): " choice
        
        case $choice in
            1) check_services ;;
            2) test_metrics_collection ;;
            3) test_normal_traffic ;;
            4) test_error_rate ;;
            5) test_cpu_stress ;;
            6) test_container_restart ;;
            7) test_alert_status ;;
            8) test_memory_usage ;;
            9) display_urls ;;
            10) run_all_tests ;;
            11) log_info "Exiting..."; exit 0 ;;
            *) log_error "Invalid option" ;;
        esac
    done
else
    # Command-line mode
    case $1 in
        all) run_all_tests ;;
        health) check_services ;;
        metrics) test_metrics_collection ;;
        traffic) test_normal_traffic ;;
        errors) test_error_rate ;;
        cpu) test_cpu_stress ;;
        restart) test_container_restart ;;
        alerts) test_alert_status ;;
        memory) test_memory_usage ;;
        urls) display_urls ;;
        *) echo "Usage: $0 {all|health|metrics|traffic|errors|cpu|restart|alerts|memory|urls}"; exit 1 ;;
    esac
fi
