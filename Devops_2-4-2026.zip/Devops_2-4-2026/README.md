# Complete Monitoring and Alerting System
**Production-Ready Docker Monitoring Stack with Prometheus, cAdvisor, Grafana, and Alertmanager**

---

## 📋 Table of Contents

1. [Architecture Overview](#architecture-overview)
2. [Components](#components)
3. [Prerequisites](#prerequisites)
4. [Quick Start](#quick-start)
5. [Configuration Details](#configuration-details)
6. [Testing & Demonstration](#testing--demonstration)
7. [Grafana Dashboard Setup](#grafana-dashboard-setup)
8. [Alerting Setup](#alerting-setup)
9. [Troubleshooting](#troubleshooting)
10. [Production Considerations](#production-considerations)

---

## 🏗️ Architecture Overview

```
┌─────────────────────────────────────────────────────────────┐
│                     MONITORING STACK                        │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  ┌──────────────┐        ┌──────────────┐                  │
│  │  Web App     │        │  cAdvisor    │                  │
│  │  (Node.js)   │        │  Container   │                  │
│  │  :3000       │        │  Metrics     │                  │
│  └──────┬───────┘        │  :8080       │                  │
│         │                └──────┬───────┘                   │
│         │ /metrics               │                          │
│         │ (prometheus format)    │                          │
│         │                        │                          │
│  ┌──────▼────────────────────────▼──────┐                  │
│  │                                      │                  │
│  │        PROMETHEUS (Metrics DB)       │                  │
│  │        Port: 9090                    │                  │
│  │        Scrapes every 15s             │                  │
│  │                                      │                  │
│  └──────┬──────────────┬────────────────┘                  │
│         │              │                                   │
│  ┌──────▼──────┐  ┌───▼───────────┐  ┌─────────────┐      │
│  │ ALERTMANAGER│  │   GRAFANA     │  │ Node Export │      │
│  │ :9093       │  │   :3001       │  │   :9100     │      │
│  │ - Routes    │  │   Dashboards  │  │ Host metrics│      │
│  │ - Channels  │  │   Visuals     │  └─────────────┘      │
│  └──────┬──────┘  └───────────────┘                        │
│         │                                                  │
│  ┌──────▼──────────────┐                                  │
│  │ Alert Channels      │                                  │
│  │ - Console/Webhook   │                                  │
│  │ - Email (optional)  │                                  │
│  │ - Slack (optional)  │                                  │
│  └─────────────────────┘                                  │
└─────────────────────────────────────────────────────────────┘
```

---

## 📦 Components

### 1. **Web Application (Node.js)**
- **Container**: `monitoring-app:3000`
- **Purpose**: Demo application with synthetic metrics
- **Endpoints**:
  - `GET /` → Success response with app info
  - `GET /health` → Health check (used by Docker)
  - `GET /metrics` → Prometheus metrics (scraped by Prometheus)
  - `GET /error` → Simulates application errors (for alert testing)
  - Query params: `?error_rate=80&error_type=database`

### 2. **Prometheus**
- **Container**: `monitoring-prometheus:9090`
- **Purpose**: Metrics collection and alerting engine
- **Features**:
  - Scrapes metrics from app, cAdvisor, Node Exporter
  - Stores time-series data (15 days retention)
  - Evaluates alert rules every 15 seconds
  - Web UI for exploring metrics

### 3. **cAdvisor (Container Advisor)**
- **Container**: `monitoring-cadvisor:8080`
- **Purpose**: Container-level metrics collection
- **Metrics**:
  - CPU usage per container
  - Memory consumption
  - Filesystem performance
  - Network I/O
  - Container restart counts

### 4. **Node Exporter**
- **Container**: `monitoring-node-exporter:9100`
- **Purpose**: Host system metrics
- **Metrics**:
  - Host CPU, memory, disk utilization
  - Network interface statistics
  - Process-level metrics
  - System load average

### 5. **Alertmanager**
- **Container**: `monitoring-alertmanager:9093`
- **Purpose**: Alert notification and routing
- **Features**:
  - Groups similar alerts
  - Routes to configured channels
  - Handles alert acknowledgment
  - Inhibition rules for dependent alerts

### 6. **Grafana**
- **Container**: `monitoring-grafana:3001`
- **Purpose**: Visualization and dashboarding
- **Credentials**: `admin` / `admin123`
- **Features**:
  - Real-time dashboards
  - Alert integration
  - Flexible querying
  - Export/embed capabilities

---

## 🚀 Prerequisites

### System Requirements
- **Docker**: 20.10+
- **Docker Compose**: 1.29+
- **Disk Space**: 5GB (for metrics storage)
- **Memory**: 4GB RAM (2GB minimum)
- **OS**: Linux, macOS, or Windows with WSL2

### Installation

#### Windows (WSL2)
```powershell
# Install Docker Desktop for Windows
# Ensure WSL2 is enabled in Docker settings

# Clone or download the project
cd Devops_2-4-2026
```

#### Linux/macOS
```bash
# Ensure Docker daemon is running
sudo systemctl start docker

# Navigate to project
cd Devops_2-4-2026
```

---

## ⚡ Quick Start

### 1. **Build and Start the Stack**

```bash
# Navigate to project directory
cd c:\Users\malle\OneDrive\Desktop\Devops2026\Devops_2-4-2026

# Build images (first time only)
docker-compose build

# Start all services
docker-compose up -d

# Verify all services are running
docker-compose ps
```

**Expected Output:**
```
NAME                     STATUS
monitoring-app           Up (healthy)
monitoring-prometheus    Up (healthy)
monitoring-cadvisor      Up (healthy)
monitoring-node-exporter Up
monitoring-alertmanager  Up
monitoring-grafana       Up (healthy)
```

### 2. **Access the Services**

| Service | URL | Purpose |
|---------|-----|---------|
| Application | http://localhost:3000 | Web app interface |
| Prometheus | http://localhost:9090 | Metrics query UI |
| Alertmanager | http://localhost:9093 | Alert management |
| **Grafana** | **http://localhost:3001** | **Dashboards (main)** |
| cAdvisor | http://localhost:8080 | Container metrics |
| Node Exporter | http://localhost:9100/metrics | System metrics |

### 3. **Verify Metrics are Being Collected**

```bash
# Check if Prometheus is scraping targets
curl http://localhost:9090/api/v1/targets

# Check application metrics
curl http://localhost:3000/metrics | head -20

# Check cAdvisor metrics
curl http://localhost:8080/metrics | grep container_cpu

# Check Node Exporter metrics
curl http://localhost:9100/metrics | grep node_
```

### 4. **Stop the Stack**

```bash
# Stop all services (keep volumes)
docker-compose stop

# Stop and remove containers (keep volumes)
docker-compose down

# Stop and remove everything (including volumes)
docker-compose down -v
```

---

## ⚙️ Configuration Details

### Application Configuration (`app/server.js`)

#### Custom Metrics Exposed:
- `http_request_duration_ms` - Response time histogram
- `http_requests_total` - Request counter
- `application_errors_total` - Error counter
- `error_simulation_enabled` - Feature flag gauge

#### Features:
- Structured JSON logging to stdout
- Request timing and status tracking
- Error simulation for alert testing
- Health check endpoints
- Prometheus `/metrics` endpoint

### Prometheus Configuration (`prometheus/prometheus.yml`)

#### Scrape Jobs:
1. **Prometheus (Self)**: `localhost:9090` → Monitors itself
2. **Application**: `app:3000/metrics` → 15s interval
3. **cAdvisor**: `cadvisor:8080` → Container metrics
4. **Node Exporter**: `node-exporter:9100` → Host metrics

#### Retention:
- Data retention: 15 days
- Evaluation interval: 15 seconds
- Scrape timeout: 10 seconds

### Alert Configuration (`prometheus/alerts.yml`)

#### Alert Groups:

**Application Alerts:**
- `HighErrorRate` - >5% errors for 5 minutes (WARNING)
- `ApplicationDown` - No metrics for 2 minutes (CRITICAL)
- `HighResponseTime` - P95 latency >500ms (WARNING)

**Container Alerts:**
- `HighContainerCPUUsage` - >80% CPU for 5 minutes (WARNING)
- `HighContainerMemoryUsage` - >75% memory for 5 minutes (WARNING)
- `ContainerRestartDetected` - Restart detected (CRITICAL)
- `HighContainerDiskUsage` - >85% filesystem (WARNING)

**Host Alerts:**
- `HighHostCPUUsage` - >85% CPU (WARNING)
- `HighHostMemoryUsage` - >85% memory (WARNING)
- `LowDiskSpace` - <10% available (CRITICAL)
- `NodeExporterDown` - Exporter offline (WARNING)

**Monitoring Infrastructure:**
- `PrometheusDown` - Prometheus offline (CRITICAL)
- `AlertmanagerDown` - Alertmanager offline (CRITICAL)
- `CadvisorDown` - cAdvisor offline (WARNING)

### Alertmanager Configuration (`alertmanager/alertmanager.yml`)

#### Routing Hierarchy:
```
Root (all alerts)
│
├─ Critical severity
│  └─ Route immediately (group_wait: 0s)
│
├─ Warning severity
│  └─ Route with 30s delay (batch similar)
│
├─ Info severity
│  └─ Send to /dev/null (suppress)
│
└─ Service-specific rules
   └─ Application, Host, Infrastructure
```

#### Channels Configured:
- **Console**: Local webhook (default, for demo)
- **Slack**: Optional (requires webhook URL)
- **Email**: Optional (requires SMTP)
- **PagerDuty**: Optional (requires integration key)

---

## 🧪 Testing & Demonstration

### Test 1: Generate Application Traffic

```bash
# Generate normal traffic
for i in {1..100}; do
  curl http://localhost:3000/ &
done

# Watch in Grafana dashboard
# Go to http://localhost:3001
# You should see requests/sec increasing
```

### Test 2: Trigger Application Errors

```bash
# Simulate 100% error rate for 5 minutes
for i in {1..50}; do
  curl "http://localhost:3000/error?error_rate=100&error_type=internal" &
done

# Check Prometheus:
# Query: rate(application_errors_total[5m])
# Expected: Values > 0

# Check Alertmanager (http://localhost:9093):
# Alert "HighErrorRate" should fire after 5 minutes
```

### Test 3: Container CPU Stress Test

```bash
# Start stress container
docker run -d --name stress-test \
  --cpus 1 \
  alpine:latest \
  stress --cpu 1 --timeout 600s &

# Monitor in Grafana
# Query: container_cpu_usage_seconds_total for "stress-test"
# Alert "HighContainerCPUUsage" should fire after 5 minutes

# Stop stress test
docker stop stress-test
docker rm stress-test
```

### Test 4: Container Kill/Restart

```bash
# Kill the application container
docker kill monitoring-app

# Observations:
# - Application becomes unreachable
# - Prometheus marks it as "down"
# - Alert "ApplicationDown" fires after 2 minutes
# - cAdvisor shows container_last_seen changes

# Docker automatically restarts it (unless-stopped)
# - Alert resolves after container becomes healthy
# - Container restarts counter increases
```

### Test 5: Memory Usage

```bash
# Generate memory usage in app
# Create a simple memory leak simulation:
curl "http://localhost:3000/error?error_rate=100" &

# Monitor in Prometheus:
# Query: process_resident_memory_bytes{job="application"}

# Check cAdvisor memory metrics:
# Query: container_memory_usage_bytes{name="monitoring-app"}
```

### Test 6: Check Alert Firing

Access Prometheus at http://localhost:9090:
- Click "Alerts" tab
- See status of all alert rules
- Check which are `pending` (will fire soon) or `firing`

---

## 📊 Grafana Dashboard Setup

### Access Grafana

1. Open http://localhost:3001
2. Login: `admin` / `admin123`
3. On first login, you'll see the home dashboard

### Add Prometheus Data Source (Auto-Configured)

The data source should already be configured via `grafana/provisioning/datasources/`.

To verify:
1. Click **Configuration** → **Data Sources**
2. Should see `Prometheus` (http://prometheus:9090)
3. Click **Test** to verify connectivity

### Create Custom Dashboards

#### Dashboard 1: Application Monitoring

1. Click **+** → **Dashboard** → **New Panel**
2. Configure Panel:

**Panel 1: Request Rate**
```promql
rate(http_requests_total[5m])
```
- Visualization: Graph
- Legend: Show values

**Panel 2: Error Rate**
```promql
rate(http_requests_total{status_code=~"5.."}[5m]) / rate(http_requests_total[5m])
```
- Visualization: Graph
- Unit: percent (0-100)

**Panel 3: Response Time (p95)**
```promql
histogram_quantile(0.95, sum(rate(http_request_duration_ms_bucket[5m])) by (le))
```
- Visualization: Stat
- Unit: milliseconds

#### Dashboard 2: Container Metrics

**Panel 1: CPU Usage per Container**
```promql
sum(rate(container_cpu_usage_seconds_total[5m])) by (name) * 100
```
- Visualization: Graph
- Unit: percent

**Panel 2: Memory Usage**
```promql
container_memory_usage_bytes{name!=""} / 1024 / 1024
```
- Visualization: Graph
- Unit: bytes (MB)

**Panel 3: Container Restarts**
```promql
container_last_seen{name!=""}
```
- Visualization: Table
- Columns: Container name, Last seen

#### Dashboard 3: Host Metrics

**Panel 1: CPU Usage**
```promql
(1 - avg(rate(node_cpu_seconds_total{mode="idle"}[5m]))) * 100
```

**Panel 2: Memory Utilization**
```promql
(node_memory_MemTotal_bytes - node_memory_MemAvailable_bytes) / node_memory_MemTotal_bytes * 100
```

**Panel 3: Disk Free**
```promql
node_filesystem_avail_bytes / node_filesystem_size_bytes * 100
```

### Save Dashboard

1. Click **Save** button
2. Enter dashboard name
3. Click **Save**
4. Dashboard now appears in home

---

## 🔔 Alerting Setup

### How Alerts Work

```
Application
    ↓
Prometheus scrapes metrics every 15s
    ↓
Evaluates alert rules (PromQL expressions)
    ↓
Alert condition met for 'for' duration (5m, 2m, etc.)
    ↓
Alert transitions to "firing"
    ↓
Alertmanager receives alert
    ↓
Groups similar alerts (group_by labels)
    ↓
Routes to receivers based on matching rules
    ↓
Notification sent (console, email, Slack, etc.)
```

### Testing Alerts

#### Check Alert Status
```bash
# In Prometheus UI (http://localhost:9090/alerts):
# See all alert rules and their status (pending/firing/inactive)

# Query alert expressions:
query = "HighErrorRate"
# Shows which instances match the alert condition
```

#### View Alert in Alertmanager
```bash
# Access http://localhost:9093
# See grouped alerts
# Each group shows:
#   - Alert name
#   - Labels
#   - Annotations
#   - Firing duration
#   - Graphs
```

#### Generate Sample Alert
```bash
# Terminal 1: Trigger errors
for i in {1..100}; do
  curl "http://localhost:3000/error?error_rate=100" &
done

# Terminal 2: Monitor Prometheus alerts
watch -n 1 'curl -s http://localhost:9090/api/v1/alerts | jq .data.alerts'

# After 5 minutes:
# "HighErrorRate" alert should appear in Alertmanager
```

### Configure Alert Notifications

#### Option 1: Console Logging (Demo - Already Configured)
Alerts appear in `docker logs monitoring-alertmanager`

#### Option 2: Slack (Requires Webhook)

1. Create Slack webhook:
   - Go to https://api.slack.com/apps
   - Create new app
   - Enable "Incoming Webhooks"
   - Create webhook URL

2. Update `alertmanager/alertmanager.yml`:
   ```yaml
   - name: 'slack'
     slack_configs:
       - api_url: 'YOUR_SLACK_WEBHOOK_URL'
         channel: '#alerts'
   ```

3. Reload config:
   ```bash
   docker-compose restart alertmanager
   ```

#### Option 3: Email (Requires SMTP)

1. Get SMTP credentials (Gmail, SendGrid, etc.)

2. Update `alertmanager/alertmanager.yml` global section:
   ```yaml
   global:
     smtp_smarthost: 'smtp.gmail.com:587'
     smtp_auth_username: 'your-email@gmail.com'
     smtp_auth_password: 'your-app-password'
     smtp_require_tls: true
   ```

3. Add email receiver:
   ```yaml
   - name: 'email'
     email_configs:
       - to: 'ops-team@example.com'
   ```

4. Update routing to use email receiver

5. Reload alertmanager

---

## 🐛 Troubleshooting

### All Services Not Starting

```bash
# Check docker daemon
docker ps

# View compose logs
docker-compose logs

# Rebuild from scratch
docker-compose down -v
docker-compose build --no-cache
docker-compose up -d
```

### Prometheus Not Scraping Targets

```bash
# Check Prometheus targets
curl http://localhost:9090/api/v1/targets | jq .

# Common issues:
# - Container DNS resolution: Use service name (app, not app.monitoring-network)
# - Network connectivity: Verify network bridges
# - Port exposure: Check container ports

# Check Prometheus logs
docker logs monitoring-prometheus
```

### Alerts Not Firing

```bash
# 1. Verify alert rules loaded
curl http://localhost:9090/api/v1/rules

# 2. Manually test PromQL expression
# In Prometheus UI, execute alert expression
# Example: (sum(rate(http_requests_total{status_code=~"5.."}[5m]))/sum(rate(http_requests_total[5m]))) > 0.05

# 3. Check alert status
curl http://localhost:9090/api/v1/alerts | jq .

# 4. Trigger condition manually
docker exec monitoring-app bash -c "for i in {1..100}; do curl -s http://localhost:3000/error; done"

# 5. Wait for 'for' duration (e.g., 5m)

# 6. Check Alertmanager
curl http://localhost:9093/api/v1/alerts | jq .
```

### Grafana Not Showing Data

```bash
# 1. Verify Prometheus connectivity
# In Grafana: Configuration → Data Sources → Prometheus → Test

# 2. Check time range
# Select appropriate range in dashboard (last hour, last 24h, etc.)

# 3. Manual metric query
# In Data Source: query "up" (should return metrics from all jobs)

# 4. Check Prometheus has data
curl http://localhost:9090/api/v1/query?query=up
```

### High Memory Usage

```bash
# Prometheus stores all metrics in memory
# Reduce retention or disable unused collectors

# In prometheus/prometheus.yml:
--storage.tsdb.retention.time=7d  # Reduce from 15d
```

### Container Network Issues

```bash
# Verify network bridge
docker network ls
docker network inspect devops_2-4-2026_monitoring-network

# Check container networking
docker exec monitoring-app ping prometheus

# If DNS fails, rebuild
docker-compose down
docker-compose up -d
```

---

## 🚀 Production Considerations

### Security Enhancements

1. **Disable Prometheus Lifecycle API**
   ```yaml
   # prometheus/prometheus.yml
   - "--web.enable-lifecycle"  # Remove this
   ```

2. **Use Strong Grafana Credentials**
   ```yaml
   # docker-compose.yml
   GF_SECURITY_ADMIN_PASSWORD: ${ADMIN_PASSWORD}  # Use env var
   ```

3. **Enable Authentication**
   - Prometheus: Use reverse proxy (nginx) with auth
   - Grafana: Use OAuth2 (GitHub, Google, LDAP)
   - Alertmanager: Restricting API access

4. **Network Isolation**
   ```yaml
   # Create internal network
   networks:
     monitoring-network:
       internal: true  # No external access
   ```

5. **Persistent Storage**
   - Use volume backups
   - Implement backup strategy
   - Test recovery procedures

### Scaling Considerations

1. **Federation** (Multiple Prometheus)
   ```yaml
   # primary prometheus scrapes secondary
   - job_name: 'federate'
     scrape_interval: 15s
     honor_labels: true
     metrics_path: '/federate'
     params:
       'match[]':
         - '{job="prometheus"}'
     static_configs:
       - targets:
           - 'secondary-prometheus:9090'
   ```

2. **Remote Storage**
   ```yaml
   # Store metrics in S3, InfluxDB, or similar
   remote_write:
     - url: "http://storage-adapter:9009/write"
   ```

3. **High Availability**
   - Run multiple Prometheus instances
   - Use load balancer for Grafana
   - Replicate Alertmanager state

4. **Performance Optimization**
   - Use recording rules for expensive queries
   - Increase scrape intervals for less critical metrics
   - Implement metric relabeling to drop unnecessary metrics

### Monitoring the Monitoring Stack

```promql
# Monitor Prometheus itself
up{job="prometheus"}  # Should be 1

# Check scrape duration
rate(prometheus_tsdb_symbol_table_size_bytes[5m])

# Alert on Prometheus lag
increase(prometheus_tsdb_compactions_total[1h]) == 0
```

### Data Retention Strategy

```yaml
# Keep different metrics for different periods
# Critical metrics: 30 days
# Warning metrics: 15 days
# Debug metrics: 7 days

# Implement via labels and retention policies:
metric_relabel_configs:
  - source_labels: [__name__]
    regex: 'debug_.*'
    target_label: '__tmp_retention'
    replacement: '7d'
```

---

## 📚 Additional Resources

### Prometheus Documentation
- PromQL: https://prometheus.io/docs/prometheus/latest/querying/basics/
- Alerting: https://prometheus.io/docs/alerting/latest/overview/
- Recording Rules: https://prometheus.io/docs/prometheus/latest/configuration/recording_rules/

### Grafana Documentation
- Dashboards: https://grafana.com/docs/grafana/latest/dashboards/
- Alerts: https://grafana.com/docs/grafana/latest/alerting/

### Docker Documentation
- Compose: https://docs.docker.com/compose/
- Networks: https://docs.docker.com/network/

### Best Practices
- SRE Workbook: https://sre.google/workbook/monitoring-distributed-systems/
- Golden Signals: Latency, Traffic, Errors, Saturation

---

## 🎯 Next Steps

1. **Explore Prometheus**: Run PromQL queries
   ```promql
   up
   rate(http_requests_total[5m])
   node_cpu_seconds_total
   ```

2. **Create Dashboards**: Build custom visualizations for your metrics

3. **Define SLOs**: Set Service Level Objectives based on metrics

4. **Test Incident Response**: Simulate failures and test alert procedures

5. **Implement Runbooks**: Create response playbooks for each alert

6. **Migrate to Production**: Apply security hardening and scaling patterns

---

## 📞 Support & Debugging

### Enable Debug Logging

```bash
# Prometheus debug logs
docker-compose logs -f monitoring-prometheus | grep -i error

# Alertmanager debug logs
docker-compose logs -f monitoring-alertmanager | grep -i error

# Application logs
docker-compose logs -f monitoring-app | jq .
```

### Performance Monitoring

```bash
# Check Docker resource usage
docker stats

# Check system resources
docker exec monitoring-prometheus free -h
docker exec monitoring-prometheus df -h
```

---

## ✅ Validation Checklist

Before considering the setup complete, verify:

- [ ] All 6 services are running and healthy
- [ ] Prometheus has scraped at least one metric
- [ ] Grafana dashboard loads without errors
- [ ] Can create a custom panel with PromQL query
- [ ] Alertmanager receives alerts
- [ ] Application error endpoint triggers alerts
- [ ] Container restart is detected by alerts
- [ ] Logs are accessible via `docker logs`

---

**Author**: DevOps Engineer  
**Version**: 1.0.0  
**Last Updated**: 2026-04-08  
**License**: MIT

---

### Quick Command Reference

```bash
# Start stack
docker-compose up -d

# View logs
docker-compose logs -f

# Stop stack
docker-compose stop

# Remove everything
docker-compose down -v

# Check service health
docker-compose ps

# Execute command in container
docker exec <container-name> <command>

# View resource usage
docker stats

# Scale service
docker-compose up -d --scale app=3

# Rebuild image
docker-compose build --no-cache app

# Access Prometheus
http://localhost:9090

# Access Grafana
http://localhost:3001 (admin/admin123)

# Access Alertmanager
http://localhost:9093

# Access Application
http://localhost:3000
```
