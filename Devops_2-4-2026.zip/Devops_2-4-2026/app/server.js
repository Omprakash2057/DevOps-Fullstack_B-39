/**
 * Simple Node.js Web Application with Prometheus Metrics
 * 
 * This application demonstrates:
 * - Basic HTTP endpoints (/ and /error)
 * - Prometheus metrics collection
 * - Structured logging to stdout
 * - Error simulation for alert testing
 */

const express = require('express');
const prometheus = require('prom-client');

const app = express();
const PORT = process.env.PORT || 3000;

// ============================================================================
// PROMETHEUS METRICS SETUP
// ============================================================================

// Collect default metrics (CPU, memory, etc.)
prometheus.collectDefaultMetrics({ timeout: 5000 });

// Custom metrics for application monitoring
const httpRequestDuration = new prometheus.Histogram({
  name: 'http_request_duration_ms',
  help: 'Duration of HTTP requests in ms',
  labelNames: ['method', 'route', 'status_code'],
  buckets: [0.1, 5, 15, 50, 100, 500]
});

const httpRequestTotal = new prometheus.Counter({
  name: 'http_requests_total',
  help: 'Total number of HTTP requests',
  labelNames: ['method', 'route', 'status_code']
});

const applicationErrors = new prometheus.Counter({
  name: 'application_errors_total',
  help: 'Total number of application errors',
  labelNames: ['endpoint', 'error_type']
});

const errorSimulationCounter = new prometheus.Gauge({
  name: 'error_simulation_enabled',
  help: 'Flag indicating if error simulation is active (1 = enabled, 0 = disabled)',
  labelNames: ['endpoint']
});

// ============================================================================
// MIDDLEWARE: REQUEST TIMING & METRICS
// ============================================================================

app.use((req, res, next) => {
  const start = Date.now();

  // Intercept res.end to capture response status
  const originalEnd = res.end;
  res.end = function (...args) {
    const duration = Date.now() - start;
    const statusCode = res.statusCode;

    httpRequestDuration
      .labels(req.method, req.path, statusCode)
      .observe(duration);

    httpRequestTotal
      .labels(req.method, req.path, statusCode)
      .inc();

    originalEnd.apply(res, args);
  };

  next();
});

// ============================================================================
// LOGGING UTILITY
// ============================================================================

const log = {
  info: (message, meta = {}) => {
    console.log(JSON.stringify({
      timestamp: new Date().toISOString(),
      level: 'INFO',
      message,
      ...meta
    }));
  },
  error: (message, meta = {}) => {
    console.error(JSON.stringify({
      timestamp: new Date().toISOString(),
      level: 'ERROR',
      message,
      ...meta
    }));
  },
  warn: (message, meta = {}) => {
    console.warn(JSON.stringify({
      timestamp: new Date().toISOString(),
      level: 'WARN',
      message,
      ...meta
    }));
  }
};

// ============================================================================
// ROUTES
// ============================================================================

/**
 * Health Check Endpoint
 * Returns 200 OK - Used by Docker to determine container health
 */
app.get('/health', (req, res) => {
  log.info('Health check endpoint called', { endpoint: '/health' });
  res.status(200).json({ status: 'healthy', timestamp: new Date().toISOString() });
});

/**
 * Metrics Endpoint
 * Exposes Prometheus metrics in Prometheus text format
 * Scraped by Prometheus every 15 seconds (can be configured)
 */
app.get('/metrics', (req, res) => {
  res.set('Content-Type', prometheus.register.contentType);
  res.end(prometheus.register.metrics());
});

/**
 * Root Endpoint
 * Returns a simple success response with service information
 */
app.get('/', (req, res) => {
  log.info('Root endpoint called', {
    endpoint: '/',
    service: 'monitoring-demo-app',
    version: '1.0.0'
  });

  res.status(200).json({
    message: 'Welcome to the Monitoring Demo App',
    service: 'monitoring-demo-app',
    version: '1.0.0',
    timestamp: new Date().toISOString(),
    uptime: process.uptime(),
    endpoints: {
      health: '/health',
      metrics: '/metrics',
      error: '/error'
    }
  });
});

/**
 * Error Simulation Endpoint
 * Simulates application errors for testing alerts
 * 
 * Query parameters:
 *   - error_rate: Percentage of requests to fail (0-100, default 50)
 *   - error_type: Type of error - 'timeout', 'validation', 'database', 'internal' (default 'internal')
 * 
 * Examples:
 *   GET /error                          → 50% requests fail with 'internal' error
 *   GET /error?error_rate=80            → 80% requests fail
 *   GET /error?error_type=database      → trigger 'database' errors
 *   GET /error?error_rate=100&error_type=timeout → always timeout errors
 */
app.get('/error', (req, res) => {
  const errorRate = parseInt(req.query.error_rate) || 50;
  const errorType = req.query.error_type || 'internal';
  const shouldError = Math.random() * 100 < errorRate;

  const errorTypes = {
    timeout: {
      code: 504,
      message: 'Gateway Timeout',
      type: 'timeout'
    },
    validation: {
      code: 400,
      message: 'Bad Request - Validation Error',
      type: 'validation_error'
    },
    database: {
      code: 503,
      message: 'Service Unavailable - Database Error',
      type: 'database_error'
    },
    internal: {
      code: 500,
      message: 'Internal Server Error',
      type: 'internal_error'
    }
  };

  if (shouldError) {
    const error = errorTypes[errorType] || errorTypes['internal'];
    
    applicationErrors
      .labels('/error', error.type)
      .inc();

    log.error('Error endpoint triggered - simulating failure', {
      endpoint: '/error',
      error_type: error.type,
      error_rate: errorRate,
      status_code: error.code
    });

    return res.status(error.code).json({
      error: error.message,
      error_type: error.type,
      timestamp: new Date().toISOString(),
      request_id: `req_${Date.now()}`
    });
  }

  log.info('Error endpoint called but request succeeded', {
    endpoint: '/error',
    error_rate: errorRate,
    error_type: errorType,
    status: 'success'
  });

  res.status(200).json({
    message: 'Request succeeded (error simulation did not trigger)',
    error_rate: errorRate,
    error_type: errorType,
    timestamp: new Date().toISOString()
  });
});

/**
 * Readiness Probe
 * Indicates if the application is ready to accept traffic
 */
app.get('/ready', (req, res) => {
  log.info('Readiness probe called', { endpoint: '/ready' });
  res.status(200).json({ ready: true, timestamp: new Date().toISOString() });
});

/**
 * Catch-all 404 handler
 */
app.use((req, res) => {
  log.warn('Unknown endpoint accessed', { endpoint: req.path, method: req.method });
  res.status(404).json({
    error: 'Not Found',
    message: `Endpoint ${req.path} does not exist`,
    available_endpoints: ['/', '/health', '/ready', '/metrics', '/error']
  });
});

// ============================================================================
// ERROR HANDLING
// ============================================================================

process.on('unhandledRejection', (reason, promise) => {
  log.error('Unhandled Rejection at:', {
    promise: promise.toString(),
    reason: reason.toString ? reason.toString() : reason
  });
});

process.on('uncaughtException', (error) => {
  log.error('Uncaught Exception:', {
    message: error.message,
    stack: error.stack
  });
  process.exit(1);
});

// ============================================================================
// SERVER STARTUP
// ============================================================================

app.listen(PORT, () => {
  log.info('Application Started', {
    service: 'monitoring-demo-app',
    port: PORT,
    environment: process.env.NODE_ENV || 'development',
    timestamp: new Date().toISOString(),
    endpoints: {
      root: `http://localhost:${PORT}/`,
      health: `http://localhost:${PORT}/health`,
      metrics: `http://localhost:${PORT}/metrics`,
      error: `http://localhost:${PORT}/error`
    }
  });
});
