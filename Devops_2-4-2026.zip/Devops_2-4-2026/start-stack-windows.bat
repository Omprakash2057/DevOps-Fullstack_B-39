@echo off
REM ============================================================================
REM Monitoring Stack - Windows Batch Script
REM Run monitoring and alerting system on Windows
REM ============================================================================

setlocal enabledelayedexpansion

REM Colors (Windows 10+ supports ANSI if enabled)
REM If colors don't work, they'll be ignored safely

:main
cls
echo.
echo ╔════════════════════════════════════════════════════════════╗
echo ║     MONITORING STACK - Windows Startup Menu               ║
echo ╚════════════════════════════════════════════════════════════╝
echo.
echo 1) Check Docker Desktop status
echo 2) Build application image
echo 3) Start monitoring stack
echo 4) Stop monitoring stack
echo 5) View logs
echo 6) Check service health
echo 7) Rebuild from scratch
echo 8) Open Grafana dashboard
echo 9) Open Prometheus UI
echo 10) Run diagnostics
echo 11) Exit
echo.
set /p choice=Select option (1-11): 

if "%choice%"=="1" goto check_docker
if "%choice%"=="2" goto build
if "%choice%"=="3" goto start
if "%choice%"=="4" goto stop
if "%choice%"=="5" goto logs
if "%choice%"=="6" goto health
if "%choice%"=="7" goto rebuild
if "%choice%"=="8" goto grafana
if "%choice%"=="9" goto prometheus
if "%choice%"=="10" goto diagnostics
if "%choice%"=="11" goto end

echo Invalid option!
timeout /t 2 >nul
goto main

REM ============================================================================
REM Check Docker Desktop status
REM ============================================================================
:check_docker
cls
echo Checking Docker Desktop...
docker ps >nul 2>&1
if %errorlevel% neq 0 (
    echo [ERROR] Docker daemon is not running!
    echo.
    echo Please ensure Docker Desktop is running:
    echo   1. Click Windows Start Menu
    echo   2. Search for "Docker Desktop"
    echo   3. Launch the application
    echo   4. Wait for it to fully initialize
    echo.
) else (
    echo [SUCCESS] Docker daemon is running
    echo.
    docker --version
    echo.
)
pause
goto main

REM ============================================================================
REM Build application image
REM ============================================================================
:build
cls
echo Building monitoring stack images...
echo.
docker-compose build
if %errorlevel% neq 0 (
    echo [ERROR] Build failed!
    pause
    goto main
)
echo [SUCCESS] Build completed!
pause
goto main

REM ============================================================================
REM Start monitoring stack
REM ============================================================================
:start
cls
echo Starting monitoring stack...
echo.
docker-compose up -d
if %errorlevel% neq 0 (
    echo [ERROR] Failed to start services!
    pause
    goto main
)
echo [SUCCESS] Services started!
echo.
echo Waiting for services to initialize...
timeout /t 5 /nobreak
echo.
echo Service status:
docker-compose ps
echo.
echo Services available at:
echo   Grafana:       http://localhost:3001  (admin/admin123^)
echo   Prometheus:    http://localhost:9090
echo   Alertmanager:  http://localhost:9093
echo   Application:   http://localhost:3000
echo.
pause
goto main

REM ============================================================================
REM Stop monitoring stack
REM ============================================================================
:stop
cls
echo Stopping monitoring stack...
echo.
docker-compose stop
if %errorlevel% neq 0 (
    echo [ERROR] Failed to stop services!
    pause
    goto main
)
echo [SUCCESS] Services stopped!
echo.
pause
goto main

REM ============================================================================
REM View logs
REM ============================================================================
:logs
cls
echo Select service to view logs:
echo 1) All services
echo 2) Application
echo 3) Prometheus
echo 4) Grafana
echo 5) Alertmanager
echo 6) Exit logs
echo.
set /p log_choice=Select (1-6): 

if "%log_choice%"=="1" docker-compose logs --tail=100 -f
if "%log_choice%"=="2" docker-compose logs --tail=100 -f monitoring-app
if "%log_choice%"=="3" docker-compose logs --tail=100 -f monitoring-prometheus
if "%log_choice%"=="4" docker-compose logs --tail=100 -f monitoring-grafana
if "%log_choice%"=="5" docker-compose logs --tail=100 -f monitoring-alertmanager

goto main

REM ============================================================================
REM Check service health
REM ============================================================================
:health
cls
echo Service Status:
echo.
docker-compose ps
echo.
echo Checking Prometheus targets...
timeout /t 2 >nul
powershell -Command "curl -s http://localhost:9090/api/v1/targets | ConvertFrom-Json | .data.activeTargets.length" 2>nul
echo.
pause
goto main

REM ============================================================================
REM Rebuild from scratch
REM ============================================================================
:rebuild
cls
echo WARNING: This will delete all data!
echo.
set /p confirm=Type 'yes' to confirm: 
if /i not "%confirm%"=="yes" goto main

echo Stopping services...
docker-compose down -v
echo Building fresh images...
docker-compose build --no-cache
echo Starting services...
docker-compose up -d
echo.
echo [SUCCESS] Rebuild completed!
pause
goto main

REM ============================================================================
REM Open Grafana
REM ============================================================================
:grafana
echo Opening Grafana...
start http://localhost:3001
timeout /t 2 >nul
goto main

REM ============================================================================
REM Open Prometheus
REM ============================================================================
:prometheus
echo Opening Prometheus...
start http://localhost:9090
timeout /t 2 >nul
goto main

REM ============================================================================
REM Run diagnostics
REM ============================================================================
:diagnostics
cls
echo ╔════════════════════════════════════════════════════════════╗
echo ║                  SYSTEM DIAGNOSTICS                       ║
echo ╚════════════════════════════════════════════════════════════╝
echo.

echo [1/8] Docker Version:
docker --version
echo.

echo [2/8] Docker Compose Version:
docker-compose --version
echo.

echo [3/8] Active Containers:
docker ps --format "{{.Names}}"
echo.

echo [4/8] Container Status:
docker-compose ps
echo.

echo [5/8] Network Configuration:
docker network ls | findstr monitoring
echo.

echo [6/8] Disk Usage:
for /f "tokens=*" %%i in ('docker ps --format "{{.Names}}"') do (
    echo %%i:
    docker exec %%i df -h ^| findstr "^/" 2>nul || echo [N/A]
)
echo.

echo [7/8] Resource Usage:
docker stats --no-stream --format "table {{.Container}}\t{{.CPUPerc}}\t{{.MemUsage}}"
echo.

echo [8/8] Service Connectivity Test:
echo Testing Prometheus...
curl -s http://localhost:9090/-/healthy >nul 2>&1 && echo   [OK] Prometheus && goto test_grafana
echo   [FAILED] Prometheus

:test_grafana
echo Testing Grafana...
curl -s http://localhost:3001/api/health >nul 2>&1 && echo   [OK] Grafana && goto test_app
echo   [FAILED] Grafana

:test_app
echo Testing Application...
curl -s http://localhost:3000/ >nul 2>&1 && echo   [OK] Application && goto diagnostics_end
echo   [FAILED] Application

:diagnostics_end
echo.
pause
goto main

REM ============================================================================
REM Exit
REM ============================================================================
:end
cls
echo.
echo Goodbye! Stop services with:
echo   docker-compose stop
echo.
pause
exit /b 0
