# Monitoring Stack - Troubleshooting Guide

Common issues and their solutions

## Issue 1: Services Not Starting

### Symptom
```
docker-compose up fails or services don't start
```

### Solution
```bash
# Check Docker daemon is running
docker ps

# Check logs
docker-compose logs

# Clean rebuild
docker-compose down -v
docker build --no-cache -f Dockerfile -t monitoring-app .
docker-compose build --no-cache

# Start with verbose output
docker-compose -v up
```

---

## Issue 2: Prometheus Not Scraping Targets

### Symptom
- Prometheus shows "Down" for targets
- No metrics available
- Error: "Get http://app:3000/metrics: dial tcp: lookup app: no such host"

### Solution
```bash
# Verify network connectivity
docker exec monitoring-prometheus ping app

# Check DNS resolution
docker exec monitoring-app nslookup prometheus

# Fix: Recreate network
docker network rm devops_2-4-2026_monitoring-network
docker-compose down
docker-compose up -d

# Check target config
curl http://localhost:9090/api/v1/targets | jq .
```

---

## Issue 3: Grafana Not Showing Data

### Symptom
- Dashboard panels show "No data"
- Graph area is empty
- Error: "Data source request failed"

### Solution
```bash
# 1. Verify Prometheus connectivity
# In Grafana UI: Configuration → Data Sources → Prometheus → Test

# 2. Check Prometheus has data
curl http://localhost:9090/api/v1/query?query=up

# 3. Adjust time range
# Select "Last hour" instead of default

# 4. Force refresh
# In dashboard, click refresh button or press F5

# 5. Check query syntax
# Use simpler query like: up (should work)
```

---

## Issue 4: Alerts Not Firing

### Symptom
- Alert condition is met but alert doesn't fire
- Alertmanager shows no alerts
- Prometheus shows 0 firing alerts

### Solution
```bash
# 1. Verify alert rules are loaded
curl http://localhost:9090/api/v1/rules | jq '.data.groups[].rules'

# 2. Test alert condition manually
# In Prometheus UI, run the alert expression
# Should return non-zero values

# 3. Check 'for' duration has been met
# Alert condition must be true for specified duration
# Example: if 'for: 5m', wait 5 minutes

# 4. Trigger alert manually
docker exec monitoring-app bash -c \
  'for i in {1..1000}; do curl -s http://localhost:3000/error?error_rate=100; done'

# 5. Wait and check alert status
curl http://localhost:9090/api/v1/alerts | jq '.data.alerts[] | select(.state=="firing")'
```

---

## Issue 5: High Memory Usage

### Symptom
- Docker reports high memory usage
- Prometheus container consuming multiple GB
- System becomes slow

### Solution
```bash
# 1. Check current usage
docker stats monitoring-prometheus

# 2. Reduce retention period (prometheus.yml)
--storage.tsdb.retention.time=7d  # Change from 15d

# 3. Drop unnecessary metrics
metric_relabel_configs:
  - source_labels: [__name__]
    regex: 'debug_.*'
    action: drop

# 4. Reduce cardinality
# Remove high-cardinality labels in relabel_configs

# 5. Restart Prometheus
docker-compose restart monitoring-prometheus

# 6. Check disk usage
docker exec monitoring-prometheus du -sh /prometheus
```

---

## Issue 6: Container Keeps Restarting

### Symptom
- Container exits immediately
- Status: "Restarting (1) X seconds ago"
- Error in logs about exiting

### Solution
```bash
# View detailed logs
docker logs monitoring-app

# Check for application errors
docker logs -f monitoring-app 2>&1 | grep -i "error\|exception"

# Rebuild image
docker-compose build --no-cache monitoring-app

# Check Dockerfile
# Verify CMD and ENTRYPOINT are correct

# Test locally
docker run -it monitoring-app npm start
```

---

## Issue 7: Port Conflicts

### Symptom
- Error: "port 3000 already allocated"
- Error: "listen tcp :9090: bind: address already in use"

### Solution
```bash
# Find process using port
# Windows:
netstat -ano | findstr :3000
taskkill /PID <PID> /F

# Linux/Mac:
lsof -i :3000
kill -9 <PID>

# Or change port in docker-compose.yml
# ports:
#   - "3002:3000"  # Change 3000 to 3002

# Restart
docker-compose up -d
```

---

## Issue 8: CPU Usage Very High

### Symptom
- One container is at 100% CPU
- System becomes unresponsive
- `docker stats` shows high %CPU

### Solution
```bash
# Identify which container
docker stats --no-stream | sort -k3 -rn | head

# Check logs for errors
docker logs <container_name>

# Reduce metric collection interval
# In prometheus.yml reduce cardinality or metrics

# Check for infinite loops in application
docker exec <container> top -b -n 1

# Restart container
docker-compose restart <container_name>

# Implement resource limits
# docker-compose.yml:
# deploy:
#   resources:
#     limits:
#       cpus: '0.5'
#       memory: 512M
```

---

## Issue 9: Metrics Query Returns "No Data"

### Symptom
- PromQL query shows "no data"
- Expected metric doesn't exist
- Autocomplete doesn't show metric

### Solution
```bash
# 1. Check metric name
# In Prometheus: Use metric autocomplete

# 2. Verify job name in query
# Query should reference correct job: app, cadvisor, etc.

# 3. Test collector is working
curl http://localhost:3000/metrics | grep <metric_name>
curl http://localhost:8080/metrics | grep <metric_name>

# 4. Check scrape happens
# Prometheus UI → Targets → Check scrape times

# 5. Verify label values
# Query: label_values(<metric_name>, <label>)
```

---

## Issue 10: cAdvisor/Node Exporter Not Available

### Symptom
- cAdvisor endpoint shows 502 Bad Gateway
- Node Exporter returns connection refused
- Metrics from cAdvisor missing

### Symptom
```bash
# Check if containers are running
docker-compose ps | grep -E "cadvisor|node-exporter"

# Verify ports are exposed
docker port monitoring-cadvisor
docker port monitoring-node-exporter

# Test connectivity
curl http://localhost:8080/healthz
curl http://localhost:9100/metrics | head

# Check logs
docker logs monitoring-cadvisor
docker logs monitoring-node-exporter

# Restart
docker-compose restart monitoring-cadvisor monitoring-node-exporter
```

---

## Issue 11: Docker Network Issues

### Symptom
- Containers can't communicate: "dial tcp: lookup app: no such host"
- Service resolution fails
- Intermittent connectivity issues

### Solution
```bash
# Check network status
docker network ls
docker network inspect devops_2-4-2026_monitoring-network

# Verify all containers in network
docker network inspect devops_2-4-2026_monitoring-network | jq '.Containers'

# Test DNS from container
docker exec monitoring-prometheus nslookup app

# Recreate network
docker-compose down
docker-compose up -d

# Check container startup order
# Add depends_on in docker-compose.yml

# Verify all services use same network
# In docker-compose.yml:
# networks:
#   - monitoring-network
```

---

## Issue 12: Alertmanager Not Routing Alerts

### Symptom
- Alerts fire in Prometheus but don't reach Alertmanager
- Alertmanager shows no alerts
- Notifications not sent

### Solution
```bash
# Check Alertmanager is running
docker-compose ps monitoring-alertmanager

# Check Prometheus is configured to route alerts
# In prometheus.yml should have:
# alerting:
#   alertmanagers:
#     - static_configs:
#         - targets:
#             - alertmanager:9093

# Verify connectivity
curl http://localhost:9093/-/healthy

# Check Alertmanager logs
docker logs monitoring-alertmanager

# Test alert config
docker exec monitoring-alertmanager amtool check-config /etc/alertmanager/alertmanager.yml

# Reload config
curl -X POST http://localhost:9093/-/reload

# View alerts
curl http://localhost:9093/api/v1/alerts | jq '.'
```

---

## General Debugging Commands

```bash
# View all logs
docker-compose logs --timestamps

# View logs for specific service
docker-compose logs -f monitoring-app

# Check service health
docker-compose ps

# Get detailed container info
docker inspect monitoring-app | jq '.[] | {Name, State, Mounts}'

# Check resource limits
docker stats

# Execute command in container
docker exec monitoring-app env
docker exec monitoring-app ps aux

# Get container IP
docker inspect -f '{{range .NetworkSettings.Networks}}{{.IPAddress}}{{end}}' monitoring-app

# Ping container from another
docker exec monitoring-prometheus ping app

# Check open ports in container
docker exec monitoring-app netstat -tulpn
```

---

## Performance Tuning

### If Prometheus is slow:

```yaml
# prometheus.yml
global:
  scrape_interval: 30s    # Increase from 15s
  scrape_timeout: 15s     # Increase from 10s
  evaluation_interval: 30s # Increase from 15s
```

### If Grafana is slow:

- Increase query timeout: Settings → Preferences → "Query timeout"
- Use simpler queries with fewer aggregations
- Create recording rules for complex queries

### If application is slow:

```json
// docker-compose.yml
deploy:
  resources:
    reservations:
      cpus: '0.5'
      memory: 512M
```

---

## Verification Checklist

- [ ] All 6 containers running: `docker-compose ps`
- [ ] Prometheus targets healthy: http://localhost:9090/targets
- [ ] Grafana loads: http://localhost:3001
- [ ] Application responds: http://localhost:3000
- [ ] Metrics exported: http://localhost:3000/metrics
- [ ] No errors in logs: `docker-compose logs | grep -i error`
- [ ] Alertmanager ready: http://localhost:9093/api/v1/alertmanagers
- [ ] Disk space sufficient: `docker exec monitoring-prometheus df -h /prometheus`
