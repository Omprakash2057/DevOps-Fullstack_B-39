# Grafana Dashboard Configuration Guide

This document explains how to create and configure Grafana dashboards for the monitoring stack.

## Quick Start: Create Application Monitoring Dashboard

### Step 1: Access Grafana
- URL: http://localhost:3001
- Username: admin
- Password: admin123

### Step 2: Create New Dashboard
1. Click **+** (top-left)
2. Select **Dashboard**
3. Click **Add new panel**

### Step 3: Add Panel 1 - Request Rate

**Configuration:**
- Data Source: Prometheus
- PromQL Query:
  ```promql
  rate(http_requests_total[5m])
  ```
- Panel Title: Request Rate (req/sec)
- Visualization: Graph
- Format: Numbers
- Decimals: 2

**Display:**
- Legend: Show
- X-axis: Time
- Y-axis: Requests/sec

### Step 4: Add Panel 2 - Error Rate

**Query:**
```promql
(
  sum(rate(http_requests_total{status_code=~"5.."}[5m]))
  /
  sum(rate(http_requests_total[5m]))
) * 100
```

**Configuration:**
- Panel Title: Error Rate (%)
- Visualization: Stat (for single number)
- Unit: percent (0-100)
- Thresholds:
  - Green: 0-2%
  - Yellow: 2-5%
  - Red: > 5%

### Step 5: Add Panel 3 - Response Time (P95)

**Query:**
```promql
histogram_quantile(0.95, sum(rate(http_request_duration_ms_bucket[5m])) by (le))
```

**Configuration:**
- Panel Title: Response Time P95
- Visualization: Stat
- Unit: milliseconds
- Decimals: 0

### Step 6: Add Panel 4 - Total Requests

**Query:**
```promql
sum(http_requests_total)
```

**Configuration:**
- Panel Title: Total Requests
- Visualization: Stat
- Unit: Short (reduce number size)
- Color mode: Value

## Container Metrics Dashboard

### Panel 1: CPU Usage per Container

**Query:**
```promql
sum(rate(container_cpu_usage_seconds_total[5m])) by (name) * 100
```

**Configuration:**
- Title: Container CPU Usage
- Visualization: Graph
- Unit: percent (0-100)
- Legend: Show values

### Panel 2: Memory Usage per Container

**Query:**
```promql
container_memory_usage_bytes{name!=""} / 1024 / 1024 / 1024
```

**Configuration:**
- Title: Container Memory Usage
- Visualization: Graph
- Unit: gigabytes
- Format: Short

### Panel 3: Container Restart Count

**Query:**
```promql
container_last_seen{name!=""}
```

**Configuration:**
- Title: Container Restarts
- Visualization: Table
- Columns:
  - name (label)
  - value (metric)

### Panel 4: Network I/O

**Query (RX bytes):**
```promql
rate(container_network_receive_bytes_total[5m])
```

**Query (TX bytes):**
```promql
rate(container_network_transmit_bytes_total[5m])
```

**Configuration:**
- Title: Network I/O
- Visualization: Graph
- Unit: bytes per second

## Host Metrics Dashboard

### Panel 1: CPU Usage

**Query:**
```promql
(1 - avg(rate(node_cpu_seconds_total{mode="idle"}[5m]))) * 100
```

**Configuration:**
- Title: Host CPU Usage
- Visualization: Gauge
- Unit: percent (0-100)
- Min: 0, Max: 100
- Thresholds: Good < 70%, Warning < 85%, Critical > 85%

### Panel 2: Memory Utilization

**Query:**
```promql
(
  (node_memory_MemTotal_bytes - node_memory_MemAvailable_bytes)
  /
  node_memory_MemTotal_bytes
) * 100
```

**Configuration:**
- Title: Host Memory Usage
- Visualization: Gauge
- Unit: percent (0-100)

### Panel 3: Disk Usage per Mount

**Query:**
```promql
(
  (node_filesystem_size_bytes - node_filesystem_avail_bytes)
  /
  node_filesystem_size_bytes
) * 100
```

**Configuration:**
- Title: Filesystem Usage
- Visualization: Table
- Breakdown by device

### Panel 4: Network Interface Traffic

**RX Query:**
```promql
rate(node_network_receive_bytes_total[5m]) != 0
```

**TX Query:**
```promql
rate(node_network_transmit_bytes_total[5m]) != 0
```

**Configuration:**
- Title: Network Traffic
- Visualization: Graph
- Format: bytes per second

## System-Wide Dashboard

### Panel 1: Service Status

**Query:**
```promql
up
```

**Configuration:**
- Title: Service Status
- Visualization: Table
- Columns: instance, job, value
- Color background when value = 1 (green = up)

### Panel 2: Alerts Firing

**Query:**
Use the **Alertlist** panel type (built-in)

**Configuration:**
- Title: Active Alerts
- State filter: firing
- Auto-refresh: enabled
- Suppress OK: false

### Panel 3: Metrics Ingestion Rate

**Query:**
```promql
rate(prometheus_tsdb_symbol_table_size_bytes[5m])
```

**Configuration:**
- Title: Metrics Ingestion
- Visualization: Graph

## Dashboard Variables (Optional)

Add dynamic filtering to dashboards:

### Step 1: Create Variable
1. Click **Dashboard settings** (gear icon)
2. Select **Variables**
3. Click **New**

### Step 2: Configure Variable

Example - Filter by container name:

```
Name: container
Type: Query
Data source: Prometheus
Query: label_values(container_memory_usage_bytes, name)
Multi-value: ON
```

### Step 3: Update Panels

In PromQL queries, use:
```promql
container_memory_usage_bytes{name=~"$container"}
```

## Alert Rule Integration

To see alert rules in dashboard:

1. **Add Alertlist panel**
   - Panel type: "Alert list"
   - Visualization options:
     - Show options: All
     - Grouping: By rule
     - Sorting: Recent first

2. **Add Alert Threshold to Graph**
   - In panel JSON editor, add:
   ```json
   "thresholds": {
     "mode": "absolute",
     "steps": [
       {
         "color": "green",
         "value": null
       },
       {
         "color": "red",
         "value": 80
       }
     ]
   }
   ```

## Best Practices

### Query Optimization
- Use short time ranges for frequently updated metrics
- Aggregate with `sum()` or `avg()` to reduce cardinality
- Use `rate()` for counters, `increase()` for sums
- Cache expensive queries in recording rules

### Visual Design
- Keep dashboard readable (max 4-6 panels per row)
- Group related metrics together
- Use consistent units and colors
- Add descriptions with annotations

### Performance
- Limit time range to necessary period (not all-time)
- Use appropriate step/interval
- Avoid overly complex queries
- Use dashboard refresh rate (30s-5m)

### Naming Conventions
- Dashboard: `[Team] [Component] [Purpose]` (e.g., "DevOps App Monitoring")
- Panel: `[Metric] [Unit]` (e.g., "Response Time (ms)")
- Queries: Use descriptive legends

## Export & Sharing

### Export Dashboard
1. Click **Share** (dashboard name)
2. Select **Export**
3. Format: JSON
4. Save locally

### Import Dashboard
1. Click **+** → **Import**
2. Upload JSON file
3. Configure data source
4. Click **Import**

## Example PromQL Queries

```promql
# Request metrics
rate(http_requests_total[5m])
sum(rate(http_requests_total[5m])) by (status_code)
histogram_quantile(0.99, rate(http_request_duration_ms_bucket[5m]))

# Container metrics
container_cpu_usage_seconds_total
container_memory_usage_bytes
container_network_receive_bytes_total
container_fs_usage_bytes / container_fs_limit_bytes * 100

# Host metrics
node_cpu_seconds_total
node_memory_MemAvailable_bytes
node_disk_io_reads_completed_total
node_network_receive_bytes_total

# Application health
process_resident_memory_bytes
process_cpu_seconds_total
go_goroutines (if using Go app)

# Alert related
ALERTS
ALERTS{severity="critical"}
```
