# Monitoring Stack - Windows Specific Setup Guide

Complete instructions for running the monitoring stack on Windows 10/11

## Prerequisites Installation

### 1. Install Docker Desktop for Windows

**Download:**
- Go to https://www.docker.com/products/docker-desktop
- Click "Download for Windows"
- Run the installer: `Docker Desktop Installer.exe`

**Post-Installation:**
```powershell
# After installation, restart your computer

# Verify Docker is installed
docker --version
docker run hello-world
```

**Enable WSL2 (Recommended for Better Performance):**

If using Windows 10/11 Pro, Home, or Enterprise (v2004+):

```powershell
# Open PowerShell as Administrator
# Enable WSL 2 feature
wsl --install

# Set WSL 2 as default
wsl --set-default-version 2

# In Docker Desktop Settings:
# - Settings → General → Check "Use the WSL 2 based engine"
# - Apply and Restart
```

**For Windows 10 Home (WSL2 requires specific build):**
```powershell
# Check your Windows build
winver

# If < Build 19042, update Windows first
# Settings → Update & Security → Check for updates
```

### 2. Install Git (Optional but Recommended)

```powershell
# Download from https://git-scm.com/download/win
# Run installer
# Accept defaults
```

### 3. Install PowerShell 7 (Optional, Better than cmd.exe)

```powershell
# Open PowerShell as Administrator
powershell -Command "& {Start-Process powershell -ArgumentList \"-Command irm https://aka.ms/install-powershell.ps1 | iex\" -Verb RunAs}"

# Or download from https://github.com/PowerShell/PowerShell/releases
```

---

## Project Setup

### Step 1: Clone or Download Project

**Option A: Using Git**
```powershell
cd Desktop\Devops2026
git clone <repository-url>
cd Devops_2-4-2026
```

**Option B: Manual Download**
```powershell
# All files have been created in:
cd C:\Users\malle\OneDrive\Desktop\Devops2026\Devops_2-4-2026

# Verify files exist
dir
```

### Step 2: Verify Docker Installation

```powershell
# Start Docker Desktop (if not already running)
# Wait for "Docker is running" notification

# Test Docker
docker ps
docker run --rm alpine echo "Docker is working!"

# Test Docker Compose
docker-compose --version
```

---

## Running the Monitoring Stack

### Quick Start (Easiest)

**Method 1: Run Batch File**
```powershell
# Navigate to project directory
cd C:\Users\malle\OneDrive\Desktop\Devops2026\Devops_2-4-2026

# Run startup menu
.\start-stack-windows.bat

# Select option 3: Start monitoring stack
```

**Method 2: PowerShell Commands**
```powershell
# Navigate to project
cd C:\Users\malle\OneDrive\Desktop\Devops2026\Devops_2-4-2026

# Build images (first time only)
docker-compose build

# Start services
docker-compose up -d

# Verify all services started
docker-compose ps
```

### Expected Output

```
NAME                     STATUS              PORTS
monitoring-app           Up (healthy)        0.0.0.0:3000->3000/tcp
monitoring-prometheus    Up (healthy)        0.0.0.0:9090->9090/tcp
monitoring-cadvisor      Up (healthy)        0.0.0.0:8080->8080/tcp
monitoring-node-exporter Up                  0.0.0.0:9100->9100/tcp
monitoring-alertmanager  Up                  0.0.0.0:9093->9093/tcp
monitoring-grafana       Up (healthy)        0.0.0.0:3001->3000/tcp
```

---

## Accessing Services

Open these URLs in your browser:

| Service | URL | Username/Password |
|---------|-----|-------------------|
| **Grafana Dashboard** | http://localhost:3001 | admin / admin123 |
| Prometheus | http://localhost:9090 | - |
| Alertmanager | http://localhost:9093 | - |
| Application | http://localhost:3000 | - |
| cAdvisor | http://localhost:8080 | - |

---

## PowerShell Automation

### Create a Quick Reference Script

Save as `test-monitoring.ps1`:

```powershell
param(
    [string]$Action = "status"
)

switch ($Action) {
    "status" {
        Write-Host "Service Status:" -ForegroundColor Green
        docker-compose ps
    }
    
    "logs" {
        docker-compose logs -f
    }
    
    "stop" {
        docker-compose stop
    }
    
    "start" {
        docker-compose up -d
        Start-Sleep -Seconds 3
        docker-compose ps
    }
    
    "restart" {
        docker-compose restart
    }
    
    "test" {
        Write-Host "Testing services..." -ForegroundColor Green
        
        # Test application
        try {
            $response = Invoke-WebRequest -Uri "http://localhost:3000/" -UseBasicParsing -TimeoutSec 5
            Write-Host "[OK] Application is responding" -ForegroundColor Green
        } catch {
            Write-Host "[FAILED] Application" -ForegroundColor Red
        }
        
        # Test Prometheus
        try {
            $response = Invoke-WebRequest -Uri "http://localhost:9090/-/healthy" -UseBasicParsing -TimeoutSec 5
            Write-Host "[OK] Prometheus is responding" -ForegroundColor Green
        } catch {
            Write-Host "[FAILED] Prometheus" -ForegroundColor Red
        }
        
        # Test Grafana
        try {
            $response = Invoke-WebRequest -Uri "http://localhost:3001/api/health" -UseBasicParsing -TimeoutSec 5
            Write-Host "[OK] Grafana is responding" -ForegroundColor Green
        } catch {
            Write-Host "[FAILED] Grafana" -ForegroundColor Red
        }
    }
    
    "open-grafana" {
        Start-Process "http://localhost:3001"
    }
    
    "open-prometheus" {
        Start-Process "http://localhost:9090"
    }
    
    default {
        Write-Host @"
Usage: .\test-monitoring.ps1 -Action <action>

Actions:
  status         Show service status (default)
  start          Start all services
  stop           Stop all services
  restart        Restart all services
  logs           View container logs
  test           Test service connectivity
  open-grafana   Open Grafana in browser
  open-prometheus Open Prometheus in browser
"@
    }
}
```

**Usage:**
```powershell
.\test-monitoring.ps1 -Action status
.\test-monitoring.ps1 -Action start
.\test-monitoring.ps1 -Action test
.\test-monitoring.ps1 -Action open-grafana
```

---

## Common Windows-Specific Issues & Solutions

### Issue 1: "Docker daemon is not running"

**Solution:**
```powershell
# Method 1: Start Docker Desktop from Start Menu
# Click Windows Start → Type "Docker" → Launch Docker Desktop

# Method 2: Start from PowerShell
& "C:\Program Files\Docker\Docker\Docker Desktop.exe"

# Wait 30-60 seconds for Docker to fully initialize
# Check status
docker ps
```

### Issue 2: "WSL 2 installation incomplete"

**Solution:**
```powershell
# Update WSL 2
wsl --update

# Install Ubuntu distro (optional)
wsl --install -d Ubuntu

# Restart Docker Desktop
```

### Issue 3: Port Already in Use

**Solution:**
```powershell
# Find process using port 3000
netstat -ano | findstr :3000

# Kill the process (replace <PID> with actual PID)
taskkill /PID <PID> /F

# Or change the port in docker-compose.yml
# ports:
#   - "3002:3000"  # Change to different port
```

### Issue 4: Insufficient Disk Space

**Solution:**
```powershell
# Check Docker disk usage
docker system df

# Clean up unused images/containers
docker system prune -a

# Check available disk space
Get-Volume | Select-Object DriveLetter, SizeRemaining

# Increase Docker resources:
# Docker Desktop → Settings → Resources → Disk image size
```

### Issue 5: Cannot Connect to Docker Daemon

**Solution:**
```powershell
# Restart Docker Desktop
Get-Process dockerd -ErrorAction SilentlyContinue | Stop-Process -Force
& "C:\Program Files\Docker\Docker\Docker Desktop.exe"

# Or restart Windows completely
Restart-Computer -Force
```

### Issue 6: Slow Performance

**Solution:**
```powershell
# Allocate more resources to Docker:
# Docker Desktop → Settings → Resources:
#   - CPUs: Increase (2-4 recommended)
#   - Memory: Increase (4-8 GB recommended)
#   - Disk: Increase if needed

# Enable WSL 2 for better performance
# (Settings → General → "Use WSL 2 based engine")
```

### Issue 7: TLS/Certificate Errors

**Solution:**
```powershell
# Update Docker
# Docker Desktop → Help → Check for updates

# Or completely reinstall
docker system prune -a --volumes
# Uninstall Docker Desktop from Control Panel
# Download fresh, reinstall

# Accept Docker Desktop license agreement
# Docker Desktop → Settings → General → Check "I accept"
```

---

## Testing the Stack on Windows

### Test 1: Generate Traffic

```powershell
# Simple traffic generation
1..50 | ForEach-Object {
    Invoke-WebRequest -Uri "http://localhost:3000/" -UseBasicParsing -TimeoutSec 5 | Out-Null
    Write-Host "Request $_"
}
```

### Test 2: Trigger Errors

```powershell
# Generate errors
1..50 | ForEach-Object {
    Invoke-WebRequest -Uri "http://localhost:3000/error?error_rate=100" `
        -UseBasicParsing -TimeoutSec 5 | Out-Null
    Write-Host "Error request $_"
}
```

### Test 3: Monitor in Real-Time

```powershell
# Watch Docker stats
docker stats --no-stream

# Or continuous monitoring
while ($true) {
    Clear-Host
    docker stats --no-stream
    Start-Sleep -Seconds 5
}
```

---

## Windows Defender/Firewall Configuration

If you get connection refused errors:

```powershell
# Allow Docker through Windows Firewall
# Settings → Update & Security → Windows Security → Firewall
# → Manage apps through firewall
# → Allow Docker Desktop (Private/Public)

# Or command-line (run as Administrator)
netsh advfirewall firewall add rule name="Docker" dir=in action=allow program="C:\Program Files\Docker\Docker\resources\com.docker.backend.exe"
```

---

## Editing Configuration Files

### Edit Prometheus Config
```powershell
# In VSCode
code prometheus\prometheus.yml

# Or Notepad
notepad prometheus\prometheus.yml
```

### Edit Alert Rules
```powershell
code prometheus\alerts.yml
```

### Edit Alertmanager Config
```powershell
code alertmanager\alertmanager.yml
```

---

## Useful PowerShell Shortcuts

Create aliases in PowerShell profile:

```powershell
# Open PowerShell profile editor
notepad $PROFILE

# Add these aliases
Set-Alias -Name docker-start -Value {docker-compose up -d}
Set-Alias -Name docker-stop -Value {docker-compose stop}
Set-Alias -Name docker-logs -Value {docker-compose logs -f}
Set-Alias -Name docker-stats -Value {docker stats --no-stream}

# Save and reload
. $PROFILE
```

---

## Windows Terminal Integration (Optional)

For a better terminal experience:

1. Install Windows Terminal from Microsoft Store
2. Set default profile to PowerShell 7
3. Add Docker commands to Quick Actions

---

## Backing Up Your Setup

```powershell
# Export all configurations
New-Item -Path "backup" -ItemType Directory -Force
Copy-Item "prometheus" -Destination "backup\" -Recurse -Force
Copy-Item "alertmanager" -Destination "backup\" -Force
Copy-Item "docker-compose.yml" -Destination "backup\"
Copy-Item "Dockerfile" -Destination "backup\"

# Archive backup
Compress-Archive -Path "backup" -DestinationPath "monitoring-backup-$(Get-Date -Format 'yyyy-MM-dd').zip"
```

---

## Next Steps

1. ✅ Start the stack: `docker-compose up -d`
2. ✅ Open Grafana: http://localhost:3001
3. ✅ Create dashboards using GRAFANA_SETUP.md
4. ✅ Test alerts using QUICK_START.md
5. ✅ Refer to TROUBLESHOOTING.md if issues occur

---

## Windows-Specific Resources

- Docker Desktop Documentation: https://docs.docker.com/desktop/windows/
- WSL 2 Setup: https://docs.microsoft.com/en-us/windows/wsl/install-win10
- PowerShell Documentation: https://docs.microsoft.com/en-us/powershell/
- Docker Compose on Windows: https://docs.docker.com/compose/release-notes/
