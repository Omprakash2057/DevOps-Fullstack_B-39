# Course Management API - Kubernetes Deployment Quick Start (Windows)
# This script automates the setup process for Windows

# Error handling
$ErrorActionPreference = "Stop"

# Color codes
$Green = [System.ConsoleColor]::Green
$Red = [System.ConsoleColor]::Red
$Yellow = [System.ConsoleColor]::Yellow
$Blue = [System.ConsoleColor]::Blue

function Write-ColorOutput {
    param (
        [string]$Message,
        [System.ConsoleColor]$Color = "White"
    )
    Write-Host $Message -ForegroundColor $Color
}

# Header
Write-ColorOutput "════════════════════════════════════════════════════" -Color $Blue
Write-ColorOutput "     Course Management API - Quick Start Setup" -Color $Blue
Write-ColorOutput "════════════════════════════════════════════════════" -Color $Blue
Write-Host ""

# Check prerequisites
function Check-Prerequisites {
    Write-ColorOutput "[*] Checking prerequisites..." -Color $Blue
    
    try {
        docker --version | Out-Null
        Write-ColorOutput "[✓] Docker is installed" -Color $Green
    }
    catch {
        Write-ColorOutput "[!] Docker is not installed" -Color $Red
        exit 1
    }
    
    try {
        kubectl version --client | Out-Null
        Write-ColorOutput "[✓] kubectl is installed" -Color $Green
    }
    catch {
        Write-ColorOutput "[!] kubectl is not installed" -Color $Red
        exit 1
    }
    
    Write-Host ""
}

# Build Docker image
function Build-Image {
    Write-ColorOutput "[*] Building Docker image..." -Color $Blue
    docker build -t course-api:latest .
    Write-ColorOutput "[✓] Docker image built successfully" -Color $Green
    Write-Host ""
}

# Test Docker image locally
function Test-Image {
    Write-ColorOutput "[*] Testing Docker image locally..." -Color $Blue
    Write-ColorOutput "    Starting test container..." -Color $Yellow
    
    docker run -d --name course-api-test -p 3000:3000 course-api:latest | Out-Null
    Start-Sleep -Seconds 3
    
    try {
        $response = Invoke-WebRequest -Uri "http://localhost:3000/health" -ErrorAction Stop
        Write-ColorOutput "[✓] Health check passed" -Color $Green
    }
    catch {
        Write-ColorOutput "[!] Health check failed" -Color $Red
        docker stop course-api-test | Out-Null
        docker rm course-api-test | Out-Null
        exit 1
    }
    
    docker stop course-api-test | Out-Null
    docker rm course-api-test | Out-Null
    Write-ColorOutput "[✓] Docker image test passed" -Color $Green
    Write-Host ""
}

# Push to Docker Hub
function Push-Image {
    $DOCKER_USERNAME = Read-Host "Enter your Docker Hub username"
    
    Write-ColorOutput "[*] Logging in to Docker Hub..." -Color $Blue
    docker login
    
    Write-ColorOutput "[*] Tagging image for Docker Hub..." -Color $Blue
    docker tag course-api:latest "$DOCKER_USERNAME/course-api:latest"
    docker tag course-api:latest "$DOCKER_USERNAME/course-api:v1.0.0"
    
    Write-ColorOutput "[*] Pushing image to Docker Hub..." -Color $Blue
    docker push "$DOCKER_USERNAME/course-api:latest"
    docker push "$DOCKER_USERNAME/course-api:v1.0.0"
    
    Write-ColorOutput "[✓] Image pushed to Docker Hub" -Color $Green
    Write-Host ""
    
    # Update YAML files
    Write-ColorOutput "[*] Updating YAML files with Docker Hub username..." -Color $Blue
    (Get-Content api-pod.yaml) -replace 'your-dockerhub-username', $DOCKER_USERNAME | Set-Content api-pod.yaml
    (Get-Content deployment.yaml) -replace 'your-dockerhub-username', $DOCKER_USERNAME | Set-Content deployment.yaml
    Write-ColorOutput "[✓] YAML files updated" -Color $Green
    Write-Host ""
}

# Deploy to Kubernetes
function Deploy-ToKubernetes {
    Write-ColorOutput "[*] Deploying Pod to Kubernetes..." -Color $Blue
    kubectl apply -f api-pod.yaml
    
    Write-ColorOutput "[*] Waiting for pod to be ready..." -Color $Blue
    $maxAttempts = 30
    $attempt = 0
    
    while ($attempt -lt $maxAttempts) {
        $phase = kubectl get pod course-api-pod -o jsonpath='{.status.phase}' 2>$null
        if ($phase -eq "Running") {
            Write-ColorOutput "[✓] Pod is running" -Color $Green
            break
        }
        Write-Host "    Waiting... ($($attempt + 1)/$maxAttempts)"
        Start-Sleep -Seconds 2
        $attempt++
    }
    
    Write-ColorOutput "[*] Deploying Service..." -Color $Blue
    kubectl apply -f api-service.yaml
    
    Write-ColorOutput "[✓] Kubernetes deployment complete" -Color $Green
    Write-Host ""
}

# Display access information
function Display-AccessInfo {
    Write-ColorOutput "[*] Getting access information..." -Color $Blue
    
    $NODEPORT = kubectl get svc course-api-service -o jsonpath='{.spec.ports[0].nodePort}' 2>$null
    if (-not $NODEPORT) {
        $NODEPORT = "30001"
    }
    
    Write-Host ""
    Write-ColorOutput "════════════════════════════════════════════════════" -Color $Green
    Write-ColorOutput "         API is Ready for Testing!" -Color $Green
    Write-ColorOutput "════════════════════════════════════════════════════" -Color $Green
    Write-Host ""
    Write-ColorOutput "NodePort: $NODEPORT" -Color $Yellow
    Write-Host ""
    Write-Host "Test using:"
    Write-Host "  curl http://localhost:$NODEPORT/health"
    Write-Host "  curl http://localhost:$NODEPORT/courses"
    Write-Host ""
    Write-Host "Or use kubectl port-forward:"
    Write-Host "  kubectl port-forward svc/course-api-service 8080:80"
    Write-Host "  Then access: http://localhost:8080"
    Write-Host ""
}

# Display optional steps
function Display-OptionalSteps {
    Write-Host ""
    Write-ColorOutput "════════════════════════════════════════════════════" -Color $Blue
    Write-ColorOutput "             Optional Next Steps" -Color $Blue
    Write-ColorOutput "════════════════════════════════════════════════════" -Color $Blue
    Write-Host ""
    Write-Host "1. Deploy with Deployment (recommended for production):"
    Write-Host "   kubectl apply -f deployment.yaml"
    Write-Host ""
    Write-Host "2. Scale the deployment:"
    Write-Host "   kubectl scale deployment course-api-deployment --replicas=5"
    Write-Host ""
    Write-Host "3. View logs:"
    Write-Host "   kubectl logs -f pod/course-api-pod"
    Write-Host ""
    Write-Host "4. Get pod details:"
    Write-Host "   kubectl describe pod course-api-pod"
    Write-Host ""
    Write-Host "5. Delete resources:"
    Write-Host "   kubectl delete pod course-api-pod"
    Write-Host "   kubectl delete svc course-api-service"
    Write-Host ""
}

# Main execution
function Main {
    Check-Prerequisites
    
    $buildImage = Read-Host "Do you want to build the Docker image? (y/n)"
    if ($buildImage -eq "y") {
        Build-Image
    }
    
    $testImage = Read-Host "Do you want to test the Docker image? (y/n)"
    if ($testImage -eq "y") {
        Test-Image
    }
    
    $pushImage = Read-Host "Do you want to push to Docker Hub? (y/n)"
    if ($pushImage -eq "y") {
        Push-Image
    }
    else {
        Write-ColorOutput "[!] Skipping Docker Hub push" -Color $Yellow
        Write-ColorOutput "    Update YAML files manually with your Docker Hub username" -Color $Yellow
        Write-Host ""
    }
    
    $deployK8s = Read-Host "Do you want to deploy to Kubernetes? (y/n)"
    if ($deployK8s -eq "y") {
        Deploy-ToKubernetes
    }
    
    Display-AccessInfo
    Display-OptionalSteps
}

# Run main function
Main
