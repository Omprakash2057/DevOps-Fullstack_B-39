# Kubernetes & Docker Troubleshooting Guide

## Quick Diagnosis Flowchart

```
Problem: Pod not starting
    ├─> Check pod status: kubectl describe pod name
    ├─> Check logs: kubectl logs pod-name
    ├─> Check image: docker pull image-name
    └─> Check events: kubectl get events
```

---

## COMMON ISSUES & SOLUTIONS

### 1. Status: ImagePullBackOff

**Symptoms:**
- Pod status shows `ImagePullBackOff`
- Event message: "Failed to pull image"

**Causes:**
- Image doesn't exist in Docker Hub
- Wrong image name or tag
- Docker Hub credentials issue
- Network connectivity problem

**Solutions:**

```bash
# Verify image exists
docker pull yourusername/course-api:latest

# Double-check image name
kubectl describe pod course-api-pod | grep "Image:"

# Check YAML has correct image
cat api-pod.yaml | grep "image:"

# For private registry, create secret
kubectl create secret docker-registry regcred \
  --docker-server=docker.io \
  --docker-username=yourusername \
  --docker-password=yourpassword

# Add imagePullSecrets to pod spec:
# imagePullSecrets:
# - name: regcred

# Push image to Docker Hub if not yet pushed
docker login
docker push yourusername/course-api:latest
```

---

### 2. Status: CrashLoopBackOff

**Symptoms:**
- Pod keeps restarting
- Status: `CrashLoopBackOff`

**Causes:**
- Application crashed
- Port already in use
- Missing dependencies
- Invalid environment variables

**Solutions:**

```bash
# Check pod logs
kubectl logs course-api-pod

# Check previous logs
kubectl logs course-api-pod --previous

# Stream logs to see real-time errors
kubectl logs -f course-api-pod

# Get detailed pod description
kubectl describe pod course-api-pod

# Check resource limits aren't too low
kubectl get pod course-api-pod -o yaml | grep -A 5 "resources:"

# Test image locally
docker run -it course-api:latest

# Increase initial delay for startup probe
# In YAML: startupProbe.initialDelaySeconds: 30
```

---

### 3. Status: Pending

**Symptoms:**
- Pod stuck in `Pending` state
- Pod never moves to `Running`

**Causes:**
- Insufficient cluster resources
- No matching nodes for node selectors
- PersistentVolumeClaim not bound
- No available node slots

**Solutions:**

```bash
# Check cluster resources
kubectl top nodes
kubectl describe nodes

# Check pod events
kubectl describe pod course-api-pod

# Check node affinity/selectors
kubectl get pod course-api-pod -o yaml | grep -A 5 "nodeSelector"

# List available nodes
kubectl get nodes

# Check node capacity
kubectl describe node <node-name>

# If no resources, scale down other apps or add more nodes
kubectl scale deployment other-app --replicas=0

# For Kind/Minikube, increase allocated resources
# Docker Desktop: Settings > Resources > increase CPUs/Memory
```

---

### 4. Cannot Access Service/Pod

**Symptoms:**
- `Connection refused` error
- Cannot reach API endpoints

**Causes:**
- Service not created properly
- Pod not ready
- Network connectivity issue
- Firewall blocking port

**Solutions:**

```bash
# Verify service exists
kubectl get svc course-api-service

# Check service has endpoints
kubectl get endpoints course-api-service

# If no endpoints, check pod labels match service selector
kubectl get pod --show-labels
kubectl get svc course-api-service -o jsonpath='{.spec.selector}'

# Test pod directly
kubectl port-forward pod/course-api-pod 3000:3000
curl http://localhost:3000/health

# Try from inside pod
kubectl exec -it course-api-pod -- curl localhost:3000/health

# Check service selector matches pod labels
kubectl get pod course-api-pod -o jsonpath='{.metadata.labels}'
kubectl get svc course-api-service -o jsonpath='{.spec.selector}'

# If using NodePort, check port is accessible
NODEPORT=$(kubectl get svc course-api-service -o jsonpath='{.spec.ports[0].nodePort}')
curl http://localhost:$NODEPORT/health

# For LoadBalancer, wait for external IP
kubectl get svc -w
```

---

### 5. Pod Resource Issues

**Symptoms:**
- High memory/CPU usage
- Application running slow
- Pod killed for OOM (Out of Memory)

**Causes:**
- Resource limits too low
- Memory leak in application
- Too many replicas
- Inefficient code

**Solutions:**

```bash
# Check resource usage
kubectl top pod course-api-pod
kubectl top nodes

# Check resource limits
kubectl get pod course-api-pod -o yaml | grep -A 10 "resources:"

# Update resource limits
kubectl set resources deployment course-api-deployment \
  --limits=cpu=1000m,memory=512Mi \
  --requests=cpu=250m,memory=256Mi

# Check pod restart count
kubectl get pod course-api-pod -o jsonpath='{.status.containerStatuses[0].restartCount}'

# View OOM kill events
kubectl describe pod course-api-pod | grep -i oom

# Increase limits in YAML and reapply
# resources:
#   limits:
#     memory: "512Mi"
#     cpu: "1000m"
```

---

### 6. Service Endpoint Issues

**Symptoms:**
- Service created but no endpoints
- Can't reach pod through service

**Causes:**
- Pod labels don't match selector
- Pod not ready
- Pod in different namespace
- Health check failing

**Solutions:**

```bash
# Check if endpoints exist
kubectl get endpoints course-api-service

# Check pod labels
kubectl get pod --show-labels

# Check service selector
kubectl get svc course-api-service -o jsonpath='{.spec.selector}'
# Format: {"app":"course-api"}

# Add missing label to pod
kubectl label pod course-api-pod app=course-api

# Verify pod is ready
kubectl get pod course-api-pod -o jsonpath='{.status.conditions[?(@.type=="Ready")].status}'

# Check readiness probe
kubectl describe pod course-api-pod | grep -A 10 "Readiness"

# Check pod events
kubectl describe pod course-api-pod
```

---

### 7. Network Connectivity Issues

**Symptoms:**
- Pods can't communicate
- DNS resolution failing
- No route to host

**Causes:**
- Network policies blocking traffic
- DNS service down
- Node networking issue

**Solutions:**

```bash
# Test DNS from pod
kubectl exec -it course-api-pod -- nslookup kubernetes.default

# Test connectivity between pods
kubectl run -it --rm test --image=nicolaka/netshoot:latest --restart=Never -- bash
# Inside pod:
nslookup course-api-service
curl http://course-api-service

# Check network policies
kubectl get networkpolicies

# Test from another pod
kubectl exec -it other-pod -- curl http://course-api-service:80/health

# Enable network debugging
# Note default namespaces may have restricted policies
```

---

### 8. Deployment Rolling Update Issues

**Symptoms:**
- Deployment stuck during update
- New pods not scaling up
- Pods keep crashing after update

**Causes:**
- New image broken
- Resource constraints
- Readiness probe failing
- Rollout strategy issues

**Solutions:**

```bash
# Check deployment status
kubectl describe deployment course-api-deployment

# Watch rollout
kubectl rollout status deployment/course-api-deployment

# View rollout history
kubectl rollout history deployment/course-api-deployment

# Rollback to previous version
kubectl rollout undo deployment/course-api-deployment

# Check new pod logs
kubectl logs -f deployment/course-api-deployment

# Manual update with verification
kubectl set image deployment/course-api-deployment \
  course-api-container=yourusername/course-api:v1.0.1 \
  --record

# Pause rollout for investigation
kubectl rollout pause deployment/course-api-deployment

# Resume rollout
kubectl rollout resume deployment/course-api-deployment
```

---

### 9. Health Check Failures

**Symptoms:**
- Pod constantly restarting
- Liveness probe failing
- Pod marked as not ready

**Causes:**
- Health endpoint not implemented
- Probe timing too aggressive
- Application slow to start

**Solutions:**

```bash
# Check probe configuration
kubectl get pod course-api-pod -o yaml | grep -A 10 "livenessProbe"

# Manually test health endpoint
kubectl exec -it course-api-pod -- curl http://localhost:3000/health

# Check probe logs
kubectl describe pod course-api-pod | grep -A 5 "Liveness"

# Adjust probe timing
# In YAML:
# livenessProbe:
#   initialDelaySeconds: 30  # Increase startup time
#   periodSeconds: 20        # Check frequency
#   failureThreshold: 3      # Allow more retries

# Test health check response code
kubectl exec -it course-api-pod -- curl -w "\n%{http_code}" http://localhost:3000/health
```

---

### 10. Persistent Storage Issues

**Symptoms:**
- PersistentVolumeClaim pending
- Pod can't mount volume

**Causes:**
- PersistentVolume not available
- Storage class misconfigured
- Size mismatch

**Solutions:**

```bash
# If using Persistent Volumes:
# Check PV and PVC status
kubectl get pv
kubectl get pvc

# Describe PVC
kubectl describe pvc claim-name

# Check storage classes
kubectl get storageclass

# For local development (no need for PV):
# Use hostPath or just in-memory storage
```

---

## DEBUGGING QUICK COMMANDS

```bash
# All-in-one diagnostics
echo "=== Pod Status ===" && \
kubectl describe pod course-api-pod && \
echo "=== Recent Logs ===" && \
kubectl logs --tail=50 course-api-pod && \
echo "=== Pod Events ===" && \
kubectl describe pod course-api-pod | grep -A 20 Events && \
echo "=== Service Info ===" && \
kubectl describe svc course-api-service

# Check everything about deployment
kubectl describe deployment course-api-deployment
kubectl rollout status deployment/course-api-deployment -w

# Find all errors in cluster
kubectl get events --sort-by='.lastTimestamp' | grep Error

# Debug with netshoot image
kubectl run -it --rm debug --image=nicolaka/netshoot:latest --restart=Never -- bash

# Get top resource consumers
kubectl top pods
kubectl top nodes
```

---

## KUBECTL DEBUG COMMANDS

```bash
# Interactive debugging pod
kubectl debug -it course-api-pod --image=ubuntu:latest

# Copy file from pod
kubectl cp pod-name:/path/to/file ./local-file

# Copy file to pod
kubectl cp ./local-file pod-name:/path/to/file

# Port forward for debugging
kubectl port-forward pod/course-api-pod 9229:9229  # For Node.js debugger

# Describe everything
kubectl describe all --namespace=default
```

---

## LOG ANALYSIS

```bash
# Follow deployment logs from multiple pods
kubectl logs -f deployment/course-api-deployment

# Logs from all pods with label
kubectl logs -l app=course-api -f

# Previous crashes
kubectl logs pod-name --previous

# Extended log history
kubectl logs pod-name --tail=200

# Time-based logs
kubectl logs pod-name --since=1h
```

---

## RECOVERY PROCEDURES

### Restart Pod
```bash
# Delete pod (will be recreated)
kubectl delete pod course-api-pod

# Or scale deployment down and up
kubectl scale deployment course-api-deployment --replicas=0
kubectl scale deployment course-api-deployment --replicas=3
```

### Restart Deployment
```bash
# Restart all pods in deployment
kubectl rollout restart deployment/course-api-deployment
```

### Clean Everything
```bash
# Delete pod
kubectl delete pod course-api-pod

# Delete service
kubectl delete svc course-api-service

# Delete deployment
kubectl delete deployment course-api-deployment

# Delete all with label
kubectl delete all -l app=course-api
```

---

## USEFUL DEBUGGING STRATEGIES

1. **Check Status First**: Always start with `kubectl describe pod name`
2. **Check Events**: Pod events often show root cause
3. **Check Logs**: Application logs have specific error messages
4. **Check Labels**: Service endpoints depend on label matching
5. **Test Incrementally**: Start with local Docker, then move to Kubernetes
6. **Use Port-Forward**: Direct pod access without service issues
7. **Check Resources**: Many issues stem from insufficient CPU/memory
8. **Read Event Messages**: Often describe the exact problem

---

## MONITORING CHECKLIST

Before going to production:
- [ ] Health checks working correctly
- [ ] Resource limits set appropriately
- [ ] No pending pods
- [ ] Logs accessible and meaningful
- [ ] Service endpoints populated
- [ ] Can reach API through service
- [ ] HPA working if configured
- [ ] No continuous pod restarts

---

**Last Updated**: March 2026
