# Kubernetes kubectl Command Quick Reference

## Table of Contents
- [Docker Commands](#docker-commands)
- [Kubernetes Basics](#kubernetes-basics)
- [Pod Management](#pod-management)
- [Service Management](#service-management)
- [Deployment Management](#deployment-management)
- [Monitoring & Debugging](#monitoring--debugging)
- [Cleanup](#cleanup)

---

## DOCKER COMMANDS

### Build and Test
```bash
# Build image
docker build -t course-api:latest .

# Build with specific tag
docker build -t course-api:v1.0.0 .

# List images
docker images

# Run container locally
docker run -d -p 3000:3000 --name test course-api:latest

# Run and remove after exit
docker run --rm -it course-api:latest

# View logs
docker logs test
docker logs -f test  # Follow logs

# Execute command in running container
docker exec -it test /bin/sh

# Stop container
docker stop test

# Remove container
docker rm test

# Remove image
docker rmi course-api:latest
```

### Docker Hub
```bash
# Login
docker login

# Tag for Docker Hub
docker tag course-api:latest yourusername/course-api:latest

# Push to Docker Hub
docker push yourusername/course-api:latest

# Pull from Docker Hub
docker pull yourusername/course-api:latest

# Logout
docker logout
```

---

## KUBERNETES BASICS

### Cluster Info
```bash
# Get cluster info
kubectl cluster-info

# Get cluster nodes
kubectl get nodes

# Get detailed node info
kubectl describe node <node-name>

# Get API server version
kubectl version --short

# Get current context
kubectl config current-context

# List contexts
kubectl config get-contexts

# Switch context
kubectl config use-context <context-name>

# Get namespaces
kubectl get namespaces
```

### Namespaces
```bash
# Create namespace
kubectl create namespace course-api

# Apply resources to namespace
kubectl apply -f file.yaml -n course-api

# Set default namespace
kubectl config set-context --current --namespace=course-api

# Delete namespace
kubectl delete namespace course-api
```

---

## POD MANAGEMENT

### Create and Deploy Pods
```bash
# Apply pod configuration
kubectl apply -f api-pod.yaml

# Create pod from command line
kubectl run course-api --image=yourusername/course-api:latest

# Create pod and keep it running
kubectl run -i --tty --rm pod-name --image=yourusername/course-api:latest
```

### View Pods
```bash
# List pods
kubectl get pods

# List pods in specific namespace
kubectl get pods -n course-api

# List pods with more details
kubectl get pods -o wide

# List all pods in all namespaces
kubectl get pods --all-namespaces

# Watch pods
kubectl get pods -w

# Get pod YAML
kubectl get pod course-api-pod -o yaml

# Detailed pod info
kubectl describe pod course-api-pod

# Get pod labels
kubectl get pods --show-labels
```

### Pod Logs
```bash
# View logs
kubectl logs course-api-pod

# Stream logs
kubectl logs -f course-api-pod

# View last 50 lines
kubectl logs --tail=50 course-api-pod

# View logs from last 10 minutes
kubectl logs --since=10m course-api-pod

# View logs with timestamps
kubectl logs --timestamps=true course-api-pod

# View previous logs (if pod crashed)
kubectl logs course-api-pod --previous

# View logs from all pods with label
kubectl logs -l app=course-api
```

### Execute Commands
```bash
# Execute command in pod
kubectl exec course-api-pod -- curl localhost:3000/health

# Interactive shell in pod
kubectl exec -it course-api-pod -- /bin/sh

# Run specific command
kubectl exec -it course-api-pod -- ps aux

# Run as specific user
kubectl exec -it --user 1000 course-api-pod -- /bin/sh
```

### Port Forwarding
```bash
# Forward pod port to local
kubectl port-forward pod/course-api-pod 3000:3000

# Forward service port to local
kubectl port-forward svc/course-api-service 8080:80

# Forward with specific IP
kubectl port-forward pod/course-api-pod 127.0.0.1:3000:3000

# Stop port forwarding (Ctrl+C)
```

### Delete Pods
```bash
# Delete pod
kubectl delete pod course-api-pod

# Delete pod with grace period
kubectl delete pod course-api-pod --grace-period=30

# Force delete pod
kubectl delete pod course-api-pod --grace-period=0 --force

# Delete all pods
kubectl delete pods --all

# Delete pods by label
kubectl delete pods -l app=course-api
```

### Pod Information
```bash
# Get pod status
kubectl get pod course-api-pod -o jsonpath='{.status.phase}'

# Get pod IP
kubectl get pod course-api-pod -o jsonpath='{.status.podIP}'

# Get container status
kubectl get pod course-api-pod -o jsonpath='{.status.containerStatuses[*].name}'

# Get pod events
kubectl describe pod course-api-pod | grep -A 20 Events

# Get pod resource usage
kubectl top pod course-api-pod
```

---

## SERVICE MANAGEMENT

### Create Services
```bash
# Apply service configuration
kubectl apply -f api-service.yaml

# Create service from command line
kubectl expose pod course-api-pod --port=80 --target-port=3000 --type=NodePort
```

### View Services
```bash
# List services
kubectl get svc

# List services in namespace
kubectl get svc -n course-api

# Get service details
kubectl describe svc course-api-service

# Get service YAML
kubectl get svc course-api-service -o yaml

# List service endpoints
kubectl get endpoints

# Get specific endpoint
kubectl get endpoints course-api-service
```

### Service Information
```bash
# Get NodePort
kubectl get svc course-api-service -o jsonpath='{.spec.ports[0].nodePort}'

# Get ClusterIP
kubectl get svc course-api-service -o jsonpath='{.spec.clusterIP}'

# Get LoadBalancer IP (if available)
kubectl get svc course-api-service -o jsonpath='{.status.loadBalancer.ingress[0].ip}'

# Get all port mappings
kubectl get svc course-api-service -o jsonpath='{.spec.ports[*]}'
```

### Delete Services
```bash
# Delete service
kubectl delete svc course-api-service

# Delete service by label
kubectl delete svc -l app=course-api
```

---

## DEPLOYMENT MANAGEMENT

### Create Deployments
```bash
# Apply deployment
kubectl apply -f deployment.yaml

# Create deployment from command line
kubectl create deployment course-api --image=yourusername/course-api:latest

# Create deployment with replicas
kubectl create deployment course-api --image=yourusername/course-api:latest --replicas=3
```

### View Deployments
```bash
# List deployments
kubectl get deployments

# Get deployment details
kubectl describe deployment course-api-deployment

# Get deployment YAML
kubectl get deployment course-api-deployment -o yaml

# List replicas
kubectl get replica sets

# Watch deployment
kubectl get deployment -w
```

### Scale Deployments
```bash
# Scale to specific replicas
kubectl scale deployment course-api-deployment --replicas=5

# Autoscale deployment (HPA)
kubectl autoscale deployment course-api-deployment --min=2 --max=10 --cpu-percent=70

# Get HPA status
kubectl get hpa

# Describe HPA
kubectl describe hpa course-api-hpa

# Watch HPA scaling
kubectl get hpa -w
```

### Update Deployments
```bash
# Set image
kubectl set image deployment/course-api-deployment \
  course-api-container=yourusername/course-api:v1.0.1

# Set environment variable
kubectl set env deployment/course-api-deployment NODE_ENV=production

# Edit deployment
kubectl edit deployment course-api-deployment
```

### Rollout Management
```bash
# Check rollout status
kubectl rollout status deployment/course-api-deployment

# View rollout history
kubectl rollout history deployment/course-api-deployment

# Rollback to previous version
kubectl rollout undo deployment/course-api-deployment

# Rollback to specific revision
kubectl rollout undo deployment/course-api-deployment --to-revision=2

# Watch rollout
kubectl rollout status -w deployment/course-api-deployment
```

### Delete Deployments
```bash
# Delete deployment
kubectl delete deployment course-api-deployment

# Delete deployment and all related objects
kubectl delete deployment course-api-deployment --cascade=background
```

---

## MONITORING & DEBUGGING

### Resource Usage
```bash
# Pod resource usage
kubectl top pod

# Specific pod usage
kubectl top pod course-api-pod

# Node resource usage
kubectl top node

# Specific node usage
kubectl top node <node-name>
```

### Events
```bash
# Get cluster events
kubectl get events

# Get pod events
kubectl describe pod course-api-pod | grep -A 20 Events

# Watch events
kubectl get events -w

# Events in specific namespace
kubectl get events -n course-api
```

### Debugging
```bash
# Get pod YAML
kubectl get pod course-api-pod -o yaml

# Get pod status conditions
kubectl get pod course-api-pod -o jsonpath='{.status.conditions[*]}'

# Check container status
kubectl get pod course-api-pod -o jsonpath='{.status.containerStatuses[*]}'

# Get pod events
kubectl get events --field-selector involvedObject.name=course-api-pod

# Describe all resources
kubectl describe all

# Debug with temporary pod
kubectl run -it --rm debug --image=nicolaka/netshoot:latest --restart=Never -- /bin/bash

# Check DNS from pod
kubectl exec -it course-api-pod -- nslookup service-name
```

### Verify Health
```bash
# Check pod health
kubectl get pod course-api-pod -o jsonpath='{.status.conditions[?(@.type=="Ready")].status}'

# Check service endpoints
kubectl get endpoints course-api-service

# Test connectivity
kubectl exec -it course-api-pod -- curl localhost:3000/health

# Check pod logs for errors
kubectl logs course-api-pod | grep -i error
```

---

## LABELS AND SELECTORS

### Label Operations
```bash
# Show all labels
kubectl get pods --show-labels

# Label a pod
kubectl label pod course-api-pod env=production

# Label deployment
kubectl label deployment course-api-deployment tier=api

# Override label
kubectl label pod course-api-pod env=staging --overwrite

# Remove label
kubectl label pod course-api-pod env-

# Select by label
kubectl get pods -l app=course-api

# Select with multiple labels
kubectl get pods -l app=course-api,env=production

# Select with not equal
kubectl get pods -l app!=course-api

# Select with set operators
kubectl get pods -l 'app in (course-api, other-api)'
kubectl get pods -l 'app notin (course-api)'
```

---

## CONFIGMAPS AND SECRETS

```bash
# Create ConfigMap
kubectl create configmap course-config --from-literal=NODE_ENV=production

# Create Secret
kubectl create secret generic course-secret --from-literal=pass=secret123

# View ConfigMap
kubectl get configmap course-config -o yaml

# View Secret
kubectl get secret course-secret -o yaml

# Delete ConfigMap
kubectl delete configmap course-config

# Delete Secret
kubectl delete secret course-secret
```

---

## CLEANUP

### Delete Individual Resources
```bash
# Delete pod
kubectl delete pod course-api-pod

# Delete service
kubectl delete svc course-api-service

# Delete deployment
kubectl delete deployment course-api-deployment

# Delete HPA
kubectl delete hpa course-api-hpa
```

### Bulk Delete
```bash
# Delete all pods
kubectl delete pods --all

# Delete all resources with label
kubectl delete all -l app=course-api

# Delete all resources
kubectl delete all --all

# Delete namespace
kubectl delete namespace course-api
```

### Force Delete
```bash
# Force delete pod
kubectl delete pod course-api-pod --grace-period=0 --force

# Force delete deployment
kubectl delete deployment course-api-deployment --cascade=orphan
```

---

## TIPS & TRICKS

### Useful Aliases
```bash
# Add to ~/.bashrc or ~/.zshrc
alias k='kubectl'
alias kg='kubectl get'
alias kd='kubectl describe'
alias kl='kubectl logs'
alias kx='kubectl exec -it'

# Usage:
k get pods
kg pods
kd pod course-api-pod
kl course-api-pod
kx course-api-pod -- bash
```

### Shell Completion
```bash
# Enable bash completion
source <(kubectl completion bash)

# Enable zsh completion
source <(kubectl completion zsh)
```

### Quick Commands
```bash
# Get all resources
kubectl get all

# Get specific namespace
kubectl get all -n course-api

# Use specific kubeconfig
kubectl --kubeconfig=/path/to/config get pods

# Dry run (see what would be applied)
kubectl apply -f file.yaml --dry-run=client

# Get wide output
kubectl get pods -o wide

# Get JSON output
kubectl get pods -o json

# Get custom columns
kubectl get pods -o custom-columns=NAME:.metadata.name,STATUS:.status.phase
```

---

**Last Updated**: March 2026  
**Kubernetes Version**: 1.20+
