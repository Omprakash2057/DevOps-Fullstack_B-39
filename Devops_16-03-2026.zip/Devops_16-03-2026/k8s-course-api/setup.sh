#!/bin/bash

# Course Management API - Kubernetes Deployment Quick Start
# This script automates the setup process

set -e  # Exit on error

echo "════════════════════════════════════════════════════"
echo "     Course Management API - Quick Start Setup"
echo "════════════════════════════════════════════════════"
echo ""

# Color codes
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Check prerequisites
check_prerequisites() {
    echo -e "${BLUE}[*] Checking prerequisites...${NC}"
    
    if ! command -v docker &> /dev/null; then
        echo -e "${RED}[!] Docker is not installed${NC}"
        exit 1
    fi
    
    if ! command -v kubectl &> /dev/null; then
        echo -e "${RED}[!] kubectl is not installed${NC}"
        exit 1
    fi
    
    echo -e "${GREEN}[✓] Prerequisites check passed${NC}"
    echo ""
}

# Build Docker image
build_image() {
    echo -e "${BLUE}[*] Building Docker image...${NC}"
    docker build -t course-api:latest .
    echo -e "${GREEN}[✓] Docker image built successfully${NC}"
    echo ""
}

# Test Docker image locally
test_image() {
    echo -e "${BLUE}[*] Testing Docker image locally...${NC}"
    echo -e "${YELLOW}    Starting test container...${NC}"
    
    docker run -d --name course-api-test -p 3000:3000 course-api:latest
    sleep 3
    
    if curl -f http://localhost:3000/health > /dev/null 2>&1; then
        echo -e "${GREEN}[✓] Health check passed${NC}"
    else
        echo -e "${RED}[!] Health check failed${NC}"
        docker stop course-api-test
        docker rm course-api-test
        exit 1
    fi
    
    docker stop course-api-test
    docker rm course-api-test
    echo -e "${GREEN}[✓] Docker image test passed${NC}"
    echo ""
}

# Push to Docker Hub
push_image() {
    read -p "Enter your Docker Hub username: " DOCKER_USERNAME
    
    echo -e "${BLUE}[*] Logging in to Docker Hub...${NC}"
    docker login
    
    echo -e "${BLUE}[*] Tagging image for Docker Hub...${NC}"
    docker tag course-api:latest ${DOCKER_USERNAME}/course-api:latest
    docker tag course-api:latest ${DOCKER_USERNAME}/course-api:v1.0.0
    
    echo -e "${BLUE}[*] Pushing image to Docker Hub...${NC}"
    docker push ${DOCKER_USERNAME}/course-api:latest
    docker push ${DOCKER_USERNAME}/course-api:v1.0.0
    
    echo -e "${GREEN}[✓] Image pushed to Docker Hub${NC}"
    echo ""
    
    # Update YAML files
    echo -e "${BLUE}[*] Updating YAML files with Docker Hub username...${NC}"
    sed -i.bak "s/your-dockerhub-username/${DOCKER_USERNAME}/g" api-pod.yaml deployment.yaml
    echo -e "${GREEN}[✓] YAML files updated${NC}"
    echo ""
}

# Deploy to Kubernetes
deploy_to_k8s() {
    echo -e "${BLUE}[*] Deploying Pod to Kubernetes...${NC}"
    kubectl apply -f api-pod.yaml
    
    echo -e "${BLUE}[*] Waiting for pod to be ready...${NC}"
    for i in {1..30}; do
        if kubectl get pod course-api-pod -o jsonpath='{.status.phase}' 2>/dev/null | grep -q "Running"; then
            echo -e "${GREEN}[✓] Pod is running${NC}"
            break
        fi
        echo "    Waiting... ($i/30)"
        sleep 2
    done
    
    echo -e "${BLUE}[*] Deploying Service...${NC}"
    kubectl apply -f api-service.yaml
    
    echo -e "${GREEN}[✓] Kubernetes deployment complete${NC}"
    echo ""
}

# Display access information
display_access_info() {
    echo -e "${BLUE}[*] Getting access information...${NC}"
    
    NODEPORT=$(kubectl get svc course-api-service -o jsonpath='{.spec.ports[0].nodePort}' 2>/dev/null || echo "30001")
    
    echo -e "${GREEN}════════════════════════════════════════════════════${NC}"
    echo -e "${GREEN}         API is Ready for Testing!${NC}"
    echo -e "${GREEN}════════════════════════════════════════════════════${NC}"
    echo ""
    echo -e "${YELLOW}NodePort: ${NODEPORT}${NC}"
    echo ""
    echo "Test using:"
    echo "  curl http://localhost:${NODEPORT}/health"
    echo "  curl http://localhost:${NODEPORT}/courses"
    echo ""
    echo "Or use kubectl port-forward:"
    echo "  kubectl port-forward svc/course-api-service 8080:80"
    echo "  Then access: http://localhost:8080"
    echo ""
}

# Display optional steps
display_optional_steps() {
    echo -e "${BLUE}════════════════════════════════════════════════════${NC}"
    echo -e "${BLUE}             Optional Next Steps${NC}"
    echo -e "${BLUE}════════════════════════════════════════════════════${NC}"
    echo ""
    echo "1. Deploy with Deployment (recommended for production):"
    echo "   kubectl apply -f deployment.yaml"
    echo ""
    echo "2. Scale the deployment:"
    echo "   kubectl scale deployment course-api-deployment --replicas=5"
    echo ""
    echo "3. View logs:"
    echo "   kubectl logs -f pod/course-api-pod"
    echo ""
    echo "4. Get pod details:"
    echo "   kubectl describe pod course-api-pod"
    echo ""
    echo "5. Delete resources:"
    echo "   kubectl delete pod course-api-pod"
    echo "   kubectl delete svc course-api-service"
    echo ""
}

# Main execution
main() {
    check_prerequisites
    
    read -p "Do you want to build the Docker image? (y/n) " -n 1 -r
    echo
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        build_image
    fi
    
    read -p "Do you want to test the Docker image? (y/n) " -n 1 -r
    echo
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        test_image
    fi
    
    read -p "Do you want to push to Docker Hub? (y/n) " -n 1 -r
    echo
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        push_image
    else
        echo -e "${YELLOW}[!] Skipping Docker Hub push${NC}"
        echo -e "${YELLOW}    Update YAML files manually with your Docker Hub username${NC}"
        echo ""
    fi
    
    read -p "Do you want to deploy to Kubernetes? (y/n) " -n 1 -r
    echo
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        deploy_to_k8s
    fi
    
    display_access_info
    display_optional_steps
}

# Run main function
main
