# Kubernetes REST API Deployment Guide
## Complete Course Management API Deployment

---

## TABLE OF CONTENTS
1. [Project Overview](#overview)
2. [Prerequisites](#prerequisites)
3. [Docker Setup & Deployment](#docker-setup)
4. [Kubernetes Pod Deployment](#kubernetes-pod)
5. [Service Configuration](#service-config)
6. [Scaling & Management](#scaling)
7. [Advanced Topics](#advanced)
8. [Testing & Verification](#testing)
9. [Troubleshooting](#troubleshooting)

---

## PROJECT OVERVIEW {#overview}

This project demonstrates deploying a REST API for a Course Management System using:
- **Backend**: Node.js + Express.js
- **Containerization**: Docker with multi-stage builds
- **Orchestration**: Kubernetes (Pod, Service, Deployment)
- **Scalability**: Horizontal Pod Autoscaler (HPA)

### API Endpoints:
```
GET     /                - Welcome message
GET     /health          - Health check
GET     /courses         - List all courses
GET     /courses/:id     - Get specific course
POST    /add-course      - Add new course
PUT     /courses/:id     - Update course
DELETE  /courses/:id     - Delete course
```

---

## PREREQUISITES {#prerequisites}

### Required Software:
```bash
# Check installations
docker --version          # Docker (version 20.10+)
kubectl version --client  # kubectl (compatible with K8s cluster)
kind version              # kind (for local testing, optional)
```

### Other Requirements:
- Docker Hub account (for image repository)
- Kubernetes cluster (local with Kind/Minikube or cloud-based)
- 2+ CPU cores, 4GB+ RAM recommended

---

## DOCKER SETUP & DEPLOYMENT {#docker-setup}

### Step 1: Build the Docker Image

```bash
# Navigate to project directory
cd k8s-course-api

# Build image with tag
docker build -t course-api:latest .

# Alternative: Build with specific version tag
docker build -t course-api:v1.0.0 .

# Verify image was created
docker images | grep course-api
```

### Step 2: Test Docker Image Locally (Before Pushing)

```bash
# Run container locally
docker run -d \
  --name course-api-test \
  -p 3000:3000 \
  course-api:latest

# Check container is running
docker ps | grep course-api

# Test the health endpoint
curl http://localhost:3000/health

# View logs
docker logs course-api-test

# Stop container
docker stop course-api-test
docker rm course-api-test
```

### Step 3: Tag and Push to Docker Hub

```bash
# Create Docker Hub account at https://hub.docker.com

# Login to Docker Hub
docker login
# Enter username and password when prompted

# Tag image with Docker Hub repository
docker tag course-api:latest your-dockerhub-username/course-api:latest
docker tag course-api:latest your-dockerhub-username/course-api:v1.0.0

# Push to Docker Hub
docker push your-dockerhub-username/course-api:latest
docker push your-dockerhub-username/course-api:v1.0.0

# Verify push
docker images | grep your-dockerhub-username/course-api
```

### Step 4: Update YAML Files

Replace `your-dockerhub-username` in:
- `api-pod.yaml` - image field
- `deployment.yaml` - image field

```yaml
# Before:
image: your-dockerhub-username/course-api:latest

# After:
image: yourusername/course-api:latest
```

---

## KUBERNETES POD DEPLOYMENT {#kubernetes-pod}

### Step 1: Create Kubernetes Namespace (Optional)

```bash
# Create namespace for organization
kubectl create namespace course-api
# Or apply from file
kubectl apply -f - << EOF
apiVersion: v1
kind: Namespace
metadata:
  name: course-api
EOF
```

### Step 2: Deploy Pod

```bash
# Apply Pod configuration
kubectl apply -f api-pod.yaml

# Verify pod is created
kubectl get pods

# Get detailed pod information
kubectl describe pod course-api-pod

# Watch pod status
kubectl get pods -w
```

### Step 3: Verify Pod is Running

```bash
# Check pod status
kubectl get pod course-api-pod

# View pod details
kubectl describe pod course-api-pod

# Check pod events
kubectl get events

# View full pod YAML
kubectl get pod course-api-pod -o yaml
```

### Step 4: Access Pod Logs

```bash
# View current logs
kubectl logs course-api-pod

# Stream logs in real-time
kubectl logs -f course-api-pod

# View last 50 lines
kubectl logs --tail=50 course-api-pod

# View logs from last 10 minutes
kubectl logs --since=10m course-api-pod
```

### Step 5: Execute Commands Inside Pod

```bash
# Get shell access to pod
kubectl exec -it course-api-pod -- /bin/sh

# Inside pod shell, you can run:
# curl http://localhost:3000/health
# ps aux
# exit

# Or run single command
kubectl exec course-api-pod -- curl localhost:3000/health
```

---

## SERVICE CONFIGURATION {#service-config}

### Step 1: Create Service

```bash
# Apply Service configuration (NodePort)
kubectl apply -f api-service.yaml

# Verify service is created
kubectl get svc

# Get detailed service information
kubectl describe svc course-api-service
```

### Step 2: Find Service Access Information

```bash
# Get NodePort number
kubectl get svc course-api-service -o jsonpath='{.spec.ports[0].nodePort}'
# Output: 30001

# Get node IP address
kubectl get nodes -o wide
# Or specific node IP:
kubectl get node <node-name> -o jsonpath='{.status.addresses[?(@.type=="ExternalIP")].address}'

# For Minikube/Kind on local machine
minikube ip
kind get nodes
```

### Step 3: Access the API

```bash
# Using NodePort (Local Machine)
NODEIP=$(kubectl get nodes -o jsonpath='{.items[0].status.addresses[?(@.type=="ExternalIP")].address}' || echo "localhost")
NODEPORT=$(kubectl get svc course-api-service -o jsonpath='{.spec.ports[0].nodePort}')

# Test health endpoint
curl http://${NODEIP}:${NODEPORT}/health

# List all courses
curl http://${NODEIP}:${NODEPORT}/courses

# Get specific course
curl http://${NODEIP}:${NODEPORT}/courses/1
```

### Step 4: Port Forwarding (Alternative Access Method)

```bash
# Forward local port to pod
kubectl port-forward pod/course-api-pod 3000:3000

# In another terminal, now you can access:
curl http://localhost:3000/health
curl http://localhost:3000/courses

# For service:
kubectl port-forward svc/course-api-service 8080:80

# Access via:
curl http://localhost:8080/health
```

---

## SCALING & MANAGEMENT {#scaling}

### Step 1: Scale Pod (Manual - Not Recommended for Pods)

```bash
# Note: Pods cannot be scaled directly. Use Deployment instead.
# Duplicate and rename the pod manually if needed.

# To scale properly, use Deployment (see next section)
```

### Step 2: Deploy with Replication Controller (Scaling Pods)

```bash
# Create ReplicationController for scaling
kubectl apply -f - << EOF
apiVersion: v1
kind: ReplicationController
metadata:
  name: course-api-rc
spec:
  replicas: 3
  selector:
    app: course-api
  template:
    metadata:
      labels:
        app: course-api
    spec:
      containers:
      - name: course-api-container
        image: yourusername/course-api:latest
        ports:
        - containerPort: 3000
      restartPolicy: Always
EOF

# Or better: Deploy with Deployment (see below)
```

### Step 3: Check Pod Status

```bash
# List all pods
kubectl get pods

# List pods with more details
kubectl get pods -o wide

# Get specific pod details
kubectl get pod course-api-pod -o yaml

# Watch pods in real-time
kubectl get pods -w
```

### Step 4: View Events and Logs

```bash
# View cluster events
kubectl get events
kubectl describe events

# View pod events
kubectl describe pod course-api-pod

# View pod logs
kubectl logs course-api-pod

# Stream pod logs
kubectl logs -f course-api-pod

# View logs with timestamps
kubectl logs course-api-pod --timestamps=true

# View previous pod logs (if pod restarted)
kubectl logs course-api-pod --previous
```

### Step 5: Restart Pod

```bash
# Delete pod (will be recreated if managed by Deployment)
kubectl delete pod course-api-pod

# Wait for pod to be recreated
kubectl get pods -w

# Or force delete with grace period
kubectl delete pod course-api-pod --grace-period=0 --force

# Verify pod is running again
kubectl describe pod course-api-pod
```

### Step 6: Update Pod Image

```bash
# Update image in running pod (not recommended for Pods)
kubectl set image pod/course-api-pod \
  course-api-container=yourusername/course-api:v1.0.1

# Better approach: Create new pod with updated image
kubectl delete pod course-api-pod
# Then apply new yaml with updated image
kubectl apply -f api-pod.yaml  # After updating image in yaml
```

---

## ADVANCED TOPICS {#advanced}

### Deployment Configuration (Recommended for Production)

```bash
# Deploy using Deployment (automatic scaling, rolling updates)
kubectl apply -f deployment.yaml

# Verify deployment
kubectl get deployments

# Get deployment details
kubectl describe deployment course-api-deployment

# Watch deployment rollout
kubectl rollout status deployment/course-api-deployment

# View deployment history
kubectl rollout history deployment/course-api-deployment

# Rollback to previous version
kubectl rollout undo deployment/course-api-deployment

# Rollback to specific revision
kubectl rollout undo deployment/course-api-deployment --to-revision=2
```

### Scale Deployment

```bash
# Scale deployment manually
kubectl scale deployment course-api-deployment --replicas=5

# Verify scaling
kubectl get pods

# Watch pods scaling
kubectl get pods -w
```

### Setup Horizontal Pod Autoscaler (HPA)

```bash
# Check if metrics-server is installed (required for HPA)
kubectl get deployment metrics-server -n kube-system

# If not installed, install metrics-server:
kubectl apply -f https://github.com/kubernetes-sigs/metrics-server/releases/latest/download/components.yaml

# Create HPA (included in deployment.yaml)
kubectl apply -f - << EOF
apiVersion: autoscaling/v2
kind: HorizontalPodAutoscaler
metadata:
  name: course-api-hpa
spec:
  scaleTargetRef:
    apiVersion: apps/v1
    kind: Deployment
    name: course-api-deployment
  minReplicas: 2
  maxReplicas: 10
  metrics:
  - type: Resource
    resource:
      name: cpu
      target:
        type: Utilization
        averageUtilization: 70
EOF

# Check HPA status
kubectl get hpa

# Monitor HPA
kubectl describe hpa course-api-hpa

# Watch HPA scaling decisions
kubectl get hpa -w
```

### Labels and Selectors

```bash
# View labels on pods
kubectl get pods --show-labels

# Label a pod
kubectl label pod course-api-pod env=production version=v1

# Label a deployment
kubectl label deployment course-api-deployment tier=api

# Select pods by label
kubectl get pods -l app=course-api

# Select multiple labels
kubectl get pods -l app=course-api,environment=production

# Select with value operator
kubectl get pods -l 'environment in (production, staging)'
```

### ConfigMap and Secrets

```bash
# Create ConfigMap for configuration
kubectl create configmap course-api-config \
  --from-literal=NODE_ENV=production \
  --from-literal=PORT=3000

# Create Secret for sensitive data
kubectl create secret generic course-api-secret \
  --from-literal=db-password=secretpassword

# View ConfigMap
kubectl get configmap course-api-config -o yaml

# View Secret
kubectl get secret course-api-secret -o yaml

# Use in pod:
# env:
# - name: PORT
#   valueFrom:
#     configMapKeyRef:
#       name: course-api-config
#       key: PORT
```

---

## TESTING & VERIFICATION {#testing}

### Method 1: Using cURL

```bash
# Get API URL
NODEIP=$(kubectl get nodes -o jsonpath='{.items[0].status.addresses[?(@.type=="ExternalIP")].address}' || echo "localhost")
NODEPORT=$(kubectl get svc course-api-service -o jsonpath='{.spec.ports[0].nodePort}')
API_URL="http://${NODEIP}:${NODEPORT}"

# Test 1: Health Check
curl ${API_URL}/health

# Test 2: Get all courses
curl ${API_URL}/courses

# Test 3: Get specific course
curl ${API_URL}/courses/1

# Test 4: Add new course
curl -X POST ${API_URL}/add-course \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Advanced Kubernetes",
    "instructor": "Alice Cooper",
    "duration": "8 weeks"
  }'

# Test 5: Update course
curl -X PUT ${API_URL}/courses/1 \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Node.js Advanced Topics",
    "instructor": "John Doe",
    "duration": "5 weeks"
  }'

# Test 6: Delete course
curl -X DELETE ${API_URL}/courses/1
```

### Method 2: Using Postman

```
1. Open Postman
2. Create new collection: "Course API Testing"
3. Create requests:

GET http://<NODEIP>:<NODEPORT>/health
GET http://<NODEIP>:<NODEPORT>/courses
GET http://<NODEIP>:<NODEPORT>/courses/1
POST http://<NODEIP>:<NODEPORT>/add-course
  Body: JSON
  {
    "name": "Test Course",
    "instructor": "Test Instructor",
    "duration": "4 weeks"
  }
PUT http://<NODEIP>:<NODEPORT>/courses/1
  Body: JSON
  {
    "name": "Updated Course Name",
    "instructor": "Updated Instructor",
    "duration": "6 weeks"
  }
DELETE http://<NODEIP>:<NODEPORT>/courses/1

4. Run collection tests
5. View response times and status codes
```

### Method 3: Using kubectl port-forward

```bash
# Terminal 1: Forward port
kubectl port-forward svc/course-api-service 8080:80

# Terminal 2: Run tests
curl http://localhost:8080/health
curl http://localhost:8080/courses

# Test with Postman:
# Use http://localhost:8080 as base URL
```

### Method 4: Automated Load Testing

```bash
# Using Apache Bench (ab)
ab -n 1000 -c 10 http://<NODEIP>:<NODEPORT>/courses

# Using wrk (load testing tool)
wrk -t4 -c100 -d30s http://<NODEIP>:<NODEPORT>/health

# Using hey (modern load testing)
hey -n 1000 -c 50 http://<NODEIP>:<NODEPORT>/courses
```

---

## TROUBLESHOOTING {#troubleshooting}

### Pod Won't Start

```bash
# Check pod status
kubectl describe pod course-api-pod

# Check pod logs
kubectl logs course-api-pod

# Check previous logs if pod crashed
kubectl logs course-api-pod --previous

# Check events
kubectl get events

# Common issues:
# - ImagePullBackOff: Image not found, verify Docker Hub push
# - CrashLoopBackOff: Application crashed, check logs
# - Pending: Not enough resources, check node capacity
```

### Image Pull Errors

```bash
# Verify image exists in Docker Hub
docker pull yourusername/course-api:latest

# Verify image name in YAML matches Docker Hub
kubectl get pod course-api-pod -o jsonpath='{.spec.containers[0].image}'

# Add image pull secret if using private registry
kubectl create secret docker-registry regcred \
  --docker-server=docker.io \
  --docker-username=<your-username> \
  --docker-password=<your-password>
```

### Cannot Access Service

```bash
# Verify service is created
kubectl get svc course-api-service

# Verify pod is running and ready
kubectl get pods course-api-pod -o wide

# Verify service selector matches pod labels
kubectl get pod course-api-pod --show-labels
kubectl get svc course-api-service -o jsonpath='{.spec.selector}'

# Check if endpoints are assigned
kubectl get endpoints course-api-service

# Test pod connectivity directly
kubectl exec -it course-api-pod -- curl localhost:3000/health

# Check network policies if any
kubectl get networkpolicies
```

### High Resource Usage

```bash
# Check resource usage
kubectl top nodes
kubectl top pods

# Check pod resource limits
kubectl describe pod course-api-pod

# Check cluster resources
kubectl describe nodes

# If out of resources, scale down or add more nodes
```

### Debugging Commands

```bash
# Get pod details in YAML
kubectl get pod course-api-pod -o yaml

# Describe entire pod
kubectl describe pod course-api-pod

# View pod events
kubectl describe pod course-api-pod | grep -A 20 Events

# Check pod conditions
kubectl get pod course-api-pod -o jsonpath='{.status.conditions[*]}'

# SSH into pod for debugging
kubectl exec -it course-api-pod -- /bin/sh

# tcpdump network traffic
kubectl run -it --rm debug --image=nicolaka/netshoot:latest --restart=Never -- tcpdump -i eth0 -A
```

---

## CLEANUP & TEARDOWN

```bash
# Delete Pod
kubectl delete pod course-api-pod

# Delete Service
kubectl delete svc course-api-service

# Delete Deployment
kubectl delete deployment course-api-deployment

# Delete HPA
kubectl delete hpa course-api-hpa

# Delete all resources with labels
kubectl delete all -l app=course-api

# Delete ConfigMap and Secrets
kubectl delete configmap course-api-config
kubectl delete secret course-api-secret

# Delete namespace
kubectl delete namespace course-api

# Clean local Docker images
docker rmi course-api:latest
docker rmi yourusername/course-api:latest
```

---

## COMPLETE WORKFLOW SUMMARY

```bash
# 1. Build Docker image
docker build -t course-api:latest .

# 2. Tag and push to Docker Hub
docker tag course-api:latest yourusername/course-api:latest
docker login
docker push yourusername/course-api:latest

# 3. Update YAML files with your Docker Hub username

# 4. Deploy Pod
kubectl apply -f api-pod.yaml

# 5. Verify Pod is running
kubectl get pods
kubectl describe pod course-api-pod

# 6. Deploy Service
kubectl apply -f api-service.yaml

# 7. Get access details
kubectl get svc course-api-service
NODEIP=$(kubectl get nodes -o jsonpath='{.items[0].status.addresses[?(@.type=="ExternalIP")].address}' || echo "localhost")
NODEPORT=$(kubectl get svc course-api-service -o jsonpath='{.spec.ports[0].nodePort}')

# 8. Test API
curl http://${NODEIP}:${NODEPORT}/health
curl http://${NODEIP}:${NODEPORT}/courses

# 9. Scale with Deployment (optional)
kubectl apply -f deployment.yaml

# 10. Monitor
kubectl get pods -w
kubectl logs -f deployment/course-api-deployment
```

---

## PERFORMANCE OPTIMIZATION TIPS

1. **Resource Requests/Limits**: Set appropriate CPU and memory limits
2. **Health Checks**: Use liveness and readiness probes
3. **Multi-stage Docker Build**: Reduces image size
4. **Node Affinity**: Schedule pods on specific nodes
5. **Pod Disruption Budgets**: Ensure availability during node maintenance
6. **Horizontal Pod Autoscaler**: Auto-scale based on metrics
7. **Caching**: Implement caching strategies in application
8. **Logging**: Use structured logging for better observability

---

## REFERENCES

- Kubernetes Official Docs: https://kubernetes.io/docs/
- Express.js Documentation: https://expressjs.com/
- Docker Documentation: https://docs.docker.com/
- Docker Hub: https://hub.docker.com/
- kubectl Cheat Sheet: https://kubernetes.io/docs/reference/kubectl/

---

**Last Updated**: March 2026
**Author**: DevOps Engineer
