const express = require('express');
const bodyParser = require('body-parser');
const os = require('os');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// Sample in-memory database for courses
let courses = [
  { id: 1, name: 'Node.js Basics', instructor: 'John Doe', duration: '4 weeks' },
  { id: 2, name: 'Kubernetes Fundamentals', instructor: 'Jane Smith', duration: '6 weeks' },
  { id: 3, name: 'Docker Essentials', instructor: 'Bob Johnson', duration: '3 weeks' }
];

// =====================
// API ENDPOINTS
// =====================

// Health Check Endpoint
app.get('/health', (req, res) => {
  res.status(200).json({
    status: 'OK',
    timestamp: new Date().toISOString(),
    hostname: os.hostname(),
    uptime: process.uptime()
  });
});

// Get all courses
app.get('/courses', (req, res) => {
  console.log(`[${new Date().toISOString()}] GET /courses - Total courses: ${courses.length}`);
  res.status(200).json({
    success: true,
    data: courses,
    count: courses.length,
    hostname: os.hostname()
  });
});

// Get a specific course by ID
app.get('/courses/:id', (req, res) => {
  const courseId = parseInt(req.params.id);
  const course = courses.find(c => c.id === courseId);
  
  console.log(`[${new Date().toISOString()}] GET /courses/${courseId}`);
  
  if (!course) {
    return res.status(404).json({
      success: false,
      error: 'Course not found',
      courseId: courseId
    });
  }
  
  res.status(200).json({
    success: true,
    data: course,
    hostname: os.hostname()
  });
});

// Add a new course
app.post('/add-course', (req, res) => {
  const { name, instructor, duration } = req.body;
  
  // Validation
  if (!name || !instructor || !duration) {
    return res.status(400).json({
      success: false,
      error: 'Missing required fields: name, instructor, duration'
    });
  }
  
  const newCourse = {
    id: courses.length > 0 ? Math.max(...courses.map(c => c.id)) + 1 : 1,
    name,
    instructor,
    duration
  };
  
  courses.push(newCourse);
  
  console.log(`[${new Date().toISOString()}] POST /add-course - New course added: ${name}`);
  
  res.status(201).json({
    success: true,
    message: 'Course added successfully',
    data: newCourse,
    hostname: os.hostname()
  });
});

// Update a course
app.put('/courses/:id', (req, res) => {
  const courseId = parseInt(req.params.id);
  const course = courses.find(c => c.id === courseId);
  
  if (!course) {
    return res.status(404).json({
      success: false,
      error: 'Course not found',
      courseId: courseId
    });
  }
  
  const { name, instructor, duration } = req.body;
  if (name) course.name = name;
  if (instructor) course.instructor = instructor;
  if (duration) course.duration = duration;
  
  console.log(`[${new Date().toISOString()}] PUT /courses/${courseId} - Course updated`);
  
  res.status(200).json({
    success: true,
    message: 'Course updated successfully',
    data: course,
    hostname: os.hostname()
  });
});

// Delete a course
app.delete('/courses/:id', (req, res) => {
  const courseId = parseInt(req.params.id);
  const initialLength = courses.length;
  courses = courses.filter(c => c.id !== courseId);
  
  if (courses.length === initialLength) {
    return res.status(404).json({
      success: false,
      error: 'Course not found',
      courseId: courseId
    });
  }
  
  console.log(`[${new Date().toISOString()}] DELETE /courses/${courseId} - Course deleted`);
  
  res.status(200).json({
    success: true,
    message: 'Course deleted successfully',
    deletedId: courseId,
    hostname: os.hostname()
  });
});

// Root endpoint
app.get('/', (req, res) => {
  res.status(200).json({
    message: 'Welcome to Course Management API',
    version: '1.0.0',
    hostname: os.hostname(),
    endpoints: {
      health: 'GET /health',
      listCourses: 'GET /courses',
      getCourse: 'GET /courses/:id',
      addCourse: 'POST /add-course',
      updateCourse: 'PUT /courses/:id',
      deleteCourse: 'DELETE /courses/:id'
    }
  });
});

// 404 handler
app.use((req, res) => {
  res.status(404).json({
    success: false,
    error: 'Endpoint not found',
    path: req.path,
    method: req.method
  });
});

// Start the server
app.listen(PORT, () => {
  console.log(`=========================================`);
  console.log(`Server running on port ${PORT}`);
  console.log(`Hostname: ${os.hostname()}`);
  console.log(`Started at: ${new Date().toISOString()}`);
  console.log(`=========================================`);
  console.log('\nAPI Documentation:');
  console.log('  GET  /              - Welcome message');
  console.log('  GET  /health        - Health check');
  console.log('  GET  /courses       - List all courses');
  console.log('  GET  /courses/:id   - Get specific course');
  console.log('  POST /add-course    - Add new course');
  console.log('  PUT  /courses/:id   - Update course');
  console.log('  DELETE /courses/:id - Delete course');
  console.log('=========================================\n');
});

// Graceful shutdown
process.on('SIGTERM', () => {
  console.log('SIGTERM signal received: closing HTTP server');
  process.exit(0);
});

process.on('SIGINT', () => {
  console.log('SIGINT signal received: closing HTTP server');
  process.exit(0);
});
