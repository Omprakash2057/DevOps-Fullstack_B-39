# Course Management API - Kubernetes Deployment

A complete, production-ready solution for deploying a REST API using Kubernetes. This project demonstrates best practices for containerization, orchestration, and scaling.

## 📋 Project Structure

```
k8s-course-api/
├── server.js                 # Express.js REST API
├── package.json              # Node.js dependencies
├── Dockerfile                # Multi-stage Docker build
├── api-pod.yaml              # Kubernetes Pod definition
├── api-service.yaml          # Kubernetes Service definition
├── deployment.yaml           # Kubernetes Deployment with HPA
├── setup.sh                  # Linux/macOS quick start
├── setup.ps1                 # Windows quick start
├── KUBERNETES-GUIDE.md       # Complete detailed guide
├── QUICK-REFERENCE.md        # Command reference
├── .gitignore                # Git ignore rules
└── README.md                 # This file
```

## 🚀 Quick Start (5 Minutes)

### Linux/macOS:
```bash
# 1. Run setup script
chmod +x setup.sh
./setup.sh

# Follow the interactive prompts
```

### Windows (PowerShell):
```powershell
# 1. Run setup script
.\setup.ps1

# Follow the interactive prompts
```

### Manual Setup:
```bash
# 1. Build Docker image
docker build -t course-api:latest .

# 2. Push to Docker Hub (replace with your username)
docker tag course-api:latest yourusername/course-api:latest
docker login
docker push yourusername/course-api:latest

# 3. Update YAML files with your username:
sed -i 's/your-dockerhub-username/yourusername/g' api-pod.yaml deployment.yaml

# 4. Deploy to Kubernetes
kubectl apply -f api-pod.yaml
kubectl apply -f api-service.yaml

# 5. Access the API
kubectl port-forward svc/course-api-service 8080:80
# Then visit: http://localhost:8080/health
```

## 📚 Features

### REST API Endpoints
- `GET /` - Welcome message
- `GET /health` - Health check
- `GET /courses` - List all courses
- `GET /courses/:id` - Get specific course
- `POST /add-course` - Add new course
- `PUT /courses/:id` - Update course
- `DELETE /courses/:id` - Delete course

### Kubernetes Features
- ✅ Pod deployment with health checks
- ✅ Service exposure (NodePort/LoadBalancer)
- ✅ Liveness and readiness probes
- ✅ Resource limits and requests
- ✅ Rolling updates and rollback
- ✅ Horizontal Pod Autoscaler (HPA)
- ✅ ConfigMaps and Secrets support
- ✅ Security best practices

### Docker Features
- ✅ Multi-stage builds for optimization
- ✅ Alpine base image (lightweight)
- ✅ Health checks
- ✅ Non-root user execution
- ✅ Proper signal handling

## 🔧 Prerequisites

- Docker 20.10+
- kubectl 1.20+
- Kubernetes cluster (local: Kind/Minikube, or cloud: AWS/Azure/GCP)
- Docker Hub account (for image repository)
- 2+ CPU cores, 4GB+ RAM

## 📖 Documentation

### Comprehensive Guide
See [KUBERNETES-GUIDE.md](KUBERNETES-GUIDE.md) for detailed instructions including:
- Complete Docker setup and deployment
- Pod and Service configuration
- Scaling and management
- Testing and verification
- Troubleshooting
- Advanced topics

### Quick Reference
See [QUICK-REFERENCE.md](QUICK-REFERENCE.md) for command cheatsheet

## 🧪 Testing the API

### Using cURL
```bash
# Health check
curl http://localhost:8080/health

# Get all courses
curl http://localhost:8080/courses

# Add new course
curl -X POST http://localhost:8080/add-course \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Advanced Kubernetes",
    "instructor": "Alice Cooper",
    "duration": "8 weeks"
  }'

# Update course
curl -X PUT http://localhost:8080/courses/1 \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Updated Course",
    "instructor": "Bob Smith",
    "duration": "6 weeks"
  }'

# Delete course
curl -X DELETE http://localhost:8080/courses/1
```

### Using Postman
1. Import the endpoints into Postman
2. Set base URL: `http://localhost:8080`
3. Run requests with provided body samples

### Using kubectl Port-Forward
```bash
# Terminal 1: Forward port
kubectl port-forward svc/course-api-service 8080:80

# Terminal 2: Test API
curl http://localhost:8080/health
```

## 📊 Kubernetes Management

### Viewing Resources
```bash
# List pods
kubectl get pods

# List services
kubectl get svc

# List deployments
kubectl get deployments
```

### Monitoring
```bash
# View logs
kubectl logs -f pod/course-api-pod

# Monitor resource usage
kubectl top pods
kubectl top nodes

# Watch pod status
kubectl get pods -w
```

### Debugging
```bash
# Get pod details
kubectl describe pod course-api-pod

# Execute command in pod
kubectl exec -it course-api-pod -- /bin/sh

# Check pod events
kubectl get events
```

## 🔄 Scaling

### Manual Scaling
```bash
# Scale deployment
kubectl scale deployment course-api-deployment --replicas=5
```

### Automatic Scaling (HPA)
Horizontal Pod Autoscaler automatically scales pods based on CPU and memory usage. Configured in `deployment.yaml`:
- Minimum replicas: 2
- Maximum replicas: 10
- CPU threshold: 70%
- Memory threshold: 80%

View HPA status:
```bash
kubectl describe hpa course-api-hpa
kubectl get hpa -w
```

## 🔐 Security Features

- Non-root user execution
- Resource limits enforced
- Read-only root filesystem (optional)
- Network policies (optional)
- RBAC integration ready

## 📈 Performance Tuning

1. **Resource Requests/Limits**: Adjust based on your workload
2. **Replicas**: Scale based on traffic patterns
3. **Health Checks**: Tune probe timing and thresholds
4. **Image Size**: Alpine base keeps images small (~90MB)
5. **Caching**: Implement application-level caching

## 🐳 Docker Image Details

- **Base Image**: node:18-alpine
- **Optimizations**: Multi-stage build
- **Health Check**: Built-in HTTP health check
- **Size**: ~90MB
- **Registry**: Docker Hub

## 🚢 Production Deployment

### For AWS EKS
```bash
# Create LoadBalancer service
kubectl apply -f - << EOF
apiVersion: v1
kind: Service
metadata:
  name: course-api-alb
spec:
  type: LoadBalancer
  selector:
    app: course-api
  ports:
  - protocol: TCP
    port: 80
    targetPort: 3000
EOF
```

### For Azure AKS
Same approach with `type: LoadBalancer` - Azure will provision an Azure Load Balancer

### For Google GKE
Same approach with `type: LoadBalancer` - GCP will provision a Google Cloud Load Balancer

## 📝 Deployment Checklist

Before production, ensure:
- [ ] Update Docker Hub credentials in YAML files
- [ ] Set appropriate resource requests/limits
- [ ] Configure health check thresholds
- [ ] Setup HPA with proper metrics
- [ ] Enable RBAC and NetworkPolicies
- [ ] Configure persistent storage if needed
- [ ] Setup monitoring and logging
- [ ] Create backup strategy
- [ ] Test disaster recovery
- [ ] Document runbooks

## 🆘 Troubleshooting

### Pod won't start
```bash
# Check pod status
kubectl describe pod course-api-pod

# Check logs
kubectl logs course-api-pod

# Check events
kubectl get events
```

### Cannot access API
```bash
# Verify service endpoints
kubectl get endpoints course-api-service

# Check service selector
kubectl get svc course-api-service -o yaml
```

### Image pull errors
```bash
# Verify image exists
docker pull yourusername/course-api:latest

# Check image name in YAML
kubectl get pod course-api-pod -o yaml | grep image
```

See [KUBERNETES-GUIDE.md](KUBERNETES-GUIDE.md) for detailed troubleshooting.

## 📱 API Response Examples

### Safe Deployment with Replicas
```bash
metadata:
  - name: course-api-pod-1
    labels:
      app: course-api
      pod-id: "1"
  - name: course-api-pod-2
    labels:
      app: course-api
      pod-id: "2"
```

### Health Response
```json
{
  "status": "OK",
  "timestamp": "2026-03-26T10:30:45.123Z",
  "hostname": "course-api-pod-abc123",
  "uptime": 1234.567
}
```

### Courses Response
```json
{
  "success": true,
  "data": [
    {
      "id": 1,
      "name": "Node.js Basics",
      "instructor": "John Doe",
      "duration": "4 weeks"
    },
    {
      "id": 2,
      "name": "Kubernetes Fundamentals",
      "instructor": "Jane Smith",
      "duration": "6 weeks"
    }
  ],
  "count": 2,
  "hostname": "course-api-pod-xyz789"
}
```

## 🔗 Useful Resources

- [Kubernetes Official Docs](https://kubernetes.io/docs/)
- [Express.js Documentation](https://expressjs.com/)
- [Docker Documentation](https://docs.docker.com/)
- [Docker Hub](https://hub.docker.com/)
- [kubectl Cheat Sheet](https://kubernetes.io/docs/reference/kubectl/cheatsheet/)

## 📄 License

MIT License - feel free to use this project for learning and production deployments.

## 👨‍💻 Author

DevOps Engineer

## 📞 Support

For issues, questions, or contributions:
1. Check [KUBERNETES-GUIDE.md](KUBERNETES-GUIDE.md) for detailed documentation
2. Review troubleshooting section above
3. Check kubectl and Docker documentation

---

**Version**: 1.0.0  
**Last Updated**: March 2026  
**Status**: Production Ready ✅
